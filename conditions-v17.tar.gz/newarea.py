#!/usr/bin/env python3
"""
Create an area config by looking its stations up, rather than guessing them.

    newarea.py --all              create every area in AREAS that doesn't exist
    newarea.py --slug 9           create just one
    newarea.py --list             show what would be created

Everything this writes is discovered from NOAA and NWS at run time:

  * the NWS coastal marine zone that actually contains the point
  * the nearest NOAA tide-prediction station
  * the nearest NOAA current-prediction station, **tested before it is used**

That last one is the lesson from PUG1613: it is in the station list, it is the
closest station to Everett, and it answers current-prediction requests with
strings where the documentation says objects. Proximity is not proof that a
station works, so each candidate is called for real and the first one that
returns usable events wins.

This must run somewhere with network access to NOAA and NWS — i.e. the server,
not a laptop behind a corporate proxy.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import sources  # noqa: E402

UA = "tanglefoot-conditions/1.0 (+https://tanglefoot.dev)"
MDAPI = "https://api.tidesandcurrents.noaa.gov/mdapi/prod/webapi/stations.json"

# Representative points, not centroids: each is where you would actually be in
# that area — the channel you transit or the water you fish — because that is
# what the forecast and the stations need to describe.
AREAS = [
    {
        "slug": "8-2", "area": "Marine Area 8-2", "order": 1,
        "wdfw_slug": "ports-susan-gardner",
        "rule_match": r"marine area 8|area 8-2|possession sound|port susan|port gardner|everett|snohomish|tulalip|puget sound (crab|shrimp|shellfish|salmon)|halibut",
        "eyebrow": "Possession Sound &middot; Marine Area 8-2",
        "subtitle": "14-day outlook &middot; Port of Everett Marina",
        "blurb": "Home water. Port Gardner, the Tulalip Bubble and Hat Island.",
        "lat": 47.99, "lon": -122.22,
        "harvest": "harvest.json",
    },
    {
        "slug": "9", "area": "Marine Area 9", "order": 2,
        "wdfw_slug": "admiralty-inlet",
        "rule_match": r"marine area 9|admiralty|port townsend|puget sound (crab|shrimp|shellfish|salmon)|halibut",
        "harvest": "harvest-9.json",
        "eyebrow": "Admiralty Inlet &middot; Marine Area 9",
        "subtitle": "14-day outlook &middot; Admiralty Inlet and Port Townsend",
        "blurb": "The gate. Everything north or west crosses it, and the current "
                 "here is real &mdash; not the half knot Possession Sound runs.",
        "lat": 48.00, "lon": -122.62,
    },
    {
        "slug": "8-1", "area": "Marine Area 8-1", "order": 3,
        "wdfw_slug": "deception-pass-hope-island-skagit-bay",
        "rule_match": r"marine area 8|area 8-1|deception pass|skagit bay|hope island|saratoga|puget sound (crab|shrimp|shellfish|salmon)|halibut",
        "eyebrow": "Saratoga Passage &middot; Marine Area 8-1",
        "subtitle": "14-day outlook &middot; Saratoga Passage and Skagit Bay",
        "blurb": "First hop north. Langley, Camano, La Conner &mdash; protected "
                 "water and a walkable waterfront at the end of it.",
        "lat": 48.15, "lon": -122.50,
    },
    {
        "slug": "7", "area": "Marine Area 7", "order": 4,
        "wdfw_slug": "san-juan-islands",
        "rule_match": r"marine area 7|san juan|rosario|bellingham|friday harbor|puget sound (crab|shrimp|shellfish|salmon)|halibut",
        "eyebrow": "San Juan Islands &middot; Marine Area 7",
        "subtitle": "14-day outlook &middot; San Juan and Rosario Straits",
        "blurb": "The destination. Anchorages and towns both, and the longest "
                 "open crossings on the route.",
        "lat": 48.55, "lon": -122.95,
    },
    {
        "slug": "10", "area": "Marine Area 10", "order": 5,
        "wdfw_slug": "seattle-bremerton-area",
        "rule_match": r"marine area 10|seattle|bremerton|elliott bay|bainbridge|puget sound (crab|shrimp|shellfish|salmon)|halibut",
        "eyebrow": "Central Puget Sound &middot; Marine Area 10",
        "subtitle": "14-day outlook &middot; Seattle, Bainbridge and Blake Island",
        "blurb": "South run. Poulsbo, Blake Island, Shilshole.",
        "lat": 47.65, "lon": -122.42,
    },
    {
        "slug": "12", "area": "Marine Area 12", "order": 6,
        "wdfw_slug": "hood-canal",
        "rule_match": r"marine area 12|hood canal|puget sound (crab|shrimp|shellfish|salmon)|halibut",
        "eyebrow": "Hood Canal &middot; Marine Area 12",
        "subtitle": "14-day outlook &middot; Hood Canal",
        "blurb": "Quiet and scenic, and a long way in and back out again.",
        "lat": 47.70, "lon": -122.88,
    },
]


def get(url, timeout=60):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def nm(lat1, lon1, lat2, lon2):
    p, q, r = map(math.radians, (lat1, lat2, lon2 - lon1))
    return 3440.065 * math.acos(min(1, math.sin(p) * math.sin(q)
                                    + math.cos(p) * math.cos(q) * math.cos(r)))


def find_zone(lat, lon):
    """The NWS coastal marine zone containing the point, e.g. 'pzz135'."""
    try:
        d = get(f"https://api.weather.gov/zones?type=coastal&point={lat},{lon}")
        for f in d.get("features", []):
            zid = f.get("properties", {}).get("id")
            if zid:
                return zid.lower(), f["properties"].get("name", "")
    except Exception as e:
        print(f"    ! zone lookup failed: {e}")
    return None, ""


def nearest_stations(kind, lat, lon, limit=8):
    d = get(f"{MDAPI}?type={kind}&units=english")
    rows = []
    for s in d.get("stations", []):
        try:
            rows.append((nm(lat, lon, float(s["lat"]),
                            float(s.get("lng", s.get("lon")))),
                         s["id"], s.get("name", ""), s.get("currbin")))
        except Exception:
            continue
    rows.sort()
    return rows[:limit]


def working_current_station(lat, lon):
    """
    Nearest current station that actually returns usable predictions.

    Stations are tried in distance order and each is called for real. A station
    that is closer but broken is worse than one further away that works, and
    the only way to tell them apart is to ask.
    """
    from datetime import date, timedelta
    today = date.today()
    cands = nearest_stations("currentpredictions", lat, lon, limit=14)

    # bins that publish predictions, highest first: bin number rises as depth
    # falls, so the largest is the shallowest — closest to what a hull feels
    bins = {}
    for _, sid, _, b in cands:
        if b not in (None, ""):
            bins.setdefault(sid, set()).add(int(b))

    tried = []
    for dist, sid, name, _ in cands:
        for b in sorted(bins.get(sid, {None}), reverse=True):
            data, err = sources.fetch_currents(sid, b, today, today + timedelta(days=1))
            tried.append(f"{sid}/{b}")
            if data and data.get("events"):
                print(f"    currents: {sid} bin {b} — {name} ({dist:.1f} nm), "
                      f"{len(data['events'])} events")
                return sid, b
    print(f"    ! no working current station found (tried {', '.join(tried[:8])})")
    return None, None


def build_config(a):
    print(f"  {a['slug']}  {a['area']}  ({a['lat']}, {a['lon']})")
    zone, zname = find_zone(a["lat"], a["lon"])
    print(f"    zone: {zone or 'NOT FOUND'}  {zname}")

    tides = nearest_stations("tidepredictions", a["lat"], a["lon"], limit=3)
    if not tides:
        print("    ! no tide station found")
        return None
    tdist, tid, tname, _ = tides[0]
    print(f"    tides: {tid} — {tname} ({tdist:.1f} nm)")

    cid, cbin = working_current_station(a["lat"], a["lon"])

    if not zone:
        # No silent fallback. Substituting another area's zone gives the page an
        # authoritative-looking marine forecast for the wrong water, which is
        # worse than having none: it is wrong in a way the reader cannot see.
        print("    !! REFUSING to write this area: no NWS coastal zone resolved.")
        print("       Re-run with a point that is actually in open water.")
        return None

    cfg = {
        "title": "Boating Conditions for Overthinkers",
        "area": a["area"],
        "canonical": f"https://tanglefoot.dev/conditions/{a['slug']}/",
        "href": f"/conditions/{a['slug']}/",
        "order": a["order"],
        "blurb": a["blurb"],
        "eyebrow": a["eyebrow"],
        "subtitle": a["subtitle"] + f" &middot; tides at {tname}",
        "description": (f"14-day boating conditions for {a['area']} - tides, "
                        "currents, wind against suggested limits, and what's open."),
        "station": tid,
        "station_name": tname,
        "wdfw_slug": a.get("wdfw_slug", ""),
        "rule_match": a.get("rule_match", ""),
        "zone": zone,
        "zone_name": zname,
        "lat": a["lat"], "lon": a["lon"],
        "timezone": "America/Los_Angeles",
        "wind_limit_kt": 12,
        "seas_limit_ft": 2,
        "bands": {"green": [12, 2], "amber": [18, 4], "rough": [24, 6]},
        "current_station": cid,
        "current_bin": cbin,
        "min_bytes": 20000,
        "output": f"/var/www/tanglefoot/conditions/{a['slug']}/index.html",
        "_fetch_note": ("Fetch is local geography and is NOT inherited from another "
                        "area. Until this is filled in, sea state is estimated from "
                        "wind alone with no directional weighting, and the page says "
                        "nothing about fetch. Add sector entries as you learn the water: "
                        "\"S\": [\"straight up the strait\", 1.3]"),
        "fetch": {},
    }
    if a.get("harvest"):
        cfg["harvest"] = a["harvest"]
    return cfg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--slug")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--force", action="store_true", help="overwrite existing configs")
    ap.add_argument("--dir", default=os.path.join(HERE, "areas"))
    args = ap.parse_args()

    if args.list:
        for a in AREAS:
            print(f"{a['slug']:>4}  {a['area']:<16} {a['lat']:>7.3f},{a['lon']:>9.3f}  "
                  f"{a['blurb'][:52]}")
        return 0

    todo = [a for a in AREAS if args.all or a["slug"] == args.slug]
    if not todo:
        print("nothing selected — use --all, --slug <n>, or --list")
        return 1

    os.makedirs(args.dir, exist_ok=True)
    made = skipped = failed = 0
    for a in todo:
        path = os.path.join(args.dir, f"{a['slug']}.json")
        if os.path.exists(path) and not args.force:
            print(f"  {a['slug']}: exists, leaving alone (--force to replace)")
            skipped += 1
            continue
        cfg = build_config(a)
        if not cfg:
            failed += 1
            continue
        with open(path, "w") as fh:
            json.dump(cfg, fh, indent=2, ensure_ascii=False)
            fh.write("\n")
        print(f"    wrote {path}")
        made += 1
    print(f"\n{made} written, {skipped} skipped, {failed} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
