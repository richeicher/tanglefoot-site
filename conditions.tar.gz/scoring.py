"""
Turning numbers into a verdict.

All of the judgement the page makes lives here, in one place, so the rules can
be read and argued with rather than being scattered through the renderer.
"""

from __future__ import annotations

MS_TO_KT = 1.94384
MM_TO_IN = 1 / 25.4

COMPASS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
           "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]

# Arrows point the way the wind is blowing, not where it comes from.
ARROW = {"N": "↓", "NNE": "↓", "NE": "↙", "ENE": "↙", "E": "←", "ESE": "←",
         "SE": "↖", "SSE": "↑", "S": "↑", "SSW": "↑", "SW": "↗", "WSW": "→",
         "W": "→", "WNW": "→", "NW": "↘", "NNW": "↓"}


def compass(deg):
    if deg is None:
        return None
    return COMPASS[int((float(deg) % 360) / 22.5 + 0.5) % 16]


def kt(ms):
    return None if ms is None else round(float(ms) * MS_TO_KT, 1)


def f(c):
    return None if c is None else round(float(c) * 9 / 5 + 32)


def inches(mm):
    return 0.0 if mm is None else round(float(mm) * MM_TO_IN, 2)


def sea_state(peak_kt):
    """
    Possession Sound has a short fetch, so sea state follows wind closely.
    Returns (label, upper-bound feet) — the bound is what gets compared against
    the seas threshold.
    """
    if peak_kt is None:
        return ("Unknown", None)
    if peak_kt <= 3:
        return ("Glassy, under 6 in", 0.5)
    if peak_kt <= 6:
        return ("Ripples, under 6 in", 0.5)
    if peak_kt <= 9:
        return ("Light chop, ~1 ft", 1.0)
    if peak_kt <= 12:
        return ("Chop, 1&ndash;2 ft", 2.0)
    return ("2+ ft", 3.0)


def sky_phrase(symbol, cloud_pct):
    """Short human phrase for a cell, preferring the model's own symbol."""
    if symbol:
        s = symbol.split("_")[0]
        table = {
            "clearsky": "Clear", "fair": "Mostly clear", "partlycloudy": "Partly cloudy",
            "cloudy": "Overcast", "lightrain": "Light rain", "rain": "Rain",
            "heavyrain": "Heavy rain", "lightrainshowers": "Light showers",
            "rainshowers": "Showers", "heavyrainshowers": "Heavy showers",
            "fog": "Fog", "lightsleet": "Sleet", "sleet": "Sleet", "snow": "Snow",
            "lightsnow": "Light snow", "heavysnow": "Heavy snow",
            "lightsnowshowers": "Snow showers", "snowshowers": "Snow showers",
        }
        if s in table:
            return table[s]
    if cloud_pct is None:
        return "&mdash;"
    if cloud_pct < 10:
        return "Clear"
    if cloud_pct < 40:
        return "Mostly clear"
    if cloud_pct < 75:
        return "Partly cloudy"
    return "Overcast"


def rate_day(peak_kt, seas_ft, rain_in, cloud_avg, wind_limit, seas_limit,
             has_forecast=True):
    """
    Returns (rating, label). Ratings drive colour; labels are what the chip says.

    The order matters. Seas can disqualify a day whose wind is still legal —
    9 to 12 kt is inside a 10 kt limit but already puts up 1 to 2 ft — so the
    sea check comes first and the reason is reported separately.
    """
    if not has_forecast:
        return ("soft", "Tilt only")

    over_wind = peak_kt is not None and peak_kt > wind_limit
    over_seas = seas_ft is not None and seas_ft > seas_limit
    heavy_rain = rain_in >= 0.25
    some_rain = rain_in >= 0.05

    if over_wind or over_seas or heavy_rain:
        return ("bad", "Stay in")
    if some_rain or (peak_kt is not None and peak_kt > wind_limit * 0.8):
        return ("warn", "Marginal")

    dry_calm = rain_in < 0.02 and (peak_kt is not None and peak_kt <= wind_limit * 0.7)
    if dry_calm and (cloud_avg is not None and cloud_avg < 45):
        return ("go", "Excellent")
    return ("go", "Good")


def limiting_factor(peak_kt, seas_ft, rain_in, wind_limit, seas_limit):
    """Which threshold actually decides the day. Used in the prose."""
    if seas_ft is not None and seas_ft > seas_limit:
        if peak_kt is not None and peak_kt <= wind_limit:
            return "seas"          # the interesting case: legal wind, illegal water
        return "seas and wind"
    if peak_kt is not None and peak_kt > wind_limit:
        return "wind"
    if rain_in >= 0.25:
        return "rain"
    if rain_in >= 0.05:
        return "showers"
    return None


def score_for_ranking(day):
    """Higher is better. Used to pick the standout day of the run."""
    if day.get("tilt"):
        return -1e9
    s = 0.0
    s -= (day.get("rain_in") or 0) * 400          # dry dominates
    s -= (day.get("peak_kt") or 0) * 6            # then calm
    s -= (day.get("cloud_avg") or 0) * 0.35       # then clear
    s += (day.get("high_f") or 0) * 0.8           # then warm
    if day["rating"] == "bad":
        s -= 500
    if day["rating"] == "warn":
        s -= 200
    return s
