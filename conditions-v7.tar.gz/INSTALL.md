# conditions generator — install

This replaces the git-pull deploy. The box now builds the page itself from the
source APIs, so nothing has to be pushed to it and this Claude session drops out
of the daily loop entirely.

```
06:00  systemd timer fires
       → fetch NOAA tides, NWS PZZ135, MET Norway, WDFW rule feed
       → score, render, validate
       → atomic swap into /var/www/tanglefoot/index.html
```

No credentials anywhere. No GitHub. No conduit.

## Install

Copy the folder to the box and put it in place:

```bash
sudo mkdir -p /opt/conditions
sudo tar xzf conditions.tar.gz -C /opt/conditions
sudo chown -R root:root /opt/conditions
```

Python 3.11+ with `zoneinfo` is all it needs — no pip packages. Ubuntu 24.04 has
it. If timezone lookups fail, `sudo apt-get install -y tzdata`.

## Test before trusting it

**1. Can it reach everything?**

```bash
sudo python3 /opt/conditions/generate.py --check
```

Prints each source and what it got. Exit 0 means all four are healthy.

**2. Does it build a sane page?**

```bash
sudo python3 /opt/conditions/generate.py --dry-run
```

Writes to `/tmp/conditions-preview.html` and touches nothing else. Copy it
somewhere you can look at it, or `curl file:///tmp/conditions-preview.html`.

**3. For real:**

```bash
sudo python3 /opt/conditions/generate.py
curl -s localhost | grep -c "Wind through the day"   # expect 14
```

## Point the timer at it

```bash
sudo tee /etc/systemd/system/tanglefoot-deploy.service >/dev/null <<'UNIT'
[Unit]
Description=Build and publish the conditions page
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/bin/python3 /opt/conditions/generate.py
UNIT

sudo sed -i 's/06:20:00/06:00:00/' /etc/systemd/system/tanglefoot-deploy.timer
sudo systemctl daemon-reload
sudo systemctl restart tanglefoot-deploy.timer
systemctl list-timers | grep tanglefoot
```

The old `/usr/local/bin/tanglefoot-deploy` script and the `/srv/tanglefoot/repo`
clone are now unused. Leave them or delete them; nothing references them.

## What it refuses to do

The run exits without touching the live page if:

- the built page is under 20,000 bytes
- the page title (from `config.json`) isn't in it
- it doesn't contain exactly 14 day cards
- fewer than three days have any forecast behind them
- neither tides nor the model could be fetched (exit 2)

A degraded source doesn't stop the run — it publishes what it has and prints a
"Source degraded" note into the page's own notes list, so the page tells its
reader what it's missing rather than hiding it.

The previous page is kept at `/var/www/tanglefoot/index.prev.html`. Rollback:

```bash
sudo cp /var/www/tanglefoot/index.prev.html /var/www/tanglefoot/index.html
```

## The two files you'll actually edit

**`config.json`** — station, coordinates, zone, your thresholds, the page title
and the output path. The title doubles as the publish guard, so renaming the
page is a one-field edit. Changing `wind_limit_kt` or `seas_limit_ft` re-scores every
day on the next run.

**`harvest.json`** — the seasons table. This is **verified by hand, not
scraped**, because getting a season wrong has consequences a broken scraper
shouldn't be allowed to cause. Update it when seasons change and bump
`"checked"`. Every run reads the WDFW rule feed and, if new items mention this
water, prints a banner above the table saying the table hasn't been updated for
them. That's the prompt to go look.

## Adding more marine areas later

`config.json` is the whole per-area definition. Copy it, change station, zone,
coordinates, title and output path, and run `generate.py --config area9.json`
— well, almost: the config path is currently fixed. Adding a `--config` flag is
a two-line change when you want it, and then thirteen areas is thirteen JSON
files and thirteen timer units on the same $5 box.

## Tests

```bash
python3 /opt/conditions/test_offline.py
```

Runs the parsers against captured NOAA and NWS payloads, checks the sun and moon
maths against known values, exercises every scoring rule, and builds and renders
a full page from a synthetic series. No network needed. Run it after any edit.

## Known weaknesses

- **The prose is assembled by rule**, not written. It's accurate but flatter
  than the hand-written version.
- **The zone-forecast parser is the brittle part.** It reads a plain-text NWS
  product with a regex. If NWS changes the format, the zone data drops out,
  the page says so in its notes, and it falls back to the model alone.
- **The creel report section is not in this version.** It was a scrape of a page
  with no stable structure, and I would rather ship without it than ship
  something that silently goes wrong. Worth adding once there's a reason to
  trust the parse.
