#!/usr/bin/env python3
"""
Build the conditions page from live data and install it.

    generate.py --check      test every source, write nothing
    generate.py --dry-run    build the page to stdout path, don't install
    generate.py              build and install

Exit codes: 0 ok, 1 refused (page built but failed validation), 2 no usable data.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import tempfile
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import build
import render
import scoring as S
import sources


def log(msg):
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}", flush=True)


EMPTY_HARVEST = {"checked": None, "open_on": "", "seen_rule_titles": [],
                 "pills": [], "table": [], "footer": ""}


def load_json(name, default=None, base=None):
    # `base` lets an area config live anywhere and pull its siblings (harvest.json)
    # from beside itself rather than from the code directory.
    path = name if os.path.isabs(name) else os.path.join(base or HERE, name)
    if not os.path.exists(path):
        if default is not None:
            return default
        raise SystemExit(f"missing required file: {path}")
    with open(path) as fh:
        return json.load(fh)


# ─────────────────────────────────────────────────────────────── verdict ──

def runs_of(days, predicate):
    out, cur = [], []
    for d in days:
        if predicate(d):
            cur.append(d)
        else:
            if cur:
                out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return out


def make_verdict(days, cfg):
    usable = [d for d in days if d["rating"] == "go" and not d["tilt"]]
    best = next((d for d in days if d.get("best")), None)
    streaks = runs_of(days, lambda d: d["rating"] == "go" and not d["tilt"])
    longest = max(streaks, key=len) if streaks else []

    today = days[0]
    peaks = [d["peak_kt"] for d in days if d["peak_kt"] is not None]
    max_wind = max(peaks) if peaks else None
    wet = [d for d in days if d["rain_in"] >= 0.1]

    if not usable:
        headline = "Nothing inside the suggested limits in the next fortnight"
    elif longest and len(longest) >= 3:
        a, b = longest[0], longest[-1]
        headline = (f"{len(longest)} straight days inside the suggested limits, "
                    f"{a['date']:%b %-d}&ndash;{b['date']:%-d}")
        if best and best in longest:
            headline += f", with {best['date']:%A the %-d}{_ord(best['date'].day)} the standout"
    elif best:
        headline = f"{best['date']:%A the %-d}{_ord(best['date'].day)} is the day to take"
    else:
        headline = "A mixed fortnight &mdash; pick the window carefully"

    paras = []

    if max_wind is not None and max_wind <= cfg["wind_limit_kt"]:
        # Wind being legal all fortnight does NOT mean sea state is a non-issue:
        # 9-12 kt sits inside a 10 kt limit but already puts up 1-2 ft. Say which
        # threshold actually ruled the bad days out, or the prose contradicts the tiles.
        seas_out = [d for d in days
                    if not d["tilt"] and d["rating"] == "bad"
                    and d.get("seas_ft") is not None
                    and d["seas_ft"] > cfg["seas_limit_ft"]]
        if seas_out:
            names = ", ".join(f"{d['date']:%a the %-d}" for d in seas_out[:3])
            more = f" and {len(seas_out) - 3} more" if len(seas_out) > 3 else ""
            n = len(seas_out)
            p = (f"Wind never crosses the suggested {cfg['wind_limit_kt']}-knot line anywhere in "
                 f"the fortnight &mdash; the windiest hour in the whole run is {max_wind:.1f} kt. "
                 f"But wind is not what rules the red days out: at that speed the chop is "
                 f"already past the suggested {cfg['seas_limit_ft']}-foot seas limit, so "
                 f"<em>{n} day{'' if n == 1 else 's'} {'is' if n == 1 else 'are'} out on "
                 f"sea state, not wind</em> &mdash; {names}{more}.")
        else:
            p = (f"Wind never crosses the suggested {cfg['wind_limit_kt']}-knot line anywhere in "
                 f"the fortnight &mdash; the windiest hour in the whole run is {max_wind:.1f} kt, "
                 f"and the chop stays inside the suggested {cfg['seas_limit_ft']}-foot limit too. "
                 f"So <em>rain and visibility decide the days, not sea state</em>.")
    else:
        blown = [d for d in days if d["peak_kt"] and d["peak_kt"] > cfg["wind_limit_kt"]]
        names = ", ".join(f"{d['date']:%a the %-d}" for d in blown[:3])
        p = (f"Wind crosses the suggested {cfg['wind_limit_kt']}-knot limit on {len(blown)} "
             f"day{'' if len(blown) == 1 else 's'} &mdash; {names}. Everything else is "
             f"inside the line, so rain and cloud decide the rest.")
    if wet:
        p += (f" {len(wet)} day{'' if len(wet) == 1 else 's'} carry meaningful rain, "
              f"heaviest on {max(wet, key=lambda d: d['rain_in'])['date']:%A}.")
    paras.append(p)

    if best:
        cols = [c for c in best["cols"] if c["f"] is not None]
        warmest = max((c["f"] for c in cols), default=None)
        p2 = (f"<em>{best['date']:%A %b %-d} is the pick</em>: peak wind "
              f"{best['peak_kt']:.1f} kt, {best['rain_in']:.2f} in of rain")
        if warmest:
            p2 += f", {warmest}&deg;F at the warmest"
        p2 += f", and a {best['range']} tidal range."
        runner = sorted((d for d in usable if d is not best),
                        key=lambda d: d["score"], reverse=True)
        if runner:
            r = runner[0]
            p2 += (f" {r['date']:%A the %-d}{_ord(r['date'].day)} is the next best "
                   f"at {r['peak_kt']:.1f} kt.")
    else:
        p2 = "No day in the run comes in clean. Watch for the next model update."

    if today["rating"] == "go":
        p2 += " Today is inside the limits if you want to go now."
    elif today["rating"] == "bad":
        p2 += " Today is not one to be out in."
    paras.append(p2)

    return {"headline": headline, "paragraphs": paras}


def _ord(n):
    return "th" if 11 <= n % 100 <= 13 else {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")


# ──────────────────────────────────────────────────────────────── notes ──

def make_notes(cfg, zone_issued, model_updated, degraded, harvest_checked,
               currents=None):
    wl, sl = cfg["wind_limit_kt"], cfg["seas_limit_ft"]
    zone = (cfg.get("zone") or "").lower()
    zurl = (f"https://tgftp.nws.noaa.gov/data/forecasts/marine/coastal/pz/{zone}.txt"
            if zone else "https://marine.weather.gov/")
    A = lambda href, text: f'<a href="{href}">{text}</a>'
    notes = [
        "<b>Where these numbers come from, and what they are not.</b> "
        "There is no Coast Guard wind or sea limit for recreational boats &mdash; "
        + A("https://www.uscgboating.org/", "the USCG")
        + " regulates equipment, documentation and conduct, not whether a day is "
        "pleasant. The one official line is the National Weather Service&rsquo;s "
        + A("https://marinenavigation.noaa.gov/weather-warnings.html",
            "Small Craft Advisory")
        + ": <em>sustained winds between 20 and 33 knots</em>, or seas above a height "
        "set per region, for conditions &ldquo;that might be hazardous to small "
        f"craft&rdquo;. The {wl} knots and {sl} foot used here sit at roughly half "
        "that wind and a fraction of that sea. They are a <em>comfort</em> threshold "
        "for a small motor yacht, not a safety one.",

        "<b>So read the colours accordingly.</b> Green is a good day. Amber is water "
        "the boat handles perfectly well and you may simply not enjoy. Red on this "
        f"page means past {wl} kt or {sl} ft &mdash; nowhere near an advisory, and "
        "plenty of people are out in it happily. Nothing here knows your boat, your "
        "crew or your experience, and a green day is <em>worth considering</em>, "
        "never permission. Before any day near the top of the range, read the live "
        "product: " + A(zurl, f"NWS {zone.upper() or 'marine forecast'}") + " and "
        + A("https://marine.weather.gov/", "current warnings") + ".",

        "<b>Every day gets a full tile, in date order, today first.</b> Each shows "
        "conditions at four points through the day, the day's peak wind against the "
        f"suggested {wl}-kt limit, the full tide curve with all four turns, and sun, "
        "daylight, moon and rain totals.",
        "<b>This page is generated by a script on the server</b>, not written by hand. "
        "The numbers come straight from the sources below; the prose is assembled from "
        "the same numbers by rule. Where it reads a little flat, that is why.",
        "<b>The harvest table is verified by hand, not scraped.</b> It was last checked "
        f"on {harvest_checked}. The "
        + A("https://wdfw.wa.gov/fishing/regulations/emergency-rules",
            "WDFW rule feed") + " is read every run, and if anything "
        "new mentions this water a banner appears above the table &mdash; but the table "
        "itself does not change until a human updates it.",
        "<b>Tides are exact for all 14 days</b> &mdash; they're astronomical, not "
        "forecast. The shaded band on each chart is daylight, sunrise to sunset.",
        "<b>Sea state is estimated from wind</b> over Possession Sound's short fetch. "
        "The zone forecast's \"2 ft or less\" floor is too coarse to score against a "
        f"{sl}-foot threshold, so light-wind days are refined from wind speed. Where "
        "the zone forecast gives a harder wave number, that number wins. Wind is also "
        "weighted by the fetch of the direction it comes from &mdash; the same speed "
        "builds a bigger sea with twenty miles of open water behind it than with one.",
        "<b>Confidence drops as you go down the page.</b> The bar under each heading "
        "shows roughly how much to trust that block. The last days carry no wind "
        "guidance at all &mdash; their tiles show the tide, which is exact, and nothing "
        "that pretends to be a forecast.",
    ]
    if zone_issued:
        notes.append(f"<b>Zone forecast issued {zone_issued}.</b> Its day names are mapped "
                     "from its own issuance date, not today's, so a stale product can't "
                     "silently shift the week.")
    if model_updated:
        notes.append(f"<b>Model run {model_updated}.</b> Beyond about day three the data "
                     "is 6-hourly, which in Pacific time lands on 5 AM, 11 AM, 5 PM and "
                     "11 PM &mdash; the four columns each tile shows. Nothing is "
                     "interpolated.")
    if currents:
        m = currents["meta"]
        notes.append(
            f"<b>Currents are trolling information, not a go/no-go factor.</b> "
            f"They come from " + A("https://tidesandcurrents.noaa.gov/noaacurrents/"
                       f"Predictions?id={m['station']}_{m['bin']}",
                       f"NOAA station {m['station']} bin {m['bin']}") + ", and this "
            "water runs slack &mdash; well under a knot at every stage of every tide "
            "in the run. That is too little to build wind-against-tide chop, so "
            "current is deliberately <em>not</em> fed into the day ratings. What it "
            "is good for is the gap between speed over ground and speed through "
            "water when you are trolling, and knowing when the water goes still.")
    for d in degraded:
        notes.append(f"<b>Source degraded:</b> {d}")
    return notes


# ───────────────────────────────────────────────────────────────── main ──

def version_line():
    vpath = os.path.join(HERE, "VERSION")
    if os.path.exists(vpath):
        with open(vpath) as fh:
            return fh.readline().strip()
    return ""


def run_one(config="config.json", check=False, dry_run=False, out=None):
    """
    Build (and normally install) one area.

    Returns (exit_code, summary). The summary is what the landing page is
    assembled from, so the index can never disagree with the pages it links
    to: it is the same data, from the same run.
    """
    class _A:
        pass
    args = _A()
    args.check, args.dry_run, args.out, args.config = check, dry_run, out, config

    cfg_path = args.config if os.path.isabs(args.config) \
        else os.path.join(HERE, args.config)
    cfg_dir = os.path.dirname(cfg_path)
    cfg = load_json(cfg_path)
    tz = ZoneInfo(cfg["timezone"])
    today = datetime.now(tz).date()

    degraded = []

    log("fetching tides…")
    tides, err = sources.fetch_tides(cfg["station"], today - timedelta(days=1),
                                     today + timedelta(days=14))
    if err:
        degraded.append(err)
        log(f"  ! {err}")
    else:
        log(f"  {len(tides)} turns")

    log("fetching zone forecast…")
    if not cfg.get("zone"):
        zone, err = None, "no NWS zone configured for this area"
    else:
        zone, err = sources.fetch_zone(cfg["zone"])
    if err:
        degraded.append(err)
        log(f"  ! {err}")
    else:
        log(f"  issued {zone['issued']}, {len(zone['periods'])} periods")

    log("fetching model…")
    model, err = sources.fetch_model(cfg["lat"], cfg["lon"])
    if err:
        degraded.append(err)
        log(f"  ! {err}")
    else:
        log(f"  updated {model['updated']}, {len(model['steps'])} steps")

    log("fetching currents…")
    currents = None
    if cfg.get("current_station"):
        currents, err = sources.fetch_currents(
            cfg["current_station"], cfg.get("current_bin"),
            today - timedelta(days=1), today + timedelta(days=14))
        if err:
            degraded.append(err)
            log(f"  ! {err}")
        else:
            log(f"  {len(currents['events'])} slack/max events")
    else:
        log("  no current station configured, skipping")

    log("fetching rule feed…")
    feed, err = sources.fetch_rule_feed()
    if err:
        degraded.append(err)
        log(f"  ! {err}")
    else:
        log(f"  {len(feed)} items")

    def _sum(**kw):
        s = {"area": cfg.get("area", ""), "title": cfg.get("title", ""),
             "href": cfg.get("href", ""), "canonical": cfg.get("canonical", ""),
             "blurb": cfg.get("blurb", ""), "order": cfg.get("order", 99),
             "degraded": list(degraded)}
        s.update(kw)
        return s

    if args.check:
        log("check complete" + (f" — {len(degraded)} degraded" if degraded else " — all sources OK"))
        return (0 if not degraded else 1), _sum(ok=not degraded)

    if not tides and not model:
        log("REFUSED: neither tides nor model available, nothing worth publishing")
        return 2, _sum(ok=False, error="no tides and no model")

    # An area with no seasons table of its own simply has no harvest section.
    # EMPTY_HARVEST must match the shape render.harvest_section actually reads —
    # inventing a plausible-looking default was how six areas crashed on
    # KeyError: 'pills'.
    harvest = None
    hname = cfg.get("harvest")
    if hname:
        # beside the area config first, then beside the code: area configs live
        # in areas/ but a shared harvest.json sensibly sits with the code.
        for base in (cfg_dir, HERE):
            p = hname if os.path.isabs(hname) else os.path.join(base, hname)
            if os.path.exists(p):
                harvest = load_json(p)
                break
        if harvest is None:
            log(f"  ! harvest file {hname!r} not found — continuing without seasons")
    if harvest is None:
        harvest = dict(EMPTY_HARVEST)
    seen = set(harvest.get("seen_rule_titles", []))
    # Anything published before the table was last hand-verified is already
    # accounted for, so it cannot be news.
    rulepat = cfg.get("rule_match")
    alert = sources.relevant_rules(
        feed, seen, sources.parse_checked(harvest.get("checked")),
        pattern=rulepat) if feed else []
    recent = sources.recent_rules(feed, pattern=rulepat) if feed else []
    if recent:
        log(f"  {len(recent)} notice(s) mention this area")
    if alert:
        log(f"  {len(alert)} new relevant rule item(s) — banner will show")

    days, zone_issued = build.build_days(cfg, tides or [], model, zone, today,
                                         currents=currents)
    verdict = make_verdict(days, cfg)

    cfg = dict(cfg)
    cfg["generated"] = f"{datetime.now(tz):%a %-d %b %Y, %H:%M:%S %Z}"
    cfg["version"] = version_line()
    cfg["tier1_src"] = (f"NWS {cfg['zone'].upper()}"
                        + (f" {cfg['zone_name']}" if cfg.get("zone_name") else "")
                        + f", issued {zone['issued']}"
                        if zone else "NWS zone forecast unavailable")
    cfg["tier2_src"] = (f"MET Norway, run {model['updated']}" if model
                        else "model unavailable")
    cfg["tier3_src"] = "No model guidance at this range"

    zl = (cfg.get("zone") or "").lower()
    zurl = (f"https://tgftp.nws.noaa.gov/data/forecasts/marine/coastal/pz/{zl}.txt"
            if zl else "https://marine.weather.gov/")
    turl = f"https://tidesandcurrents.noaa.gov/stationhome.html?id={cfg['station']}"
    srcs = (f"Tides &middot; <a href=\"{turl}\">NOAA CO-OPS {cfg['station']}"
            f"{' ' + cfg['station_name'] if cfg.get('station_name') else ''}</a><br>"
            f"Marine &middot; <a href=\"{zurl}\">NWS {(cfg.get('zone') or 'none').upper()}"
            f"{' &mdash; ' + cfg['zone_name'] if cfg.get('zone_name') else ''}</a>"
            f"{', ' + zone['issued'] if zone else ' (unavailable)'}<br>"
            f"Model &middot; <a href=\"https://api.met.no/weatherapi/locationforecast/2.0/"
            f"documentation\">MET Norway Locationforecast 2.0</a>"
            f"{', run ' + model['updated'] if model else ' (unavailable)'}<br>"
            + (f"Currents &middot; <a href=\"https://tidesandcurrents.noaa.gov/noaacurrents/"
               f"Predictions?id={currents['meta']['station']}_"
               f"{currents['meta']['bin']}\">NOAA CO-OPS {currents['meta']['station']} "
               f"bin {currents['meta']['bin']}</a><br>" if currents else "")
            + (f"Harvest &middot; verified by hand {harvest['checked']}<br>"
               if harvest.get("checked") else "")
            + f"Rules &middot; <a href=\"https://wdfw.wa.gov/fishing/regulations/"
              f"emergency-rules\">WDFW emergency rules</a>, read {today:%-d %b %Y}<br>"
            + f"Sun and moon computed for {cfg['lat']}&deg;N, {cfg['lon']}&deg;E "
            + "&middot; all times local")

    notes = make_notes(cfg, zone["issued"] if zone else None,
                       model["updated"] if model else None,
                       degraded, harvest.get("checked"), currents)

    page = render.render(cfg, days, verdict, harvest, harvest.get("checked"),
                         alert, srcs, notes, recent_rules=recent)

    # ── validation: refuse to install anything that isn't clearly the page ──
    problems = []
    # The marker defaults to the title so renaming the page is a one-field edit.
    # It used to be a separate required field, which meant changing the title
    # alone would silently make every future run refuse to publish.
    marker = cfg.get("marker") or cfg["title"]
    if len(page) < cfg["min_bytes"]:
        problems.append(f"page is {len(page)} bytes, under {cfg['min_bytes']}")
    if marker not in page:
        problems.append(f"marker {marker!r} missing")
    if len([d for d in days if not d["tilt"]]) < 3:
        problems.append("fewer than three days have any forecast behind them")
    # Structural, and independent of whatever the page is called this week.
    cards = page.count('class="bc ')
    if cards != len(days):
        problems.append(f"{cards} day cards rendered, expected {len(days)}")
    if problems:
        for p in problems:
            log(f"REFUSED: {p}")
        return 1, _sum(ok=False, error="; ".join(problems))

    out = args.out or cfg["output"]
    if args.dry_run:
        # Unique name, not a fixed one: a preview written by one user would
        # otherwise be unwritable by the next (fs.protected_regular), and a
        # dry run must never fail for a reason that has nothing to do with
        # the page it is checking.
        fd, tmp = tempfile.mkstemp(prefix="conditions-preview-", suffix=".html")
        with os.fdopen(fd, "w") as fh:
            fh.write(page)
        os.chmod(tmp, 0o644)
        log(f"dry run — wrote {len(page)} bytes to {tmp}")
        return 0, _sum(ok=True, preview=tmp, **_headline(days, verdict))

    # atomic install, with the previous page kept for rollback
    d = os.path.dirname(out)
    os.makedirs(d, exist_ok=True)     # a new area's directory won't exist yet
    if os.path.exists(out):
        shutil.copy2(out, os.path.join(d, "index.prev.html"))
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    with os.fdopen(fd, "w") as fh:
        fh.write(page)
    os.chmod(tmp, 0o644)
    os.replace(tmp, out)
    log(f"published {len(page)} bytes to {out}"
        + (f" ({len(degraded)} source(s) degraded)" if degraded else ""))
    return 0, _sum(ok=True, bytes=len(page), out=out, **_headline(days, verdict))


def _headline(days, verdict):
    """The few facts the landing page shows for an area."""
    today = days[0]
    nxt = next((d for d in days
                if d["rating"] == "go" and not d["tilt"] and not d["today"]), None)
    return {
        "headline": verdict["headline"],
        "today_rating": today["rating"],
        "today_label": today["label"],
        "today_peak": today["peak_kt"],
        "today_sea": today.get("sea"),
        "next_good": f"{nxt['date']:%a %-d %b}" if nxt else None,
        "go_days": sum(1 for d in days if d["rating"] == "go" and not d["tilt"]),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="test sources, write nothing")
    ap.add_argument("--dry-run", action="store_true", help="build but do not install")
    ap.add_argument("--out", help="override output path")
    ap.add_argument("--config", default="config.json",
                    help="area config to build (default: config.json beside the code)")
    args = ap.parse_args()
    v = version_line()
    if v:
        log(f"conditions {v}")
    code, _ = run_one(args.config, args.check, args.dry_run, args.out)
    return code


if __name__ == "__main__":
    sys.exit(main())
