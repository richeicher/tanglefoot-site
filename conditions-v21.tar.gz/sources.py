"""
Data sources for the conditions page.

Every fetch is wrapped so a single dead source degrades the page instead of
killing the run. Each fetcher returns (data, note) where note is None on success
or a short human-readable string explaining what went wrong.
"""

from __future__ import annotations

import json
import re
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta, timezone

UA = "tanglefoot-conditions/1.0 (+https://tanglefoot.dev)"
TIMEOUT = 25


class SourceError(Exception):
    pass


def _get(url: str, accept: str = "*/*") -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": accept})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            if r.status != 200:
                raise SourceError(f"HTTP {r.status}")
            return r.read()
    except urllib.error.HTTPError as e:
        raise SourceError(f"HTTP {e.code}") from e
    except Exception as e:  # timeouts, DNS, TLS
        raise SourceError(str(e)[:120]) from e


# ──────────────────────────────────────────────────────────── currents ──

def fetch_currents(station: str, bin_num, start: date, end: date):
    """
    NOAA CO-OPS tidal current predictions, slack-and-max events.
    Returns (data, note) like every other fetcher here, where data is
    {'events': [(date, 'HH:MM', knots, 'slack'|'flood'|'ebb')], 'meta': {...}}
    and meta carries the mean flood/ebb set when NOAA supplies it.

    Velocity sign is NOAA's: positive flood, negative ebb. We keep the sign —
    direction is the whole point of the reading — and let the renderer decide
    how to show it.

    Not every station publishes every bin, and at least one station answers
    with a shape that is not the documented one, so everything here is checked
    before it is trusted rather than after it has thrown.
    """
    if not station:
        return None, None

    url = (
        "https://api.tidesandcurrents.noaa.gov/api/prod/datagetter"
        "?product=currents_predictions&application=tanglefoot"
        f"&begin_date={start:%Y%m%d}&end_date={end:%Y%m%d}"
        f"&station={station}&time_zone=lst_ldt"
        "&interval=MAX_SLACK&units=english&format=json"
        + (f"&bin={bin_num}" if bin_num not in (None, "") else "")
    )
    try:
        payload = json.loads(_get(url, "application/json"))
    except SourceError as e:
        return None, f"NOAA currents unavailable ({e})"
    except json.JSONDecodeError:
        return None, "NOAA currents returned malformed JSON"

    if isinstance(payload, dict) and payload.get("error"):
        msg = payload["error"].get("message", "unknown") \
            if isinstance(payload["error"], dict) else str(payload["error"])
        return None, f"NOAA currents refused station {station} ({msg[:80]})"

    block = payload.get("current_predictions") if isinstance(payload, dict) else None
    if not isinstance(block, dict):
        return None, f"NOAA currents returned an unexpected shape for {station}"

    cp = block.get("cp")
    if not isinstance(cp, list):
        return None, (f"NOAA currents gave no event list for {station} "
                      f"(got {type(cp).__name__})")

    out = []
    for e in cp:
        if not isinstance(e, dict):
            continue                      # a station that answers in strings
        t = e.get("Time") or e.get("t")
        if not t or " " not in t:
            continue
        d_str, hm = t.split(" ", 1)
        kind = str(e.get("Type", "")).strip().lower()
        if kind not in ("slack", "flood", "ebb"):
            continue
        v = e.get("Velocity_Major", e.get("Velocity"))
        try:
            kts = 0.0 if kind == "slack" else round(float(v), 2)
        except (TypeError, ValueError):
            continue
        out.append((d_str, hm[:5], kts, kind))

    if not out:
        return None, f"NOAA currents returned no usable events for {station}"

    meta = {
        "flood_dir": block.get("meanFloodDir"),
        "ebb_dir": block.get("meanEbbDir"),
        "station": station,
        "bin": bin_num,
    }
    return {"events": out, "meta": meta}, None


# ─────────────────────────────────────────────────────────────── tides ──

def fetch_tides(station: str, start: date, end: date):
    """NOAA CO-OPS high/low predictions. Returns [(date, 'HH:MM', feet, 'H'|'L')]."""
    url = (
        "https://api.tidesandcurrents.noaa.gov/api/prod/datagetter"
        "?product=predictions&application=tanglefoot"
        f"&begin_date={start:%Y%m%d}&end_date={end:%Y%m%d}"
        f"&datum=MLLW&station={station}&time_zone=lst_ldt"
        "&units=english&interval=hilo&format=json"
    )
    try:
        payload = json.loads(_get(url, "application/json"))
    except SourceError as e:
        return None, f"NOAA tides unavailable ({e})"
    except json.JSONDecodeError:
        return None, "NOAA tides returned malformed JSON"

    if "predictions" not in payload:
        return None, f"NOAA tides returned no predictions ({payload.get('error', {}).get('message', 'unknown')})"

    out = []
    for p in payload["predictions"]:
        try:
            d, hm = p["t"].split(" ")
            out.append((d, hm[:5], round(float(p["v"]), 2), p["type"]))
        except (KeyError, ValueError):
            continue
    if not out:
        return None, "NOAA tides returned an empty series"
    return out, None


# ──────────────────────────────────────────────────────── zone forecast ──

PERIOD_RE = re.compile(r"^\.([A-Z][A-Z \.]*?)\.\.\.(.*)$")


def fetch_zone(zone: str = "pzz135"):
    """
    NWS coastal zone product. Returns {'issued': str, 'periods': [(name, text)]}.
    The product is plain text; periods look like:
        .TODAY...N wind around 5 kt. Waves around 2 ft or less.
    """
    url = f"https://tgftp.nws.noaa.gov/data/forecasts/marine/coastal/pz/{zone}.txt"
    try:
        raw = _get(url, "text/plain").decode("utf-8", "replace")
    except SourceError as e:
        return None, f"NWS zone forecast unavailable ({e})"

    issued = None
    m = re.search(r"^(\d{3,4}\s+(?:AM|PM)\s+[A-Z]{3}\s+\w{3}\s+\w{3}\s+\d{1,2}\s+\d{4})\s*$",
                  raw, re.M)
    if m:
        issued = m.group(1).strip()

    # The product carries its own live hazard headline, e.g.
    #   ...SMALL CRAFT ADVISORY IN EFFECT UNTIL 5 AM PDT TUESDAY...
    # That is NWS actually declaring conditions hazardous, which beats any
    # threshold this code could pick. Highest severity wins.
    hazard = None
    HAZ = [("hurricane force wind", 5), ("storm warning", 4), ("gale warning", 3),
           ("gale watch", 2), ("small craft advisory", 1)]
    best = 0
    for hl in re.findall(r"^\.{3}(.+?)\.{3}\s*$", raw, re.M) + \
             re.findall(r"^\*\s*(.+)$", raw, re.M):
        low = hl.lower()
        for name, rank in HAZ:
            if name in low and rank > best:
                best, hazard = rank, hl.strip()

    periods, name, buf = [], None, []
    for line in raw.splitlines():
        pm = PERIOD_RE.match(line)
        if pm:
            if name:
                periods.append((name, " ".join(buf).strip()))
            name, buf = pm.group(1).strip().rstrip("."), [pm.group(2).strip()]
        elif name and line.strip() and not line.startswith("$$"):
            buf.append(line.strip())
        elif line.startswith("$$") and name:
            periods.append((name, " ".join(buf).strip()))
            name, buf = None, []
    if name:
        periods.append((name, " ".join(buf).strip()))

    if not periods:
        return None, "NWS zone forecast had no parseable periods"
    return {"issued": issued, "periods": periods, "hazard": hazard,
            "hazard_rank": best}, None


def zone_wind_kt(text: str):
    """Pull the highest wind number out of a period's text, in knots."""
    nums = [int(n) for n in re.findall(r"(\d{1,2})\s*(?:to\s*\d{1,2}\s*)?kt", text)]
    nums += [int(n) for n in re.findall(r"to\s+(\d{1,2})\s*kt", text)]
    return max(nums) if nums else None


def zone_wave_ft(text: str):
    """Highest wave height mentioned, in feet."""
    nums = [int(n) for n in re.findall(r"(\d{1,2})\s*ft", text)]
    return max(nums) if nums else None


# ─────────────────────────────────────────────────────────────── model ──

def fetch_model(lat: float, lon: float):
    """
    MET Norway locationforecast 2.0. Returns
    {'updated': iso, 'steps': {iso_utc: {...}}} with every timestep keyed by its
    exact UTC timestamp, so nothing has to be inferred from ordering.
    """
    url = (
        "https://api.met.no/weatherapi/locationforecast/2.0/complete"
        f"?lat={lat:.4f}&lon={lon:.4f}"
    )
    try:
        payload = json.loads(_get(url, "application/json"))
    except SourceError as e:
        return None, f"MET Norway unavailable ({e})"
    except json.JSONDecodeError:
        return None, "MET Norway returned malformed JSON"

    try:
        series = payload["properties"]["timeseries"]
        updated = payload["properties"]["meta"]["updated_at"]
    except KeyError:
        return None, "MET Norway response missing expected structure"

    steps = {}
    for entry in series:
        t = entry["time"]
        det = entry.get("data", {}).get("instant", {}).get("details", {})
        nxt = entry.get("data", {})
        precip = symbol = None
        for horizon in ("next_1_hours", "next_6_hours", "next_12_hours"):
            blk = nxt.get(horizon)
            if blk:
                precip = blk.get("details", {}).get("precipitation_amount")
                symbol = blk.get("summary", {}).get("symbol_code")
                break
        steps[t] = {
            "temp_c": det.get("air_temperature"),
            "wind_ms": det.get("wind_speed"),
            "gust_ms": det.get("wind_speed_of_gust"),
            "wind_dir": det.get("wind_from_direction"),
            "cloud_pct": det.get("cloud_area_fraction"),
            "rh_pct": det.get("relative_humidity"),
            "precip_mm": precip,
            "symbol": symbol,
        }
    if not steps:
        return None, "MET Norway returned an empty timeseries"
    return {"updated": updated, "steps": steps}, None


# ───────────────────────────────────────────────────────── rule changes ──

def fetch_rule_feed():
    """
    WDFW emergency-rule RSS. Used only for change detection: the harvest table
    is human-verified config, and this tells you when to go re-verify it.
    Returns [(iso_date, title)].
    """
    url = "https://wdfw.wa.gov/fishing/regulations/emergency-rules/rss"
    try:
        raw = _get(url, "application/rss+xml").decode("utf-8", "replace")
    except SourceError as e:
        return None, f"WDFW rule feed unavailable ({e})"

    items = []
    for chunk in re.findall(r"<item>(.*?)</item>", raw, re.S)[:40]:
        t = re.search(r"<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>", chunk, re.S)
        d = re.search(r"<pubDate>(.*?)</pubDate>", chunk, re.S)
        lk = re.search(r"<link>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</link>", chunk, re.S)
        if t:
            # The link is what makes an alert actionable: a title tells you
            # something changed, the link tells you what.
            items.append(((d.group(1).strip() if d else ""), t.group(1).strip(),
                          (lk.group(1).strip() if lk else "")))
    if not items:
        return None, "WDFW rule feed had no items"
    return items, None


# Deliberately broad — better to flag a Puget-Sound-wide notice that turns out
# to be Area 7 than to miss the one that matters. "possession" is anchored to
# "Possession Sound" because bare "possession" matches "possession limit", which
# appears in half the titles WDFW publishes.
RELEVANT = re.compile(
    r"\b(marine area 8|area 8-1|area 8-2|possession sound|port susan|"
    r"port gardner|everett|snohomish|puget sound|crab|shrimp|shellfish|"
    r"halibut)\b", re.I)


def _rfc822(s):
    """RSS pubDate -> date, or None. Tolerates the several shapes WDFW emits."""
    if not s:
        return None
    s = re.sub(r"\s*\([^)]*\)\s*$", "", s.strip())      # drop "(PDT)"
    for fmt in ("%a, %d %b %Y %H:%M:%S %z", "%a, %d %b %Y %H:%M:%S %Z",
                "%a, %d %b %Y %H:%M:%S", "%a, %d %b %Y", "%d %b %Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def parse_checked(s):
    """harvest.json 'checked' -> date, or None."""
    if not s:
        return None
    for fmt in ("%d %b %Y", "%Y-%m-%d", "%b %d %Y"):
        try:
            return datetime.strptime(s.strip(), fmt).date()
        except ValueError:
            continue
    return None


def _unpack(it):
    """Feed items are (date, title) or (date, title, link) — tolerate both."""
    if len(it) >= 3:
        return it[0], it[1], it[2]
    return it[0], it[1], ""


def relevant_rules(items, since_titles, since_date=None, pattern=None):
    """
    Feed items that mention this water AND postdate the last hand-verification.

    The date test is what makes the banner meaningful. Relying on a manually
    maintained seen-list meant the list stayed empty, every matching item
    stayed "new" forever, and the warning above the regulations table was
    permanently on — which is the same as not having one.

    An item published before the table was last checked by hand is already
    accounted for, whatever it says.
    """
    rx = pattern if pattern is not None else RELEVANT
    if isinstance(rx, str):
        try:
            rx = re.compile(rx, re.I)
        except re.error:
            rx = RELEVANT
    out = []
    for it in items:
        d, t, link = _unpack(it)
        if t in since_titles:
            continue
        if not rx.search(t):
            continue
        if since_date is not None:
            pub = _rfc822(d)
            if pub is not None and pub <= since_date:
                continue
        out.append((d, t, link))
    return out


def recent_rules(items, pattern=None, limit=6):
    """
    Every feed item matching this area, newest first, regardless of age.

    Distinct from relevant_rules, which only surfaces items NEWER than the last
    hand-verification and drives the "go re-check the table" banner. This one is
    the standing list a reader wants: what has WDFW said about this water lately.
    """
    rx = pattern if pattern is not None else RELEVANT
    if isinstance(rx, str):
        try:
            rx = re.compile(rx, re.I)
        except re.error:
            rx = RELEVANT
    out = [(_rfc822(d), d, t, link) for d, t, link in map(_unpack, items) if rx.search(t)]
    out.sort(key=lambda x: (x[0] is not None, x[0]), reverse=True)
    return [(d, t, link) for _, d, t, link in out[:limit]]


# ───────────────────────────────────────────────────────── creel reports ──

CREEL_URL = ("https://wdfw.wa.gov/fishing/reports/creel/puget-annual/export"
             "?sample_date=&ramp=&catch_area=&page=&_format=csv")

# The columns we rely on, exactly as WDFW writes them. If this header changes,
# the parse is wrong in ways that would be invisible — a column shifted by one
# turns coho into chum — so a mismatch means no section rather than a guess.
CREEL_COLS = ["Sample date", "Ramp/site", "Catch area",
              "# Interviews (Boat or Shore)", "Anglers"]
CREEL_FISH = ["Chinook", "Coho", "Chum", "Pink", "Sockeye", "Lingcod", "Halibut"]


def _clean_ramp(name):
    """
    WDFW carries a site's history in its name — "Everett Ramp (formerly Norton
    Street Ramp (2010))". That matters in their database and not at all to
    somebody deciding where to launch, so the parenthetical is dropped.
    """
    i = name.lower().find("(formerly")
    return (name[:i].strip() if i > 0 else name).strip()


def fetch_creel(area_match=None, days=45, limit_ramps=8):
    """
    WDFW dockside creel sampling, grouped by ramp for one marine area.

    area_match is a substring of the "Catch area" column, e.g. "Area 8-2", or a
    list of them. A list is how a marine area picks up its own terminal
    fisheries: WDFW files the Tulalip Bubble and the Snohomish River mouth
    under their own names, not under "Area 8-2", and a page for 8-2 that leaves
    them out is missing the water people actually fish. A row is counted once
    however many entries it matches.

    Returns (data, note) like every fetcher here.

    Filtering is done on the area column rather than the endpoint's catch_area
    parameter because that parameter takes an internal id nobody publishes, and
    a wrong id returns a plausible-looking page of the wrong water.
    """
    if not area_match:
        return None, None
    wanted = [area_match] if isinstance(area_match, str) else list(area_match)
    wanted = [w.lower() for w in wanted if w]
    if not wanted:
        return None, None
    try:
        raw = _get(CREEL_URL, "text/csv").decode("utf-8", "replace")
    except SourceError as e:
        return None, f"WDFW creel reports unavailable ({e})"

    import csv as _csv
    import io as _io
    rdr = _csv.reader(_io.StringIO(raw))
    try:
        header = next(rdr)
    except StopIteration:
        return None, "WDFW creel export was empty"

    header = [h.strip() for h in header]
    missing = [c for c in CREEL_COLS if c not in header]
    if missing:
        return None, ("WDFW creel export changed shape (missing "
                      + ", ".join(missing) + ") — not guessing at the columns")
    idx = {c: header.index(c) for c in header}

    cutoff = date.today() - timedelta(days=days)
    rows, newest = [], None
    for r in rdr:
        if len(r) < len(header):
            continue
        col = r[idx["Catch area"]].lower()
        if not any(w in col for w in wanted):
            continue
        try:
            d = datetime.strptime(r[idx["Sample date"]].strip(), "%b %d, %Y").date()
        except ValueError:
            continue
        newest = d if newest is None or d > newest else newest
        if d < cutoff:
            continue
        def num(col):
            try:
                return float(r[idx[col]]) if col in idx and r[idx[col]] != "" else 0.0
            except ValueError:
                return 0.0
        rows.append({"date": d, "ramp": _clean_ramp(r[idx["Ramp/site"]]),
                     "anglers": num("Anglers"),
                     "interviews": num("# Interviews (Boat or Shore)"),
                     "fish": {f: num(f) for f in CREEL_FISH if f in idx}})

    if not rows:
        return ({"ramps": [], "newest": newest, "window": days,
                 "area": area_match, "sampled": 0}, None)

    by_ramp = {}
    for r in rows:
        g = by_ramp.setdefault(r["ramp"], {"ramp": r["ramp"], "anglers": 0.0,
                                           "trips": 0, "last": r["date"],
                                           "fish": {f: 0.0 for f in CREEL_FISH}})
        g["anglers"] += r["anglers"]
        g["trips"] += 1
        g["last"] = max(g["last"], r["date"])
        for f, v in r["fish"].items():
            g["fish"][f] = g["fish"].get(f, 0.0) + v

    out = sorted(by_ramp.values(), key=lambda g: (-g["anglers"], g["ramp"]))[:limit_ramps]
    for g in out:
        total = sum(g["fish"].values())
        g["total"] = total
        g["per_angler"] = round(total / g["anglers"], 2) if g["anglers"] else 0.0
    return ({"ramps": out, "newest": newest, "window": days,
             "area": area_match, "sampled": len(by_ramp)}, None)
