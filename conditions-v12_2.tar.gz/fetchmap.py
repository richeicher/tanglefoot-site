#!/usr/bin/env python3
"""
Fetch real marine-area boundaries from WDFW and reduce them to a drawable map.

    fetchmap.py            fetch, simplify, write map.json
    fetchmap.py --show     report what it got, write nothing

The polygons come from WDFW's own GIS service:
  geodataservices.wdfw.wa.gov/arcgis/rest/services/ApplicationServices/
  Marine_Areas/MapServer/2   (Marine Area Boundaries)

This is deliberately NOT hand-drawn. A marine-area map is a map of regulatory
boundaries: someone deciding whether they are in 8-1 or 8-2 is deciding which
rules apply to them. An approximated line is a wrong answer to that question,
so if this fetch fails there is simply no map.

Output is a plain projected polygon set — no geometry library needed at build
time, and no network needed when the pages are generated.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "map.json")
UA = "tanglefoot-conditions/1.0 (+https://tanglefoot.dev)"

SERVICE = ("https://geodataservices.wdfw.wa.gov/arcgis/rest/services/"
           "ApplicationServices/Marine_Areas/MapServer/2/query")

# Only the areas the site covers. The map should show what it can link to.
WANT = {"7": "7", "8-1": "8-1", "8-2": "8-2", "9": "9", "10": "10", "12": "12"}


def get(url, timeout=120):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def fields():
    """What the layer calls its columns — never assume a schema."""
    d = get(SERVICE.rsplit("/", 1)[0] + "?f=pjson")
    return [f["name"] for f in d.get("fields", [])], d.get("name", "")


def fetch():
    q = urllib.parse.urlencode({
        "where": "1=1", "outFields": "*", "returnGeometry": "true",
        "outSR": "4326", "f": "geojson",
    })
    return get(f"{SERVICE}?{q}")


def area_key(props):
    """Find whatever field holds the marine-area label, tolerantly."""
    for k, v in props.items():
        if v is None:
            continue
        s = str(v).strip()
        if s in WANT:
            return WANT[s]
        lk = k.lower()
        if ("area" in lk or "marine" in lk) and s.replace("-", "").isalnum():
            s2 = s.upper().replace("MARINE AREA", "").strip()
            if s2 in WANT:
                return WANT[s2]
    return None


def rings_of(geom):
    if not geom:
        return []
    t, c = geom.get("type"), geom.get("coordinates") or []
    if t == "Polygon":
        return [c[0]] if c else []
    if t == "MultiPolygon":
        return [p[0] for p in c if p]
    return []


def simplify(ring, tol):
    """Ramer-Douglas-Peucker. Keeps shape, drops the thousands of points that
    make an inline SVG bigger than the page it sits on."""
    if len(ring) < 3:
        return ring
    def d(p, a, b):
        if a == b:
            return math.hypot(p[0] - a[0], p[1] - a[1])
        t = max(0, min(1, (((p[0]-a[0])*(b[0]-a[0]) + (p[1]-a[1])*(b[1]-a[1]))
                           / ((b[0]-a[0])**2 + (b[1]-a[1])**2))))
        return math.hypot(p[0] - (a[0]+t*(b[0]-a[0])), p[1] - (a[1]+t*(b[1]-a[1])))
    dmax, idx = 0, 0
    for i in range(1, len(ring) - 1):
        dd = d(ring[i], ring[0], ring[-1])
        if dd > dmax:
            dmax, idx = dd, i
    if dmax > tol:
        return simplify(ring[:idx+1], tol)[:-1] + simplify(ring[idx:], tol)
    return [ring[0], ring[-1]]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--show", action="store_true")
    ap.add_argument("--tol", type=float, default=0.004, help="simplify tolerance, degrees")
    args = ap.parse_args()

    try:
        names, layer = fields()
        print(f"layer: {layer}")
        print(f"fields: {', '.join(names)}")
    except Exception as e:
        print(f"could not read the layer schema: {e}")
        return 1

    try:
        gj = fetch()
    except Exception as e:
        print(f"fetch failed: {e}")
        return 1

    feats = gj.get("features", [])
    print(f"{len(feats)} feature(s) returned")

    areas, unmatched = {}, []
    for f in feats:
        props = f.get("properties") or {}
        key = area_key(props)
        if not key:
            unmatched.append({k: v for k, v in list(props.items())[:4]})
            continue
        for ring in rings_of(f.get("geometry")):
            if len(ring) < 4:
                continue
            s = simplify([(round(x, 5), round(y, 5)) for x, y in ring], args.tol)
            if len(s) >= 4:
                areas.setdefault(key, []).append(s)

    for k in sorted(areas):
        pts = sum(len(r) for r in areas[k])
        print(f"  area {k:<4} {len(areas[k])} ring(s), {pts} points after simplify")
    missing = [k for k in WANT.values() if k not in areas]
    if missing:
        print(f"  ! no geometry matched for: {', '.join(missing)}")
    if unmatched and not areas:
        print("  sample of unmatched properties (to find the right field):")
        for u in unmatched[:3]:
            print("   ", u)

    if args.show:
        return 0
    if not areas:
        print("REFUSED: nothing matched — not writing a map rather than guessing")
        return 1

    lons = [p[0] for rs in areas.values() for r in rs for p in r]
    lats = [p[1] for rs in areas.values() for r in rs for p in r]
    doc = {"source": "WDFW Marine Area Boundaries (geodataservices.wdfw.wa.gov)",
           "bbox": [min(lons), min(lats), max(lons), max(lats)],
           "areas": {k: v for k, v in areas.items()}}
    with open(OUT, "w") as fh:
        json.dump(doc, fh, separators=(",", ":"))
    print(f"wrote {OUT} ({os.path.getsize(OUT)} bytes, {len(areas)} areas)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
