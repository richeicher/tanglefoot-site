# conditions generator — install

This replaces the git-pull deploy. The box now builds the page itself from the
source APIs, so nothing has to be pushed to it and this Claude session drops out
of the daily loop entirely.

```
06:00  systemd timer fires
       → fetch NOAA tides, NWS PZZ135, MET Norway, WDFW rule feed
       → score, render, validate
       → atomic swap into /var/www/tanglefoot/index.html
```

No credentials anywhere. No GitHub. No conduit.

## Install

Copy the folder to the box and put it in place:

```bash
sudo mkdir -p /opt/conditions
sudo tar xzf conditions.tar.gz -C /opt/conditions
sudo chown -R root:root /opt/conditions
```

Python 3.11+ with `zoneinfo` is all it needs — no pip packages. Ubuntu 24.04 has
it. If timezone lookups fail, `sudo apt-get install -y tzdata`.

## Test before trusting it

**1. Can it reach everything?**

```bash
sudo python3 /opt/conditions/generate.py --check
```

Prints each source and what it got. Exit 0 means all four are healthy.

**2. Does it build a sane page?**

```bash
sudo python3 /opt/conditions/generate.py --dry-run
```

Writes a uniquely-named preview file and touches nothing else. The run prints
the path it used on the last line — copy that file somewhere you can look at it.

**3. For real:**

```bash
sudo python3 /opt/conditions/generate.py
curl -s localhost | grep -c "Wind through the day"   # expect 14
```

## Point the timer at it

```bash
sudo tee /etc/systemd/system/tanglefoot-deploy.service >/dev/null <<'UNIT'
[Unit]
Description=Build and publish the conditions page
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/bin/python3 /opt/conditions/generate.py
UNIT

sudo sed -i 's/06:20:00/06:00:00/' /etc/systemd/system/tanglefoot-deploy.timer
sudo systemctl daemon-reload
sudo systemctl restart tanglefoot-deploy.timer
systemctl list-timers | grep tanglefoot
```

The old `/usr/local/bin/tanglefoot-deploy` script and the `/srv/tanglefoot/repo`
clone are now unused. Leave them or delete them; nothing references them.

## What it refuses to do

The run exits without touching the live page if:

- the built page is under 20,000 bytes
- the page title (from `config.json`) isn't in it
- it doesn't contain exactly 14 day cards
- fewer than three days have any forecast behind them
- neither tides nor the model could be fetched (exit 2)

A degraded source doesn't stop the run — it publishes what it has and prints a
"Source degraded" note into the page's own notes list, so the page tells its
reader what it's missing rather than hiding it.

The previous page is kept at `/var/www/tanglefoot/index.prev.html`. Rollback:

```bash
sudo cp /var/www/tanglefoot/index.prev.html /var/www/tanglefoot/index.html
```

## The two files you'll actually edit

**`config.json`** — station, coordinates, zone, your thresholds, the page title
and the output path. The title doubles as the publish guard, so renaming the
page is a one-field edit. Changing `wind_limit_kt` or `seas_limit_ft` re-scores every
day on the next run.

**`harvest.json`** — the seasons table. This is **verified by hand, not
scraped**, because getting a season wrong has consequences a broken scraper
shouldn't be allowed to cause. Update it when seasons change and bump
`"checked"`. Every run reads the WDFW rule feed and, if new items mention this
water, prints a banner above the table saying the table hasn't been updated for
them. That's the prompt to go look.

## Areas

Every area is one JSON file in `areas/`. The code is shared — a change to the
scoring, the layout or the prose lands on every area at once, which is the whole
point of the split.

Create them by lookup, not by hand:

```bash
sudo python3 /opt/conditions/newarea.py --list     # what's on offer
sudo python3 /opt/conditions/newarea.py --all      # create the ones you don't have
```

That discovers, per area, the NWS coastal zone that actually contains the point,
the nearest NOAA tide station, and a current station **that it has called and
confirmed works** — PUG1613 is the nearest station to Everett and returns
malformed predictions, so proximity alone is not enough.

Existing files are never overwritten without `--force`, so re-running it is safe.

Upgrading adds code, not config. An area created by an older version keeps that
version's shape, so a new feature reading a new key would do nothing on it.
`build_all.py` fills in missing keys automatically on every run — it only fills
blanks and never touches a value already set, including one you edited by hand.
To do it by itself:

```bash
sudo python3 /opt/conditions/newarea.py --all --backfill
```

Then build everything and the index over it:

```bash
sudo python3 /opt/conditions/build_all.py
```

One area failing doesn't stop the others and doesn't remove it from the index —
it shows as unavailable with the reason, because a missing row reads as "that
area doesn't exist", which is the worse lie.

### Fetch is not inherited

`fetch` weights sea state by the direction wind comes from, and it is local
geography. A new area ships with an empty table: neutral weighting, and the page
says nothing about fetch rather than claiming Possession Sound's coastline
applies to the San Juans. Fill it in as you learn the water.

### Dockside creel checks

`creel_area` on each area names the **"Catch area"** labels in WDFW's Puget
Sound creel export that belong to that water, and drives the "What people are
catching" section. The labels are taken verbatim from WDFW's own filter list at
<https://wdfw.wa.gov/fishing/reports/creel/puget-annual> — they are not derived
from the area number, and a wrong label returns a plausible-looking table of
somebody else's ramps.

It is a list because a marine area's terminal fisheries are filed under their
own names, not under the area: 8-2 claims `Area 8-2`, `Tulalip Terminal Area`
and `Snohomish River Mouth`. A row matching more than one label is counted once.
An area with no `creel_area` renders no section at all.

`home_ramp` is optional and just tags your own ramp in the table.

If WDFW renames a column in that export, the section stops and says which column
went missing rather than reading the wrong field. That is deliberate: fish
counts that are quietly wrong are worse than fish counts that are absent.

### Seasons

Every area has a season table now: `harvest.json` for 8-2, `harvest-<slug>.json`
for the rest. They are **not** equivalent.

`harvest.json` (8-2) is **verified by hand**. The others carry `"verified": false`
and render with a red DRAFT banner, a citation to the edition they were
transcribed from, and an explicit "do not rely on it". That flag is the whole
safety mechanism — the tables look identical otherwise, and a draft that quietly
claimed to be verified is the failure that costs a reader a citation.

To promote a draft once you have checked it against the live rules: set
`"verified": true`, update `"checked"` to the date you checked it, and the banner
becomes the normal hand-verified line that ages on its own.

`crab_slug` is separate from `wdfw_slug` because WDFW's crab pages use their own
slugs (`port-susaneverett-area-8-2`, not `ports-susan-gardner`). Each one was
confirmed by fetching it. An area with no `crab_slug` links WDFW's crab index
rather than a specific page that would 404.

## Tests

```bash
python3 /opt/conditions/test_offline.py
```

Runs the parsers against captured NOAA and NWS payloads, checks the sun and moon
math against known values, exercises every scoring rule, and builds and renders
a full page from a synthetic series. No network needed. Run it after any edit.

## Known weaknesses

- **The prose is assembled by rule**, not written. It's accurate but flatter
  than the hand-written version.
- **The zone-forecast parser is the brittle part.** It reads a plain-text NWS
  product with a regex. If NWS changes the format, the zone data drops out,
  the page says so in its notes, and it falls back to the model alone.
- **Creel sampling is uneven, and the page can only report what WDFW published.**
  A ramp with two checks in six weeks is a small sample, not a slow ramp, and
  the section says so. WDFW publishes on its own schedule and can run a week or
  more behind.
