"""
Render the page as static HTML.

The published version builds its tiles in JavaScript at load time. This one
emits finished markup with the tide charts already drawn as inline SVG, so the
page needs no script at all — faster, works with JS off, and indexable if the
multi-area idea ever happens.
"""

from __future__ import annotations

import html
import math
import os
from datetime import date, datetime, timedelta

import scoring as S

HERE = os.path.dirname(os.path.abspath(__file__))
THEME = open(os.path.join(HERE, "theme.html")).read()


def esc(s):
    return html.escape(str(s), quote=False) if s is not None else ""


# ───────────────────────────────────────────────────────────── tide svg ──

def _mins(hm):
    h, m = hm.split(":")
    return int(h) * 60 + int(m)


def _height_at(turn_list, minute):
    """Cosine interpolation between turning points, as the JS version did."""
    a = b = None
    for t in turn_list:
        if t[0] <= minute:
            a = t
        if t[0] >= minute and b is None:
            b = t
    if a is None:
        return b[1] if b else 0.0
    if b is None or b[0] == a[0]:
        return a[1]
    p = (minute - a[0]) / (b[0] - a[0])
    return (a[1] + b[1]) / 2 - ((b[1] - a[1]) / 2) * math.cos(math.pi * p)


def tide_svg(prev_turns, turns, next_turns, sunrise, sunset):
    """One day's tide curve, with neighbouring days as anchors so the ends aren't flat."""
    W, H = 300, 88
    PADL, PADR, PADT, PADB = 22, 6, 9, 14
    LO, HI = 0, 12

    flat = ([(_mins(t["hm"]) - 1440, t["v"]) for t in prev_turns]
            + [(_mins(t["hm"]), t["v"]) for t in turns]
            + [(_mins(t["hm"]) + 1440, t["v"]) for t in next_turns])
    flat.sort()
    if not flat:
        return '<svg viewBox="0 0 300 88" role="img" aria-label="no tide data"></svg>'

    def x(m):
        return PADL + (m / 1440) * (W - PADL - PADR)

    def y(v):
        return H - PADB - ((v - LO) / (HI - LO)) * (H - PADT - PADB)

    pts = [(x(m), y(_height_at(flat, m))) for m in range(0, 1441, 20)]
    line = "M" + " L".join(f"{px:.1f} {py:.1f}" for px, py in pts)
    area = f"{line} L{x(1440):.1f} {H - PADB} L{x(0):.1f} {H - PADB} Z"

    band = ""
    if sunrise != "--:--" and sunset != "--:--":
        sx, ex = x(_mins(sunrise)), x(_mins(sunset))
        band = (f'<rect x="{sx:.1f}" y="{PADT}" width="{ex - sx:.1f}" '
                f'height="{H - PADT - PADB}" fill="var(--day-band)"/>')

    grid = ""
    for v in (0, 4, 8, 12):
        gy = y(v)
        grid += (f'<line x1="{PADL}" y1="{gy:.1f}" x2="{W - PADR}" y2="{gy:.1f}" '
                 f'stroke="var(--rule)" stroke-width=".6"/>'
                 f'<text x="{PADL - 4}" y="{gy + 3:.1f}" text-anchor="end" '
                 f'font-family="IBM Plex Mono,monospace" font-size="7.5" '
                 f'fill="var(--ink-faint)">{v}</text>')

    marks = "".join(
        f'<circle cx="{x(_mins(t["hm"])):.1f}" cy="{y(t["v"]):.1f}" r="2.6" '
        f'fill="var(--surface)" stroke="var(--tide-line)" stroke-width="1.5"/>'
        for t in turns)

    return (f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Tide curve">'
            f'{band}{grid}'
            f'<path d="{area}" fill="var(--tide-fill)" opacity=".75"/>'
            f'<path d="{line}" fill="none" stroke="var(--tide-line)" '
            f'stroke-width="1.8" stroke-linejoin="round"/>{marks}</svg>')


def _share_tags(cfg):
    """
    Open Graph and Twitter tags. Without these a link pasted into Facebook shows
    as a bare URL with no title or description, which reads as spam and gets
    scrolled past. The share title carries the area, so nobody in a
    Puget-Sound-wide group mistakes one area's page for their own water.
    """
    url = cfg.get("canonical", "")
    area = cfg.get("area", "")
    t = f"{cfg['title']}{' &middot; ' + area if area else ''}"
    tags = [
        f'<meta property="og:title" content="{esc(t)}">',
        f'<meta property="og:description" content="{esc(cfg["description"])}">',
        '<meta property="og:type" content="website">',
        '<meta name="twitter:card" content="summary">',
        f'<meta name="twitter:title" content="{esc(t)}">',
        f'<meta name="twitter:description" content="{esc(cfg["description"])}">',
    ]
    if url:
        tags.append(f'<meta property="og:url" content="{esc(url)}">')
        tags.append(f'<link rel="canonical" href="{esc(url)}">')
    return "\n".join(tags)


# ───────────────────────────────────────────────────────────── wind svg ──

def wind_svg(series, limit, scale, sunrise, sunset, zone_kt=None):
    """
    Wind through the day against the limit line.

    `series` is [(minutes_past_midnight, kt)] from the model. Past day three the
    model is 6-hourly, so this is drawn as points joined by straight lines and
    the markers are left visible — a smooth curve there would imply resolution
    the data does not have.

    The zone forecast, when it disagrees, is drawn as its own dashed line rather
    than blended in. The two are different products and the reader should be
    able to see them disagree.
    """
    # The viewBox is wide on purpose. This panel spans the full card, and a
    # 300-unit box inside a 600px element letterboxes: the browser fits by
    # height and paints the chart centered at 300px, leaving the axis below it
    # spanning a width the chart doesn't occupy.
    W, H = 600, 74
    PADL, PADR, PADT, PADB = 30, 10, 8, 13
    if not series:
        return ""

    def x(m):
        return PADL + (max(0, min(1440, m)) / 1440) * (W - PADL - PADR)

    def y(v):
        v = max(0.0, min(scale, v))
        return H - PADB - (v / scale) * (H - PADT - PADB)

    band = ""
    if sunrise != "--:--" and sunset != "--:--":
        sx, ex = x(_mins(sunrise)), x(_mins(sunset))
        band = (f'<rect x="{sx:.1f}" y="{PADT}" width="{ex - sx:.1f}" '
                f'height="{H - PADT - PADB}" fill="var(--day-band)"/>')

    grid = ""
    for v in (0, scale / 2, scale):
        gy = y(v)
        grid += (f'<line x1="{PADL}" y1="{gy:.1f}" x2="{W - PADR}" y2="{gy:.1f}" '
                 f'stroke="var(--rule)" stroke-width=".6"/>'
                 f'<text x="{PADL - 4}" y="{gy + 3:.1f}" text-anchor="end" '
                 f'font-family="IBM Plex Mono,monospace" font-size="9" '
                 f'fill="var(--ink-faint)">{v:g}</text>')

    ly = y(limit)
    limit_line = (f'<line x1="{PADL}" y1="{ly:.1f}" x2="{W - PADR}" y2="{ly:.1f}" '
                  f'stroke="var(--bad)" stroke-width="1.1" stroke-dasharray="4 3"/>'
                  f'<text x="{W - PADR}" y="{ly - 3:.1f}" text-anchor="end" '
                  f'font-family="IBM Plex Mono,monospace" font-size="9" '
                  f'fill="var(--bad)">suggested limit {limit:g}</text>')

    pts = [(x(m), y(v)) for m, v in series]
    line = "M" + " L".join(f"{px:.1f} {py:.1f}" for px, py in pts)
    area = (f"{line} L{pts[-1][0]:.1f} {H - PADB} L{pts[0][0]:.1f} {H - PADB} Z"
            if len(pts) > 1 else "")
    fill = (f'<path d="{area}" fill="var(--tide-fill)" opacity=".5"/>' if area else "")

    marks = "".join(
        f'<circle cx="{px:.1f}" cy="{py:.1f}" r="2" fill="var(--surface)" '
        f'stroke="var(--tide-line)" stroke-width="1.2"/>' for px, py in pts)

    zone = ""
    if zone_kt is not None:
        zy = y(float(zone_kt))
        zone = (f'<line x1="{PADL}" y1="{zy:.1f}" x2="{W - PADR}" y2="{zy:.1f}" '
                f'stroke="var(--accent)" stroke-width="1" stroke-dasharray="2 3" '
                f'opacity=".85"/>'
                f'<text x="{PADL + 2}" y="{zy - 3:.1f}" '
                f'font-family="IBM Plex Mono,monospace" font-size="9" '
                f'fill="var(--accent)">NWS {float(zone_kt):g}</text>')

    return (f'<svg viewBox="0 0 {W} {H}" role="img" '
            f'aria-label="Wind through the day against the suggested {limit:g} knot limit">'
            f'{band}{grid}{fill}'
            f'<path d="{line}" fill="none" stroke="var(--tide-line)" '
            f'stroke-width="1.6" stroke-linejoin="round"/>'
            f'{marks}{limit_line}{zone}</svg>')


# ─────────────────────────────────────────────────────────────── icons ──
#
# Inline SVG, currentColor, 16px. No external requests — the page is
# self-contained and must stay that way.

_ICON = {
    "sun": '<circle cx="8" cy="8" r="3.4"/><g stroke-linecap="round">'
           '<path d="M8 .8v2M8 13.2v2M.8 8h2M13.2 8h2'
           'M2.9 2.9l1.4 1.4M11.7 11.7l1.4 1.4M13.1 2.9l-1.4 1.4M4.3 11.7l-1.4 1.4"/></g>',
    "moon": '<path d="M13 9.8A5.6 5.6 0 0 1 6.2 3a5.8 5.8 0 1 0 6.8 6.8z"/>',
    "partsun": '<circle cx="5.6" cy="5.6" r="2.5"/><g stroke-linecap="round">'
               '<path d="M5.6 .9v1.6M.9 5.6h1.6M2.3 2.3l1.1 1.1M8.9 2.3L7.8 3.4"/></g>'
               '<path d="M5.4 13.6a2.6 2.6 0 0 1 .3-5.2 3.5 3.5 0 0 1 6.6 1 2.1 2.1 0 0 1-.4 4.2z"/>',
    "cloud": '<path d="M4.6 13.2a3 3 0 0 1 .4-6 4 4 0 0 1 7.6 1.2 2.4 2.4 0 0 1-.5 4.8z"/>',
    "rain": '<path d="M4.6 10.4a3 3 0 0 1 .4-6 4 4 0 0 1 7.6 1.2 2.4 2.4 0 0 1-.5 4.8z"/>'
            '<g stroke-linecap="round"><path d="M5.4 12.2l-.9 2.4M8.2 12.2l-.9 2.4'
            'M11 12.2l-.9 2.4"/></g>',
    "showers": '<path d="M4.6 10.4a3 3 0 0 1 .4-6 4 4 0 0 1 7.6 1.2 2.4 2.4 0 0 1-.5 4.8z"/>'
               '<g stroke-linecap="round"><path d="M6.2 12.4l-.7 1.8M9.8 12.4l-.7 1.8"/></g>',
    "heavyrain": '<path d="M4.6 9.6a3 3 0 0 1 .4-6 4 4 0 0 1 7.6 1.2 2.4 2.4 0 0 1-.5 4.8z"/>'
                 '<g stroke-linecap="round"><path d="M4.4 11.2l-1 3.4M7.2 11.2l-1 3.4'
                 'M10 11.2l-1 3.4M12.8 11.2l-1 3.4"/></g>',
    "snow": '<path d="M4.6 10a3 3 0 0 1 .4-6 4 4 0 0 1 7.6 1.2 2.4 2.4 0 0 1-.5 4.8z"/>'
            '<g stroke-linecap="round"><path d="M5.6 12.4v2M4.7 12.9l1.8 1M6.5 12.9l-1.8 1'
            'M10.4 12.4v2M9.5 12.9l1.8 1M11.3 12.9l-1.8 1"/></g>',
    "sleet": '<path d="M4.6 10a3 3 0 0 1 .4-6 4 4 0 0 1 7.6 1.2 2.4 2.4 0 0 1-.5 4.8z"/>'
             '<g stroke-linecap="round"><path d="M5.6 12.2l-.8 2.2M10 12.2v2'
             'M9.2 12.7l1.6.9M10.8 12.7l-1.6.9"/></g>',
    "fog": '<g stroke-linecap="round"><path d="M2 5.5h12M3.5 8.5h9M2 11.5h12"/></g>',
}

# symbol_code stem -> icon. The model's own symbol is preferred over the phrase
# because it already knows about day and night.
_SYM = {
    "clearsky": "sun", "fair": "partsun", "partlycloudy": "partsun",
    "cloudy": "cloud", "fog": "fog",
    "lightrain": "showers", "rain": "rain", "heavyrain": "heavyrain",
    "lightrainshowers": "showers", "rainshowers": "rain",
    "heavyrainshowers": "heavyrain",
    "lightsleet": "sleet", "sleet": "sleet", "heavysleet": "sleet",
    "lightsleetshowers": "sleet", "sleetshowers": "sleet",
    "lightsnow": "snow", "snow": "snow", "heavysnow": "snow",
    "lightsnowshowers": "snow", "snowshowers": "snow",
}

_PHRASE = {
    "Clear": "sun", "Mostly clear": "partsun", "Partly cloudy": "partsun",
    "Overcast": "cloud", "Fog": "fog", "Light rain": "showers", "Rain": "rain",
    "Heavy rain": "heavyrain", "Light showers": "showers", "Showers": "rain",
    "Heavy showers": "heavyrain", "Sleet": "sleet", "Snow": "snow",
    "Light snow": "snow", "Snow showers": "snow",
}


def icon(symbol, phrase):
    """16px inline SVG for a sky condition, or nothing if we can't name it."""
    key = None
    if symbol:
        stem = symbol.split("_")[0]
        key = _SYM.get(stem)
        # a clear or fair night is a moon, not a sun
        if key in ("sun", "partsun") and symbol.endswith("_night"):
            key = "moon"
    if not key:
        key = _PHRASE.get(phrase)
    if not key or key not in _ICON:
        return ""
    return (f'<svg class="ico ico-{key}" viewBox="0 0 16 16" width="16" height="16" '
            f'aria-hidden="true" fill="none" stroke="currentColor" '
            f'stroke-width="1.3">{_ICON[key]}</svg>')


# ──────────────────────────────────────────────────────────── day cards ──

def _wind_trace(day, lim, scale):
    """The wind-through-the-day panel, or nothing when there is too little to plot."""
    series = day.get("wind_series") or []
    if len(series) < 2:
        return ""
    sun = day["sun"].split(" &ndash; ")
    svg = wind_svg(series, lim, scale, sun[0],
                   sun[1] if len(sun) > 1 else "--:--", day.get("zone_kt"))
    if not svg:
        return ""
    n = len(series)
    res = "hourly" if n >= 12 else f"{n} points, 6-hourly"
    return (f'<div class="wtrace">'
            f'<div class="wtrace-top"><span>Wind through the day</span>'
            f'<em>model, {res}</em></div>{svg}'
            f'<div class="wtrace-axis"><span>00</span><span>06</span><span>12</span>'
            f'<span>18</span><span>24</span></div></div>')


def day_card(day, prev_turns, next_turns, open_on):
    cls = "bc is-" + day["rating"] + (" is-best" if day.get("best") else "")

    if day["tilt"]:
        left = (
            '<div class="hgrid tilt">'
            '<div class="hcell"><div class="hlab">Temperature</div>'
            '<div class="htemp sm">No forecast</div><div class="hsky">Beyond model range</div></div>'
            '<div class="hcell"><div class="hlab">Precipitation</div>'
            '<div class="htemp sm">No forecast</div><div class="hsky">Beyond model range</div></div>'
            '<div class="hcell empty"><div class="hlab">Wind &amp; sea</div>'
            '<div class="htemp sm">No forecast</div><div class="hsky">Beyond model range</div></div>'
            '</div>'
            '<div class="nowind">No wind or sea-state guidance exists at this range &mdash; '
            'nothing here is a forecast you can plan a departure on. The tide, sun and moon '
            'beside it are exact.</div>')
        head_right = '<span class="tagline">' + esc(day["tag"]) + "</span>"
    else:
        cells = ""
        for c in day["cols"]:
            if c["f"] is None:
                cells += (f'<div class="hcell empty"><div class="hlab">{c["label"]}</div>'
                          f'<div class="htemp sm">&mdash;</div>'
                          f'<div class="hsky">{c["sky"]}</div></div>')
            else:
                arrow = S.ARROW.get(c["dir"], "&middot;")
                gust = ""
                if c.get("gust") is not None and c["kt"] is not None \
                        and c["gust"] - c["kt"] >= 2:
                    gust = f' <span class="gst">g{c["gust"]:.0f}</span>'
                cur = ""
                if c.get("cur") is not None:
                    v = c["cur"]
                    if abs(v) < 0.05:
                        cur = '<div class="hcur">slack</div>'
                    else:
                        cur = (f'<div class="hcur">{"flood" if v > 0 else "ebb"} '
                               f'{abs(v):.1f} kt</div>')
                ic = icon(c.get("sym"), c.get("sky"))
                cells += (f'<div class="hcell"><div class="hlab">{c["label"]}</div>'
                          f'<div class="htemp">{ic}<span>{c["f"]}&deg;</span></div>'
                          f'<div class="hwind"><span class="arr">{arrow}</span> '
                          f'{c["dir"] or ""} {c["kt"]:.1f} kt{gust}</div>'
                          f'<div class="hsky">{c["sky"]}</div>{cur}</div>')
        pk = day["peak_kt"] or 0
        lim = float(day.get("wind_limit", 10))
        scale = float(day.get("wind_scale", 12))
        pct = min(100, pk / scale * 100)
        over = " over" if pk > lim else ""
        gpct = None
        if day.get("gust_kt") is not None:
            gpct = min(100, day["gust_kt"] / scale * 100)
        gmark = (f'<span class="gmark" style="left:{gpct:.1f}%"></span>' if gpct else "")
        gtext = (f' &middot; gusts {day["gust_kt"]:.0f} kt'
                 if day.get("gust_kt") is not None else "")
        ncols = max(1, len(day["cols"]))
        left = (f'<div class="hgrid" style="grid-template-columns:repeat({ncols},1fr)">{cells}</div>'
                f'<div class="wbar-wrap">'
                f'<div class="wbar-top"><span>Peak wind vs. suggested limit</span>'
                f'<em>{pk:.1f} kt at {day["peak_at"]}{gtext} &middot; suggested limit {lim:g} kt</em></div>'
                f'<div class="wbar"><span class="fill{over}" style="width:{pct:.1f}%"></span>'
                f'{gmark}'
                f'<span class="lim" style="left:{lim / scale * 100:.1f}%"></span></div>'
                f'<div class="wbar-scale"><span>0</span><span>{scale / 3:.0f}</span>'
                f'<span>{scale * 2 / 3:.0f}</span>'
                f'<span>{scale:.0f} kt</span></div>'
                + _wind_trace(day, lim, scale)
                + f'</div>')
        gh = (f' <span class="gsth">g{day["gust_kt"]:.0f}</span>'
              if day.get("gust_kt") is not None else "")
        head_right = (f'<span class="bc-peak">peak <b>{pk:.1f} kt</b>{gh} '
                      f'{day["peak_dir"]} &middot; {day["sea"]}</span>')

    turns_html = "".join(
        f'<div class="tt"><div class="tt-k">{"High" if t["k"] == "H" else "Low"}</div>'
        f'<div class="tt-t">{t["hm"]}</div>'
        f'<div class="tt-v">{t["v"]:.1f} ft</div></div>'
        for t in day["turns"])

    cur_html = ""
    if day.get("currents"):
        chips = "".join(
            f'<div class="ct ct-{kind}"><div class="ct-k">'
            f'{"Slack" if kind == "slack" else kind.title()}</div>'
            f'<div class="ct-t">{t:%H:%M}</div>'
            f'<div class="ct-v">{"&mdash;" if kind == "slack" else f"{abs(v):.2f}"}</div></div>'
            for t, v, kind in day["currents"])
        cur_html = (f'<div class="cp-top"><h4>Current</h4>'
                    f'<span>max {day["cur_max"]:.2f} kt</span></div>'
                    f'<div class="cp-turns">{chips}</div>') if day.get("cur_max") else ""

    sun_parts = day["sun"].split(" &ndash; ")
    svg = tide_svg(prev_turns, day["turns"], next_turns,
                   sun_parts[0], sun_parts[1] if len(sun_parts) > 1 else "--:--")

    rain_meta = (f'<div>Rain &nbsp;<span>{day["rain_in"]:.2f} in</span></div>'
                 if not day["tilt"] else
                 '<div>Precip tilt &nbsp;<span>No forecast</span></div>')

    # Why this day landed where it did, and which way the sea has room to build.
    WHY = {
        "seas": "Seas over limit",
        "seas and wind": "Wind and seas over limit",
        "wind": "Wind over limit",
        "rain": "Too wet",
        "gusts": "Gusts over limit",
        "gusty": "Gusty",
        "showers": "Showers",
        "near limit": "Close to wind limit",
    }
    why = WHY.get(day.get("reason"))
    why_meta = (f'<div>Limiter &nbsp;<span>{why}</span></div>' if why and not day["tilt"]
                else ('<div>Limiter &nbsp;<span>Nothing &mdash; clean</span></div>'
                      if not day["tilt"] else ""))
    fetch_meta = (f'<div>Fetch &nbsp;<span>{day["fetch"]}</span></div>'
                  if day.get("fetch") and not day["tilt"] else "")
    open_html = (f'<div class="open-on">Open &nbsp;<span>{open_on}</span></div>'
                 if open_on else "")

    return f"""
    <article class="{cls}" id="d{day['key'].replace('-', '')}">
      <div class="bc-head">
        <span class="bc-dow">{day['dow']}</span>
        <span class="bc-date">{day['date_label']}{' &middot; today' if day['today'] else ''}</span>
        <span class="chip {day['rating']}">{day['label']}</span>
        <span class="spacer"></span>
        {head_right}
      </div>
      <p class="bc-sum">{day['sum']}</p>
      <div class="bc-body">
        <div>{left}</div>
        <div class="tp">
          <div class="tp-top"><h4>Tide &middot; {day.get("station_name") or "local"}</h4><span>range {day['range']}</span></div>
          {svg}
          <div class="tp-axis"><span>00</span><span>06</span><span>12</span><span>18</span><span>24</span></div>
          <div class="tp-turns">{turns_html}</div>
          {cur_html}
        </div>
      </div>
      <div class="bc-meta">
        <div>Sun &nbsp;<span>{day['sun']}</span></div>
        <div>Daylight &nbsp;<span>{day['daylight']}</span></div>
        <div>Moon &nbsp;<span>{day['moon']}</span></div>
        {rain_meta}
        {why_meta}
        {fetch_meta}
        {open_html}
      </div>
      {f'<p class="bc-win"><b>Best window</b>{day["win"]}</p>' if day.get("win") else ''}
      <p class="bc-note">{day['note']}</p>
    </article>"""


# ───────────────────────────────────────────────────────────── harvest ──

def _days_since(checked):
    """Days since the seasons table was hand-verified, or None if unparseable."""
    if not checked:
        return None
    for fmt in ("%d %b %Y", "%Y-%m-%d", "%b %d %Y"):
        try:
            return (date.today() - datetime.strptime(checked, fmt).date()).days
        except ValueError:
            continue
    return None


def harvest_section(harvest, checked, rule_alert, area="this area"):
    # Nothing to show -> nothing rendered, and crucially this is checked FIRST.
    # It used to sit further down, after the alert markup was built, so an area
    # with no seasons table still ran that code and died on it.
    if not harvest.get("pills") and not harvest.get("table"):
        return ""

    pills = ""
    for p in harvest["pills"]:
        note = p["note"]
        if p.get("to"):
            try:
                n = (datetime.strptime(p["to"], "%Y-%m-%d").date() - date.today()).days
                if n >= 0:
                    note += f"<br>closes in {n} day{'' if n == 1 else 's'}"
            except ValueError:
                pass
        pills += (f'<div class="hpill {p["state"]}"><b>{p["name"]}</b>'
                  f'<u>{p["head"]}</u><i>{note}</i></div>')

    rows = ""
    for r in harvest["table"]:
        rows += (f'<tr><td>{r["fishery"]}</td>'
                 f'<td class="st"><span class="st-tag {r["state"]}">{r["status"]}</span></td>'
                 f'<td class="mono">{r["season"]}</td>'
                 f'<td class="mono">{r["limit"]}</td>'
                 f'<td>{r["notes"]}</td></tr>')

    alert = ""
    if rule_alert:
        # Feed items are (date, title, link); they used to be (date, title).
        items = "".join(
            f'<li><a href="{esc(it[2])}">{esc(it[1])}</a></li>' if len(it) > 2 and it[2]
            else f"<li>{esc(it[1])}</li>"
            for it in rule_alert[:6])
        alert = (f'<p class="rnote"><b>New rule activity since this table was verified</b> '
                 f'&mdash; the WDFW feed has items that mention this water. The table below '
                 f'has <i>not</i> been updated for them; check before you go.<ul>{items}</ul></p>')

    # Regulations are the one thing on this page that can cost a reader a
    # citation. The verify line is always present, and it escalates on its own
    # once the hand-verified table starts going stale, so an unattended page
    # tells the truth about its own age instead of asserting last month's rules.
    # An unverified draft is a louder state than a stale one. The table exists
    # and is sourced, but nobody has checked it against the live regulations,
    # and the reader must not mistake it for the 8-2 table that has been.
    if harvest.get("verified") is False:
        src = harvest.get("source_url")
        cite = (f' Drafted from <a href="{esc(src)}">'
                f'{esc(harvest.get("source", "the published rules"))}</a>.'
                if src else "")
        stale_cls = " stale"
        stale_msg = ("<b>Draft &mdash; not verified by a human.</b> This table has not "
                     "been checked against the live regulations, and seasons change "
                     "in-season by emergency rule." + cite +
                     ' <a href="https://wdfw.wa.gov/fishing/regulations/rules-concise">'
                     "Confirm with WDFW</a> before you fish. Do not rely on it.")
        return _harvest_html(harvest, checked, rule_alert, area, stale_cls, stale_msg)

    age = _days_since(checked)
    if age is None:
        stale_cls, stale_msg = " warn", (
            "<b>Seasons not dated.</b> Confirm every rule with WDFW before you fish: "
            "<a href=\"https://wdfw.wa.gov/fishing/regulations/rules-concise\">"
            "wdfw.wa.gov fishing rules</a>.")
    elif age >= 10:
        stale_cls, stale_msg = " stale", (
            f"<b>These seasons were last checked by hand {age} days ago and may be out "
            f"of date.</b> WDFW changes rules mid-season by emergency order. "
            f"<a href=\"https://wdfw.wa.gov/fishing/regulations/rules-concise\">"
            f"Check the current rules</a> before you fish &mdash; do not rely on this table.")
    else:
        stale_cls, stale_msg = "", (
            "Checked by hand, not scraped. Rules change mid-season by emergency order "
            "&mdash; always confirm with "
            "<a href=\"https://wdfw.wa.gov/fishing/regulations/rules-concise\">WDFW</a> "
            "before you fish.")

    return _harvest_html(harvest, checked, rule_alert, area, stale_cls, stale_msg)


def _footer_html(footer):
    """
    footer is a list of paragraphs. One harvest file wrote it as a plain string,
    which iterated per character and wrapped every letter in its own <p>. Accept
    both shapes rather than trusting six hand-maintained JSON files to agree.
    """
    if not footer:
        return ""
    paras = [footer] if isinstance(footer, str) else list(footer)
    return "".join(f"<p>{p}</p>" for p in paras if p)


def _harvest_html(harvest, checked, rule_alert, area, stale_cls, stale_msg):
    pills = ""
    for p in harvest["pills"]:
        note = p["note"]
        if p.get("to"):
            try:
                n_ = (datetime.strptime(p["to"], "%Y-%m-%d").date() - date.today()).days
                if n_ >= 0:
                    note += f"<br>closes in {n_} day{'' if n_ == 1 else 's'}"
            except ValueError:
                pass
        pills += (f'<div class="hpill {p["state"]}"><b>{p["name"]}</b>'
                  f'<u>{p["head"]}</u><i>{note}</i></div>')
    rows = ""
    for r_ in harvest["table"]:
        rows += (f'<tr><td>{r_["fishery"]}</td>'
                 f'<td class="st"><span class="st-tag {r_["state"]}">{r_["status"]}</span></td>'
                 f'<td class="mono">{r_["season"]}</td>'
                 f'<td class="mono">{r_["limit"]}</td>'
                 f'<td>{r_["notes"]}</td></tr>')
    alert = ""
    if rule_alert:
        items = "".join(
            f'<li><a href="{esc(it[2])}">{esc(it[1])}</a></li>' if len(it) > 2 and it[2]
            else f"<li>{esc(it[1])}</li>"
            for it in rule_alert[:6])
        alert = (f'<p class="rnote"><b>New rule activity since this table was verified</b> '
                 f'&mdash; the WDFW feed has items that mention this water. The table below '
                 f'has <i>not</i> been updated for them; check before you go.<ul>{items}</ul></p>')
    # The standing footer used to assert this table "is verified by hand" on
    # every page, including the drafts where that is simply untrue.
    provenance = ("this table was transcribed from the published rules and has "
                  "not been checked by hand."
                  if harvest.get("verified") is False
                  else "this table is verified by hand rather than scraped.")
    checked = checked or "not dated"
    # "Verified" over a table the banner below calls an unverified draft is the
    # page contradicting itself in the reader's favour, which is the wrong
    # direction to be wrong in.
    dated = (f"Drafted {checked}" if harvest.get("verified") is False
             else f"Verified {checked}")
    return f"""
  <section class="sec" id="whatsopen">
    <div class="sec-head">
      <h3>What's open &middot; {area}</h3>
      <span class="src">{dated} &middot; feed checked today</span>
    </div>
    <div class="sec-conf"><i style="width:100%"></i></div>
    <div class="harvest">
      <div class="hpills">{pills}</div>
      <p class="hverify{stale_cls}">{stale_msg}</p>
      {alert}
     <details class="hdet" id="hdet" open>
      <summary class="hsum"><span class="lbl">Season detail, rules and deadlines</span>
        <span class="chev" aria-hidden="true"></span></summary>
      <div class="htable-wrap">
        <table class="ht">
          <colgroup><col style="width:18%"><col style="width:10%"><col style="width:20%">
            <col style="width:15%"><col style="width:37%"></colgroup>
          <thead><tr><th>Fishery</th><th>Status</th><th>Season</th>
            <th>Daily limit</th><th>Rules worth knowing</th></tr></thead>
          <tbody>{rows}</tbody>
        </table>
      </div>
      <div class="hfoot">
        {_footer_html(harvest.get('footer'))}
        <p><span class="caution">This is a convenience summary, not the regulations.</span>
        Seasons move on short notice, and {provenance}
        Confirm on WDFW's <a href="https://wdfw.wa.gov/fishing/regulations/emergency-rules"
        target="_blank" rel="noopener">emergency rules page</a> or the Fish Washington app
        before you leave the dock, and check shellfish on the
        <a href="https://doh.wa.gov/shellfishsafety" target="_blank" rel="noopener">DOH
        Shellfish Safety Map</a> or the biotoxin hotline at <b>1-800-562-5632</b>.</p>
      </div>
     </details>
    </div>
  </section>"""


# ──────────────────────────────────────────────────────────────── page ──

def glance(days):
    out = ""
    for d in days:
        cls = d["rating"] + (" now" if d["today"] else "")
        kt = "&mdash;" if d["tilt"] else f"{round(d['peak_kt'] or 0)}kt"
        out += (f'<a class="gd {cls}" href="#d{d["key"].replace("-", "")}">'
                f'<b>{d["dow"]}</b><i>{d["date"]:%-d}</i><u>{kt}</u></a>')
    return out


def render(cfg, days, verdict, harvest, checked, rule_alert, sources_line, notes,
           recent_rules=(), creel=None):
    tiers = {1: "", 2: "", 3: ""}
    for n, d in enumerate(days):
        prev_t = days[n - 1]["turns"] if n > 0 else []
        next_t = days[n + 1]["turns"] if n + 1 < len(days) else []
        tiers[d["tier"]] += day_card(d, prev_t, next_t, harvest.get("open_on", ""))

    heads = {
        1: ("Days 1&ndash;5 &middot; Marine forecast", cfg["tier1_src"], 92),
        2: ("Days 6&ndash;10 &middot; Model guidance", cfg["tier2_src"], 55),
        3: ("Days 11&ndash;14 &middot; Climate outlook", cfg["tier3_src"], 20),
    }
    sections = ""
    for t in (1, 2, 3):
        title, src, conf = heads[t]
        sections += f"""
  <section class="sec">
    <div class="sec-head"><h3>{title}</h3><span class="src">{src}</span></div>
    <div class="sec-conf"><i style="width:{conf}%"></i></div>
    <div class="stack">{tiers[t]}</div>
  </section>"""

    notes_html = "".join(f"<li>{n}</li>" for n in notes)

    # The legend says what the colors are called; this says what they mean.
    # A reader should not have to scroll to the notes to find out that green
    # is 12 knots.
    _b = cfg.get("bands") or {"green": [cfg["wind_limit_kt"], cfg["seas_limit_ft"]],
                              "amber": [18, 4], "rough": [24, 6]}
    band_html = (
        '<div class="bandkey">'
        f'<span><b>Green</b> up to {_b["green"][0]:g} kt and {_b["green"][1]:g} ft '
        '&mdash; comfortable</span>'
        f'<span><b>Yellow</b> to {_b["amber"][0]:g} kt or {_b["amber"][1]:g} ft '
        '&mdash; workable, you will notice it</span>'
        f'<span><b>Orange</b> to {_b["rough"][0]:g} kt or {_b["rough"][1]:g} ft '
        '&mdash; rough for a small boat</span>'
        f'<span><b>Red</b> beyond {_b["rough"][0]:g} kt or {_b["rough"][1]:g} ft, '
        '<em>or any time NWS has a Small Craft Advisory or worse in effect</em></span>'
        '<span><b>Gray</b> past the model&rsquo;s reach &mdash; tide only, no wind '
        'forecast exists yet</span>'
        '</div>')

    # NWS's own advisory headline, shown above the verdict. Computed here rather
    # than inline because the template is an f-string and cannot carry the
    # escaping this needs.
    hz = next((d.get("hazard") for d in days if d.get("hazard")), None)
    haz_html = ('<p class="hazbar"><b>NWS has an advisory in effect for this water.</b> '
                + esc(hz)
                + ' &mdash; days inside its window are marked red regardless of the '
                  'numbers below.</p>') if hz else ""

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="{esc(cfg['description'])}">
<meta name="color-scheme" content="light dark">
<title>{esc(cfg['title'])}</title>
{_share_tags(cfg)}
{THEME}
</head>
<body>
<div class="wrap">
  <header class="mast">
    <div class="mast-id">
      <p class="eyebrow">{cfg['eyebrow']}</p>
      <h1>{esc(cfg['title'])}</h1>
      <p class="mast-sub">{cfg['subtitle']}</p>
    </div>
    <div class="stamp">
      <b>Built</b>{cfg['generated']}
      <b>Version</b><span class="ver">{esc(cfg.get('version') or 'unknown')}</span>
      <b>Tides</b>NOAA {cfg['station']} {cfg.get('station_name','')}
      <b>Datum</b>MLLW, feet
    </div>
  </header>

  {haz_html}
  <section class="verdict">
    <h2>{verdict['headline']}</h2>
    {''.join(f'<p>{p}</p>' for p in verdict['paragraphs'])}
    <div class="thresh">
      <div>Green band &nbsp;<span>wind &le; {cfg['wind_limit_kt']} kt &middot;
        seas &le; {cfg['seas_limit_ft']} ft</span></div>
      <div>Scored for &nbsp;<span>general cruising comfort</span></div>
    </div>
    <div class="glance">{glance(days)}</div>
    <div class="glance-key">
      <span><em style="background:var(--go)"></em>Green &mdash; comfortable</span>
      <span><em style="background:var(--warn)"></em>Yellow &mdash; workable</span>
      <span><em style="background:var(--rough)"></em>Orange &mdash; rough for a small boat</span>
      <span><em style="background:var(--bad)"></em>Red &mdash; small-craft advisory range</span>
      <span><em style="background:var(--rule-strong)"></em>Gray &mdash; no forecast</span>
      </div>
    {band_html}
  </section>

{regs_section(cfg, recent_rules, harvest, checked, rule_alert, creel)}
{sections}

  <section class="notes">
    <h3>Reading this page</h3>
    <ul>{notes_html}</ul>
    <div class="srcs">{sources_line}</div>
  </section>
</div>
</body>
</html>
"""


# ───────────────────────────────────────────────────────────── landing ──

def landing_page(site, areas, generated, mapdoc=None):
    """
    The index over every area. Built from the same run that built the pages, so
    it can never claim something the page it links to contradicts.

    An area that failed to build is shown as unavailable rather than omitted —
    a missing row looks like the area does not exist, which is a worse lie than
    saying the data is down.
    """
    CHIP = {"go": ("go", "Good today"), "warn": ("warn", "Marginal today"),
            "bad": ("bad", "Stay in today"), "soft": ("soft", "No forecast")}
    cards = ""
    for a in sorted(areas, key=lambda x: (x.get("order", 99), x.get("area", ""))):
        href = a.get("href") or "#"
        if not a.get("ok"):
            cards += (f'<a class="ac is-down" href="{esc(href)}">'
                      f'<div class="ac-top"><span class="ac-area">{a.get("area","")}</span>'
                      f'<span class="chip soft">Unavailable</span></div>'
                      f'<p class="ac-head">This area could not be built on the last run.</p>'
                      f'<p class="ac-meta">{esc(a.get("error","") or "source unavailable")}</p>'
                      f'</a>')
            continue
        cls, lbl = CHIP.get(a.get("today_rating", "soft"), CHIP["soft"])
        peak = (f'{a["today_peak"]:.1f} kt' if a.get("today_peak") is not None
                else "&mdash;")
        nxt = (f'Next good day {a["next_good"]}' if a.get("next_good")
               else "No clear day in the run")
        cards += (f'<a class="ac is-{cls}" href="{esc(href)}">'
                  f'<div class="ac-top"><span class="ac-area">{a.get("area","")}</span>'
                  f'<span class="chip {cls}">{lbl}</span></div>'
                  f'<p class="ac-head">{a.get("headline","")}</p>'
                  f'<p class="ac-blurb">{a.get("blurb","")}</p>'
                  f'<div class="ac-meta"><span>Today {peak}</span>'
                  f'<span>{a.get("go_days", 0)} good days in 14</span>'
                  f'<span>{nxt}</span></div></a>')

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="{esc(site['description'])}">
<meta name="color-scheme" content="light dark">
<title>{esc(site['title'])}</title>
<meta property="og:title" content="{esc(site['title'])}">
<meta property="og:description" content="{esc(site['description'])}">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary">
{f'<link rel="canonical" href="{esc(site["canonical"])}">' if site.get("canonical") else ''}
{THEME}
</head>
<body>
<div class="wrap">
  <header class="mast">
    <div class="mast-id">
      <p class="eyebrow">{site.get('eyebrow','')}</p>
      <h1>{esc(site['title'])}</h1>
      <p class="mast-sub">{site.get('subtitle','')}</p>
    </div>
    <div class="stamp"><b>Built</b>{generated}
      <b>Version</b><span class="ver">{esc(site.get('version') or 'unknown')}</span></div>
  </header>
  {area_map(mapdoc, areas)}
  <div class="areas">{cards}</div>
  <p class="ac-foot">{site.get('footer','')}</p>
</div>
</body>
</html>"""


# ─────────────────────────────────────────── fishing and shellfish, any area ──

WDFW_AREA = "https://wdfw.wa.gov/fishing/locations/marine-areas/"
WDFW_CRAB = "https://wdfw.wa.gov/fishing/shellfishing-regulations/crab/seasons-areas/"
WDFW_CRAB_INDEX = "https://wdfw.wa.gov/fishing/shellfishing-regulations/crab"
WDFW_RULES = "https://wdfw.wa.gov/fishing/regulations/rules-concise"
WDFW_EMERG = "https://wdfw.wa.gov/fishing/regulations/emergency-rules"
DOH_MAP = "https://fortress.wa.gov/doh/biotoxin/biotoxin.html"
DOH_BEACH = "https://doh.wa.gov/community-and-environment/shellfish/beach-closures"


CREEL_PAGE = "https://wdfw.wa.gov/fishing/reports/creel/puget-annual"


def creel_section(creel, cfg):
    """
    What WDFW's samplers actually counted at the ramp, by ramp.

    This is the one part of the page that is not a forecast and not a
    regulation: it is a record of boats that already went out and what came
    back in the cooler. It is counted fish, not reported fish, which makes it
    the most trustworthy number here and also the most easily misread — so the
    caveats below are not decoration. Returns "" when the area has no creel
    program configured, because an empty heading reads as "nobody caught
    anything".
    """
    if not creel:
        return ""
    area = cfg.get("area", "this area")
    ramps = creel.get("ramps") or []
    window = creel.get("window", 45)
    home = (cfg.get("home_ramp") or "").lower()

    newest = creel.get("newest")
    newest_txt = f"{newest:%-d %b %Y}" if hasattr(newest, "year") else None

    if not ramps:
        body = ('<p class="rlead">WDFW has not published a dockside check in '
                f'{esc(area)} within the last {window} days'
                + (f'. The most recent one on file is {esc(newest_txt)}.'
                   if newest_txt else ' and has none on file for this area.')
                + ' Sampling is seasonal and uneven &mdash; no check means nobody '
                  'counted, not that nobody caught anything.</p>')
        rows_n = 0
    else:
        best = max((g.get("per_angler") or 0) for g in ramps) or 1.0
        rows = ""
        for g in ramps:
            per = g.get("per_angler") or 0.0
            pct = max(2, min(100, round(per / best * 100)))
            anglers = int(g.get("anglers") or 0)
            total = int(g.get("total") or 0)
            last = g.get("last")
            last_txt = f"{last:%-d %b}" if hasattr(last, "year") else "&mdash;"
            top = sorted(((v, k) for k, v in (g.get("fish") or {}).items() if v),
                         reverse=True)[:3]
            caught = ", ".join(f"{esc(k)} {int(v)}" for v, k in top) or "nothing counted"
            cls = ' class="mine"' if home and home in g["ramp"].lower() else ""
            rows += (f'<tr{cls}><td>{esc(g["ramp"])}</td>'
                     f'<td class="n">{g.get("trips", 0)}'
                     f'<s> check{"" if g.get("trips") == 1 else "s"}</s></td>'
                     f'<td class="n">{anglers}</td>'
                     f'<td class="n">{total}</td>'
                     f'<td><div class="rbar"><span>{per:.2f}</span>'
                     f'<em><i style="width:{pct}%"></i></em></div></td>'
                     f'<td>{caught}</td>'
                     f'<td class="n">{last_txt}</td></tr>')
        rows_n = len(ramps)
        body = (f'<p class="rlead">WDFW samplers meet boats at the ramp and count '
                f'what is in them. These are the checks in <b>{esc(area)}</b> over the '
                f'last {window} days &mdash; <b>fish actually counted</b>, not fish '
                f'reported. Sorted by anglers checked.</p>'
                '<div class="htable-wrap"><table class="rt">'
                '<colgroup><col style="width:26%"><col style="width:11%">'
                '<col style="width:10%"><col style="width:9%"><col style="width:16%">'
                '<col style="width:19%"><col style="width:9%"></colgroup>'
                '<thead><tr><th>Ramp</th><th>Sampled</th><th>Anglers</th><th>Fish</th>'
                '<th>Per angler</th><th>Mostly</th><th>Last</th></tr></thead>'
                f'<tbody>{rows}</tbody></table></div>')

    sub = (f"{rows_n} ramp{'' if rows_n == 1 else 's'} &middot; last {window} days"
           if rows_n else f"no checks in {window} days")
    # The per-angler explanation is only worth the reader's time when there is a
    # per-angler column to explain.
    explain = ("Per angler is fish divided by anglers checked at that ramp, across "
               "every check in the window &mdash; it mixes salmon, lingcod and halibut "
               "trips together, and one good weekend can carry a whole month. A ramp "
               "with few checks is a small sample, not a slow ramp. " if rows_n else "")
    caveat = (f'<p class="rcaveat">{explain}Figures come from '
              f'<a href="{CREEL_PAGE}">WDFW\'s Puget Sound sampling summaries</a>, '
              f'which are published on WDFW\'s own schedule and can run a week or '
              f'more behind.</p>')
    return f"""
  <section class="sec" id="creel">
    <div class="sec-head">
      <h3>What people are catching &middot; {esc(area)}</h3>
      <span class="src">WDFW dockside sampling &middot; {sub}</span>
    </div>
    <div class="sec-conf"><i style="width:100%"></i></div>
    <div class="harvest">
     <details class="hdet" id="rdet">
      <summary class="hsum"><span class="lbl">{"Ramp by ramp" if rows_n else "When WDFW last checked"}</span>
        <span class="chev" aria-hidden="true"></span></summary>
      {body}
      {caveat}
     </details>
    </div>
  </section>"""


def regs_section(cfg, recent, harvest, checked, rule_alert, creel=None):
    """
    Fishing and shellfish, for every area — not just the one with a
    hand-verified table.

    What this deliberately does NOT do is state seasons for areas nobody has
    verified. Inventing a season is the one failure here that costs a reader a
    citation, so an unverified area gets the official sources and WDFW's own
    recent notices, and says plainly that it carries no season table. That is
    useful and true; a table assembled from guesswork would be neither.
    """
    area = cfg.get("area", "this area")
    slug = cfg.get("wdfw_slug")
    links = []
    if slug:
        links.append(f'<a href="{WDFW_AREA}{slug}">{esc(area)} rules at WDFW</a>')
    # WDFW's crab pages are slugged differently from its marine-area pages
    # ("port-susaneverett-area-8-2", not "ports-susan-gardner"), so reusing the
    # area slug produced a 404 on four of six areas. No crab slug now means the
    # general crab page, which is right, rather than a specific one that is wrong.
    crab = cfg.get("crab_slug")
    links.append(f'<a href="{WDFW_CRAB}{crab}">Crab seasons</a>' if crab
                 else f'<a href="{WDFW_CRAB_INDEX}">Crab seasons by area</a>')
    links.append(f'<a href="{WDFW_RULES}">Statewide regulations</a>')
    links.append(f'<a href="{WDFW_EMERG}">Emergency rules</a>')
    links.append(f'<a href="{DOH_MAP}">Shellfish safety map (DOH)</a>')
    links.append(f'<a href="{DOH_BEACH}">Beach closures</a>')
    link_html = '<div class="rglinks">' + " ".join(
        f'<span>{l}</span>' for l in links) + "</div>"

    items = ""
    if recent:
        rows = ""
        for d, t, link in recent:
            when = ""
            m = __import__("re").match(r"\w{3}, (\d{1,2} \w{3} \d{4})", d or "")
            when = m.group(1) if m else (d or "")[:16]
            title = f'<a href="{esc(link)}">{esc(t)}</a>' if link else esc(t)
            rows += f'<li><span class="rgd">{esc(when)}</span>{title}</li>'
        items = (f'<p class="rglead">Recent WDFW notices mentioning this water. '
                 f'These are WDFW\'s own headlines &mdash; read the notice, not this '
                 f'summary of it.</p><ul class="rglist">{rows}</ul>')
    else:
        items = ('<p class="rglead">No recent WDFW notices mention this water. '
                 'That is not the same as nothing having changed &mdash; check the '
                 'links above before you fish.</p>')

    table = harvest_section(harvest, checked, rule_alert, area)
    if not table:
        table = ('<p class="hverify warn"><b>No season table for this area.</b> '
                 'Seasons here are not tracked by hand, and nothing on this page '
                 'tells you what is open. Use the WDFW links above &mdash; they are '
                 'the only authority.</p>')

    return f"""
  <section class="sec" id="harvest">
    <div class="sec-head">
      <h3>Fishing &amp; shellfish &middot; {esc(area)}</h3>
      <span class="src">Official sources, and what WDFW has said lately</span>
    </div>
    <div class="sec-conf"><i style="width:100%"></i></div>
    {link_html}
    {table}
    {items}
  </section>
{creel_section(creel, cfg)}"""


# ───────────────────────────────────────────────────────────────── map svg ──

def area_map(mapdoc, areas, width=760):
    """
    The marine areas as WDFW draws them, tinted by today's rating, each one a
    link to its page.

    Mercator, because at 48 degrees north an unprojected plot squashes the Sound
    noticeably. Returns "" when there is no map data: the alternative is drawing
    regulatory boundaries from memory, which is not a thing to guess at.
    """
    if not mapdoc or not mapdoc.get("areas"):
        return ""
    CLS = {"go": "m-go", "warn": "m-warn", "bad": "m-bad", "soft": "m-soft"}
    by_area = {a.get("area", "").replace("Marine Area ", "").strip(): a for a in areas}

    def merc(lon, lat):
        return lon, math.degrees(math.log(math.tan(math.pi / 4
                                 + math.radians(max(-85, min(85, lat))) / 2)))

    pts = [merc(x, y) for rs in mapdoc["areas"].values() for r in rs for x, y in r]
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    w = (x1 - x0) or 1e-6
    h = (y1 - y0) or 1e-6

    # Fixed landscape box, geometry fitted and centered inside it. Deriving the
    # height from the data's own aspect produced a page-and-a-half of map:
    # Puget Sound is tall and narrow, so the natural aspect is unusable as a
    # page element.
    height = int(width * 0.68)
    pad = 14
    scale = min((width - 2 * pad) / w, (height - 2 * pad) / h)
    ox = (width - w * scale) / 2
    oy = (height - h * scale) / 2

    def X(lon, lat):
        mx, _ = merc(lon, lat)
        return ox + (mx - x0) * scale

    def Y(lon, lat):
        _, my = merc(lon, lat)
        return oy + (y1 - my) * scale

    # A water-body backdrop: every area's polygon drawn once in a flat "other
    # water" tone, so the shape of the Sound reads as a map even where an area
    # has no data, and the colored areas sit *in* something rather than float.
    back = ""
    for key in sorted(mapdoc["areas"]):
        for ring in mapdoc["areas"][key]:
            back += ("M" + " L".join(f"{X(x, y):.1f} {Y(x, y):.1f}"
                                     for x, y in ring) + " Z")
    backdrop = (f'<rect class="mland" x="0" y="0" width="{width}" height="{height}"/>'
                f'<path class="mwater" d="{back}"/>')

    shapes = ""
    for key in sorted(mapdoc["areas"]):
        a = by_area.get(key)
        cls = CLS.get((a or {}).get("today_rating", "soft"), "m-soft")
        if a and not a.get("ok", True):
            cls = "m-soft"
        d = ""
        cx = cy = n = 0
        for ring in mapdoc["areas"][key]:
            d += "M" + " L".join(f"{X(x, y):.1f} {Y(x, y):.1f}" for x, y in ring) + " Z"
            for x, y in ring:
                cx += X(x, y); cy += Y(x, y); n += 1
        label = f"Marine Area {key}"
        body = (f'<path class="marea {cls}" d="{d}"/>'
                f'<text class="mlab" x="{cx/max(n,1):.0f}" y="{cy/max(n,1):.0f}" '
                f'text-anchor="middle">{key}</text>')
        href = (a or {}).get("href")
        shapes += (f'<a href="{esc(href)}"><title>{esc(label)}</title>{body}</a>'
                   if href else f'<g><title>{esc(label)}</title>{body}</g>')

    return (f'<div class="mapwrap"><svg viewBox="0 0 {width} {height}" '
            f'role="img" aria-label="Washington marine areas covered by this site">'
            f'{backdrop}{shapes}</svg>'
            f'<p class="mapnote">Boundaries are WDFW\'s own '
            f'(<span>{esc(mapdoc.get("source",""))}</span>), simplified for drawing. '
            f'Tinted by today\'s rating. Not for navigation &mdash; carry a chart.</p></div>')
