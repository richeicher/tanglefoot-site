#!/usr/bin/env python3
"""
Build the conditions page from live data and install it.

    generate.py --check      test every source, write nothing
    generate.py --dry-run    build the page to stdout path, don't install
    generate.py              build and install

Exit codes: 0 ok, 1 refused (page built but failed validation), 2 no usable data.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import tempfile
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import build
import render
import scoring as S
import sources


def log(msg):
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}", flush=True)


def load_json(name, default=None):
    path = os.path.join(HERE, name)
    if not os.path.exists(path):
        if default is not None:
            return default
        raise SystemExit(f"missing required file: {path}")
    with open(path) as fh:
        return json.load(fh)


# ─────────────────────────────────────────────────────────────── verdict ──

def runs_of(days, predicate):
    out, cur = [], []
    for d in days:
        if predicate(d):
            cur.append(d)
        else:
            if cur:
                out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return out


def make_verdict(days, cfg):
    usable = [d for d in days if d["rating"] == "go" and not d["tilt"]]
    best = next((d for d in days if d.get("best")), None)
    streaks = runs_of(days, lambda d: d["rating"] == "go" and not d["tilt"])
    longest = max(streaks, key=len) if streaks else []

    today = days[0]
    peaks = [d["peak_kt"] for d in days if d["peak_kt"] is not None]
    max_wind = max(peaks) if peaks else None
    wet = [d for d in days if d["rain_in"] >= 0.1]

    if not usable:
        headline = "Nothing inside your limits in the next fortnight"
    elif longest and len(longest) >= 3:
        a, b = longest[0], longest[-1]
        headline = (f"{len(longest)} straight days inside your limits, "
                    f"{a['date']:%b %-d}&ndash;{b['date']:%-d}")
        if best and best in longest:
            headline += f", with {best['date']:%A the %-d}{_ord(best['date'].day)} the standout"
    elif best:
        headline = f"{best['date']:%A the %-d}{_ord(best['date'].day)} is the day to take"
    else:
        headline = "A mixed fortnight &mdash; pick your window carefully"

    paras = []

    if max_wind is not None and max_wind <= cfg["wind_limit_kt"]:
        # Wind being legal all fortnight does NOT mean sea state is a non-issue:
        # 9-12 kt sits inside a 10 kt limit but already puts up 1-2 ft. Say which
        # threshold actually ruled the bad days out, or the prose contradicts the tiles.
        seas_out = [d for d in days
                    if not d["tilt"] and d["rating"] == "bad"
                    and d.get("seas_ft") is not None
                    and d["seas_ft"] > cfg["seas_limit_ft"]]
        if seas_out:
            names = ", ".join(f"{d['date']:%a the %-d}" for d in seas_out[:3])
            more = f" and {len(seas_out) - 3} more" if len(seas_out) > 3 else ""
            n = len(seas_out)
            p = (f"Wind never crosses your {cfg['wind_limit_kt']}-knot line anywhere in the "
                 f"fortnight &mdash; the windiest hour in the whole run is {max_wind:.1f} kt. "
                 f"But wind is not what rules the red days out: at that speed the chop is "
                 f"already past your {cfg['seas_limit_ft']}-foot seas limit, so "
                 f"<em>{n} day{'' if n == 1 else 's'} {'is' if n == 1 else 'are'} out on "
                 f"sea state, not wind</em> &mdash; {names}{more}.")
        else:
            p = (f"Wind never crosses your {cfg['wind_limit_kt']}-knot line anywhere in the "
                 f"fortnight &mdash; the windiest hour in the whole run is {max_wind:.1f} kt, "
                 f"and the chop stays inside your {cfg['seas_limit_ft']}-foot limit too. "
                 f"So <em>rain and visibility decide your days, not sea state</em>.")
    else:
        blown = [d for d in days if d["peak_kt"] and d["peak_kt"] > cfg["wind_limit_kt"]]
        names = ", ".join(f"{d['date']:%a the %-d}" for d in blown[:3])
        p = (f"Wind crosses your {cfg['wind_limit_kt']}-knot limit on {len(blown)} "
             f"day{'' if len(blown) == 1 else 's'} &mdash; {names}. Everything else is "
             f"inside the line, so rain and cloud decide the rest.")
    if wet:
        p += (f" {len(wet)} day{'' if len(wet) == 1 else 's'} carry meaningful rain, "
              f"heaviest on {max(wet, key=lambda d: d['rain_in'])['date']:%A}.")
    paras.append(p)

    if best:
        cols = [c for c in best["cols"] if c["f"] is not None]
        warmest = max((c["f"] for c in cols), default=None)
        p2 = (f"<em>{best['date']:%A %b %-d} is the pick</em>: peak wind "
              f"{best['peak_kt']:.1f} kt, {best['rain_in']:.2f} in of rain")
        if warmest:
            p2 += f", {warmest}&deg;F at the warmest"
        p2 += f", and a {best['range']} tidal range."
        runner = sorted((d for d in usable if d is not best),
                        key=lambda d: d["score"], reverse=True)
        if runner:
            r = runner[0]
            p2 += (f" {r['date']:%A the %-d}{_ord(r['date'].day)} is the next best "
                   f"at {r['peak_kt']:.1f} kt.")
    else:
        p2 = "No day in the run comes in clean. Watch for the next model update."

    if today["rating"] == "go":
        p2 += " Today is inside your limits if you want to go now."
    elif today["rating"] == "bad":
        p2 += " Today is not one to be out in."
    paras.append(p2)

    return {"headline": headline, "paragraphs": paras}


def _ord(n):
    return "th" if 11 <= n % 100 <= 13 else {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")


# ──────────────────────────────────────────────────────────────── notes ──

def make_notes(cfg, zone_issued, model_updated, degraded, harvest_checked,
               currents=None):
    notes = [
        "<b>Every day gets a full tile, in date order, today first.</b> Each shows "
        "conditions at four points through the day, the day's peak wind against your "
        "10-kt limit, the full tide curve with all four turns, and sun, daylight, moon "
        "and rain totals.",
        "<b>This page is generated by a script on the server</b>, not written by hand. "
        "The numbers come straight from the sources below; the prose is assembled from "
        "the same numbers by rule. Where it reads a little flat, that is why.",
        "<b>The harvest table is verified by hand, not scraped.</b> It was last checked "
        f"on {harvest_checked}. The WDFW rule feed is read every run, and if anything "
        "new mentions this water a banner appears above the table &mdash; but the table "
        "itself does not change until a human updates it.",
        "<b>Tides are exact for all 14 days</b> &mdash; they're astronomical, not "
        "forecast. The shaded band on each chart is daylight, sunrise to sunset.",
        "<b>Sea state is estimated from wind</b> over Possession Sound's short fetch. "
        "The zone forecast's \"2 ft or less\" floor is too coarse to score against a "
        "1-foot threshold, so light-wind days are refined from wind speed. Where the "
        "zone forecast gives a harder wave number, that number wins.",
        "<b>Confidence drops as you go down the page.</b> The bar under each heading "
        "shows roughly how much to trust that block. The last days carry no wind "
        "guidance at all &mdash; their tiles show the tide, which is exact, and nothing "
        "that pretends to be a forecast.",
    ]
    if zone_issued:
        notes.append(f"<b>Zone forecast issued {zone_issued}.</b> Its day names are mapped "
                     "from its own issuance date, not today's, so a stale product can't "
                     "silently shift the week.")
    if model_updated:
        notes.append(f"<b>Model run {model_updated}.</b> Beyond about day three the data "
                     "is 6-hourly, which in Pacific time lands on 5 AM, 11 AM, 5 PM and "
                     "11 PM &mdash; the four columns each tile shows. Nothing is "
                     "interpolated.")
    if currents:
        m = currents["meta"]
        notes.append(
            f"<b>Currents are trolling information, not a go/no-go factor.</b> "
            f"They come from NOAA station {m['station']}, bin {m['bin']}, and this "
            "water runs slack &mdash; well under a knot at every stage of every tide "
            "in the run. That is too little to build wind-against-tide chop, so "
            "current is deliberately <em>not</em> fed into the day ratings. What it "
            "is good for is the gap between speed over ground and speed through "
            "water when you are trolling, and knowing when the water goes still.")
    for d in degraded:
        notes.append(f"<b>Source degraded:</b> {d}")
    return notes


# ───────────────────────────────────────────────────────────────── main ──

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="test sources, write nothing")
    ap.add_argument("--dry-run", action="store_true", help="build but do not install")
    ap.add_argument("--out", help="override output path")
    args = ap.parse_args()

    vpath = os.path.join(HERE, "VERSION")
    if os.path.exists(vpath):
        with open(vpath) as fh:
            log(f"conditions {fh.readline().strip()}")

    cfg = load_json("config.json")
    tz = ZoneInfo(cfg["timezone"])
    today = datetime.now(tz).date()

    degraded = []

    log("fetching tides…")
    tides, err = sources.fetch_tides(cfg["station"], today - timedelta(days=1),
                                     today + timedelta(days=14))
    if err:
        degraded.append(err)
        log(f"  ! {err}")
    else:
        log(f"  {len(tides)} turns")

    log("fetching zone forecast…")
    zone, err = sources.fetch_zone(cfg["zone"])
    if err:
        degraded.append(err)
        log(f"  ! {err}")
    else:
        log(f"  issued {zone['issued']}, {len(zone['periods'])} periods")

    log("fetching model…")
    model, err = sources.fetch_model(cfg["lat"], cfg["lon"])
    if err:
        degraded.append(err)
        log(f"  ! {err}")
    else:
        log(f"  updated {model['updated']}, {len(model['steps'])} steps")

    log("fetching currents…")
    currents = None
    if cfg.get("current_station"):
        currents, err = sources.fetch_currents(
            cfg["current_station"], cfg.get("current_bin"),
            today - timedelta(days=1), today + timedelta(days=14))
        if err:
            degraded.append(err)
            log(f"  ! {err}")
        else:
            log(f"  {len(currents['events'])} slack/max events")
    else:
        log("  no current station configured, skipping")

    log("fetching rule feed…")
    feed, err = sources.fetch_rule_feed()
    if err:
        degraded.append(err)
        log(f"  ! {err}")
    else:
        log(f"  {len(feed)} items")

    if args.check:
        log("check complete" + (f" — {len(degraded)} degraded" if degraded else " — all sources OK"))
        return 0 if not degraded else 1

    if not tides and not model:
        log("REFUSED: neither tides nor model available, nothing worth publishing")
        return 2

    harvest = load_json("harvest.json")
    seen = set(harvest.get("seen_rule_titles", []))
    alert = sources.relevant_rules(feed, seen) if feed else []
    if alert:
        log(f"  {len(alert)} new relevant rule item(s) — banner will show")

    days, zone_issued = build.build_days(cfg, tides or [], model, zone, today,
                                         currents=currents)
    verdict = make_verdict(days, cfg)

    cfg = dict(cfg)
    cfg["generated"] = f"{datetime.now(tz):%a %-d %b %Y, %H:%M %Z}"
    cfg["tier1_src"] = (f"NWS zone {cfg['zone'].upper()}, issued {zone['issued']}"
                        if zone else "NWS zone forecast unavailable")
    cfg["tier2_src"] = (f"MET Norway, run {model['updated']}" if model
                        else "model unavailable")
    cfg["tier3_src"] = "No model guidance at this range"

    srcs = (f"Tides &middot; NOAA CO-OPS station {cfg['station']} (Everett)<br>"
            f"Marine &middot; NWS {cfg['zone'].upper()}"
            f"{' , ' + zone['issued'] if zone else ' (unavailable)'}<br>"
            f"Model &middot; MET Norway Locationforecast 2.0"
            f"{', run ' + model['updated'] if model else ' (unavailable)'}<br>"
            + (f"Currents &middot; NOAA CO-OPS {currents['meta']['station']} "
               f"bin {currents['meta']['bin']}<br>" if currents else "")
            + f"Harvest &middot; verified by hand {harvest['checked']}; "
            f"WDFW rule feed read {today:%-d %b %Y}<br>"
            f"Sun and moon computed for {cfg['lat']}&deg;N, {cfg['lon']}&deg;E "
            f"&middot; all times local")

    notes = make_notes(cfg, zone["issued"] if zone else None,
                       model["updated"] if model else None,
                       degraded, harvest["checked"], currents)

    page = render.render(cfg, days, verdict, harvest, harvest["checked"],
                         alert, srcs, notes)

    # ── validation: refuse to install anything that isn't clearly the page ──
    problems = []
    if len(page) < cfg["min_bytes"]:
        problems.append(f"page is {len(page)} bytes, under {cfg['min_bytes']}")
    if cfg["marker"] not in page:
        problems.append(f"marker {cfg['marker']!r} missing")
    if len([d for d in days if not d["tilt"]]) < 3:
        problems.append("fewer than three days have any forecast behind them")
    if problems:
        for p in problems:
            log(f"REFUSED: {p}")
        return 1

    out = args.out or cfg["output"]
    if args.dry_run:
        tmp = os.path.join(tempfile.gettempdir(), "conditions-preview.html")
        open(tmp, "w").write(page)
        log(f"dry run — wrote {len(page)} bytes to {tmp}")
        return 0

    # atomic install, with the previous page kept for rollback
    d = os.path.dirname(out)
    if os.path.exists(out):
        shutil.copy2(out, os.path.join(d, "index.prev.html"))
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    with os.fdopen(fd, "w") as fh:
        fh.write(page)
    os.chmod(tmp, 0o644)
    os.replace(tmp, out)
    log(f"published {len(page)} bytes to {out}"
        + (f" ({len(degraded)} source(s) degraded)" if degraded else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
