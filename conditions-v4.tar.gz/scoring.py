"""
Turning numbers into a verdict.

All of the judgement the page makes lives here, in one place, so the rules can
be read and argued with rather than being scattered through the renderer.
"""

from __future__ import annotations

MS_TO_KT = 1.94384
MM_TO_IN = 1 / 25.4

COMPASS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
           "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]

# Arrows point the way the wind is blowing, not where it comes from.
ARROW = {"N": "↓", "NNE": "↓", "NE": "↙", "ENE": "↙", "E": "←", "ESE": "←",
         "SE": "↖", "SSE": "↑", "S": "↑", "SSW": "↑", "SW": "↗", "WSW": "→",
         "W": "→", "WNW": "→", "NW": "↘", "NNW": "↓"}


def compass(deg):
    if deg is None:
        return None
    return COMPASS[int((float(deg) % 360) / 22.5 + 0.5) % 16]


def kt(ms):
    return None if ms is None else round(float(ms) * MS_TO_KT, 1)


def f(c):
    return None if c is None else round(float(c) * 9 / 5 + 32)


def inches(mm):
    return 0.0 if mm is None else round(float(mm) * MM_TO_IN, 2)


def sea_state(peak_kt, fetch_weight=1.0):
    """
    Possession Sound has a short fetch, so sea state follows wind closely —
    but not equally from every direction. fetch_weight scales the wind before
    banding: a southerly with the length of the main basin behind it builds
    more sea than the same speed blowing off the Everett waterfront.

    Returns (label, upper-bound feet) — the bound is what gets compared against
    the seas threshold.
    """
    if peak_kt is None:
        return ("Unknown", None)
    peak_kt = peak_kt * (fetch_weight or 1.0)
    if peak_kt <= 3:
        return ("Glassy, under 6 in", 0.5)
    if peak_kt <= 6:
        return ("Ripples, under 6 in", 0.5)
    if peak_kt <= 9:
        return ("Light chop, ~1 ft", 1.0)
    if peak_kt <= 12:
        return ("Chop, 1&ndash;2 ft", 2.0)
    return ("2+ ft", 3.0)


def sky_phrase(symbol, cloud_pct):
    """Short human phrase for a cell, preferring the model's own symbol."""
    if symbol:
        s = symbol.split("_")[0]
        table = {
            "clearsky": "Clear", "fair": "Mostly clear", "partlycloudy": "Partly cloudy",
            "cloudy": "Overcast", "lightrain": "Light rain", "rain": "Rain",
            "heavyrain": "Heavy rain", "lightrainshowers": "Light showers",
            "rainshowers": "Showers", "heavyrainshowers": "Heavy showers",
            "fog": "Fog", "lightsleet": "Sleet", "sleet": "Sleet", "snow": "Snow",
            "lightsnow": "Light snow", "heavysnow": "Heavy snow",
            "lightsnowshowers": "Snow showers", "snowshowers": "Snow showers",
        }
        if s in table:
            return table[s]
    if cloud_pct is None:
        return "&mdash;"
    if cloud_pct < 10:
        return "Clear"
    if cloud_pct < 40:
        return "Mostly clear"
    if cloud_pct < 75:
        return "Partly cloudy"
    return "Overcast"


GUST_SPREAD_KT = 5.0     # gust minus sustained, above which a day reads as gusty


def is_gusty(peak_kt, gust_kt):
    """A day is 'gusty' when the gusts run well above the sustained wind."""
    if peak_kt is None or gust_kt is None:
        return False
    return (gust_kt - peak_kt) >= GUST_SPREAD_KT


def rate_day(peak_kt, seas_ft, rain_in, cloud_avg, wind_limit, seas_limit,
             has_forecast=True, gust_kt=None):
    """
    Returns (rating, label). Ratings drive colour; labels are what the chip says.

    The order matters. Seas can disqualify a day whose wind is still legal —
    9 to 12 kt is inside a 10 kt limit but already puts up 1 to 2 ft — so the
    sea check comes first and the reason is reported separately.

    Gusts never make a day 'bad' on their own: a gust is seconds of wind, not a
    sea state, and treating it like sustained wind would strike out days that
    are perfectly fine between puffs. They do cap a day at Marginal when they
    cross the limit, and they keep a day off 'Excellent' when they are ragged.
    """
    if not has_forecast:
        return ("soft", "Tilt only")

    over_wind = peak_kt is not None and peak_kt > wind_limit
    over_seas = seas_ft is not None and seas_ft > seas_limit
    heavy_rain = rain_in >= 0.25
    some_rain = rain_in >= 0.05
    gust_over = gust_kt is not None and gust_kt > wind_limit
    gusty = is_gusty(peak_kt, gust_kt)

    if over_wind or over_seas or heavy_rain:
        return ("bad", "Stay in")
    if some_rain or gust_over or (peak_kt is not None and peak_kt > wind_limit * 0.8):
        return ("warn", "Marginal")

    dry_calm = rain_in < 0.02 and (peak_kt is not None and peak_kt <= wind_limit * 0.7)
    if dry_calm and not gusty and (cloud_avg is not None and cloud_avg < 45):
        return ("go", "Excellent")
    return ("go", "Good")


def limiting_factor(peak_kt, seas_ft, rain_in, wind_limit, seas_limit,
                    gust_kt=None):
    """Which threshold actually decides the day. Used in the prose."""
    if seas_ft is not None and seas_ft > seas_limit:
        if peak_kt is not None and peak_kt <= wind_limit:
            return "seas"          # the interesting case: legal wind, illegal water
        return "seas and wind"
    if peak_kt is not None and peak_kt > wind_limit:
        return "wind"
    if rain_in >= 0.25:
        return "rain"
    if gust_kt is not None and gust_kt > wind_limit:
        return "gusts"             # sustained is legal, the puffs are not
    if rain_in >= 0.05:
        return "showers"
    if is_gusty(peak_kt, gust_kt):
        return "gusty"
    # rate_day downgrades a day once wind reaches 80% of the limit, so the
    # limiter has to have a name for that case — otherwise a Marginal day
    # reports that nothing is against it.
    if peak_kt is not None and peak_kt > wind_limit * 0.8:
        return "near limit"
    return None


# ───────────────────────────────────────────────────────────────── fetch ──
#
# Which way the wind has room to build a sea. Sector -> (label, weight), where
# weight scales the wind-derived sea estimate: a 10 kt southerly with 20 miles
# of open water behind it is a different sea than 10 kt off a beach half a mile
# away. Overridden per-area from config.json; this is the fallback.

DEFAULT_FETCH = {
    "N":   ["down Port Susan", 1.15],
    "NNE": ["down Port Susan", 1.1],
    "NE":  ["off the Tulalip shore", 0.85],
    "ENE": ["off the mainland", 0.8],
    "E":   ["off the mainland", 0.8],
    "ESE": ["off the Everett waterfront", 0.8],
    "SE":  ["off the Everett waterfront", 0.85],
    "SSE": ["up the sound", 1.1],
    "S":   ["straight up the main basin", 1.3],
    "SSW": ["straight up the main basin", 1.3],
    "SW":  ["up past Possession Point", 1.25],
    "WSW": ["across from Whidbey", 0.95],
    "W":   ["off the Whidbey shore", 0.85],
    "WNW": ["down Saratoga Passage", 1.1],
    "NW":  ["down Saratoga Passage", 1.2],
    "NNW": ["down Saratoga Passage", 1.15],
}


def fetch_for(direction, table=None):
    """(label, weight) for a compass sector. Unknown direction is neutral."""
    t = table or DEFAULT_FETCH
    row = t.get(direction)
    if not row:
        return (None, 1.0)
    return (row[0], float(row[1]))


def score_for_ranking(day):
    """Higher is better. Used to pick the standout day of the run."""
    if day.get("tilt"):
        return -1e9
    s = 0.0
    s -= (day.get("rain_in") or 0) * 400          # dry dominates
    s -= (day.get("peak_kt") or 0) * 6            # then calm
    s -= (day.get("cloud_avg") or 0) * 0.35       # then clear
    s += (day.get("high_f") or 0) * 0.8           # then warm
    if day["rating"] == "bad":
        s -= 500
    if day["rating"] == "warn":
        s -= 200
    return s
