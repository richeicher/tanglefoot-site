"""
Data sources for the conditions page.

Every fetch is wrapped so a single dead source degrades the page instead of
killing the run. Each fetcher returns (data, note) where note is None on success
or a short human-readable string explaining what went wrong.
"""

from __future__ import annotations

import json
import re
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta, timezone

UA = "tanglefoot-conditions/1.0 (+https://tanglefoot.dev)"
TIMEOUT = 25


class SourceError(Exception):
    pass


def _get(url: str, accept: str = "*/*") -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": accept})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            if r.status != 200:
                raise SourceError(f"HTTP {r.status}")
            return r.read()
    except urllib.error.HTTPError as e:
        raise SourceError(f"HTTP {e.code}") from e
    except Exception as e:  # timeouts, DNS, TLS
        raise SourceError(str(e)[:120]) from e


# ─────────────────────────────────────────────────────────────── tides ──

def fetch_tides(station: str, start: date, end: date):
    """NOAA CO-OPS high/low predictions. Returns [(date, 'HH:MM', feet, 'H'|'L')]."""
    url = (
        "https://api.tidesandcurrents.noaa.gov/api/prod/datagetter"
        "?product=predictions&application=tanglefoot"
        f"&begin_date={start:%Y%m%d}&end_date={end:%Y%m%d}"
        f"&datum=MLLW&station={station}&time_zone=lst_ldt"
        "&units=english&interval=hilo&format=json"
    )
    try:
        payload = json.loads(_get(url, "application/json"))
    except SourceError as e:
        return None, f"NOAA tides unavailable ({e})"
    except json.JSONDecodeError:
        return None, "NOAA tides returned malformed JSON"

    if "predictions" not in payload:
        return None, f"NOAA tides returned no predictions ({payload.get('error', {}).get('message', 'unknown')})"

    out = []
    for p in payload["predictions"]:
        try:
            d, hm = p["t"].split(" ")
            out.append((d, hm[:5], round(float(p["v"]), 2), p["type"]))
        except (KeyError, ValueError):
            continue
    if not out:
        return None, "NOAA tides returned an empty series"
    return out, None


# ──────────────────────────────────────────────────────── zone forecast ──

PERIOD_RE = re.compile(r"^\.([A-Z][A-Z \.]*?)\.\.\.(.*)$")


def fetch_zone(zone: str = "pzz135"):
    """
    NWS coastal zone product. Returns {'issued': str, 'periods': [(name, text)]}.
    The product is plain text; periods look like:
        .TODAY...N wind around 5 kt. Waves around 2 ft or less.
    """
    url = f"https://tgftp.nws.noaa.gov/data/forecasts/marine/coastal/pz/{zone}.txt"
    try:
        raw = _get(url, "text/plain").decode("utf-8", "replace")
    except SourceError as e:
        return None, f"NWS zone forecast unavailable ({e})"

    issued = None
    m = re.search(r"^(\d{3,4}\s+(?:AM|PM)\s+[A-Z]{3}\s+\w{3}\s+\w{3}\s+\d{1,2}\s+\d{4})\s*$",
                  raw, re.M)
    if m:
        issued = m.group(1).strip()

    periods, name, buf = [], None, []
    for line in raw.splitlines():
        pm = PERIOD_RE.match(line)
        if pm:
            if name:
                periods.append((name, " ".join(buf).strip()))
            name, buf = pm.group(1).strip().rstrip("."), [pm.group(2).strip()]
        elif name and line.strip() and not line.startswith("$$"):
            buf.append(line.strip())
        elif line.startswith("$$") and name:
            periods.append((name, " ".join(buf).strip()))
            name, buf = None, []
    if name:
        periods.append((name, " ".join(buf).strip()))

    if not periods:
        return None, "NWS zone forecast had no parseable periods"
    return {"issued": issued, "periods": periods}, None


def zone_wind_kt(text: str):
    """Pull the highest wind number out of a period's text, in knots."""
    nums = [int(n) for n in re.findall(r"(\d{1,2})\s*(?:to\s*\d{1,2}\s*)?kt", text)]
    nums += [int(n) for n in re.findall(r"to\s+(\d{1,2})\s*kt", text)]
    return max(nums) if nums else None


def zone_wave_ft(text: str):
    """Highest wave height mentioned, in feet."""
    nums = [int(n) for n in re.findall(r"(\d{1,2})\s*ft", text)]
    return max(nums) if nums else None


# ─────────────────────────────────────────────────────────────── model ──

def fetch_model(lat: float, lon: float):
    """
    MET Norway locationforecast 2.0. Returns
    {'updated': iso, 'steps': {iso_utc: {...}}} with every timestep keyed by its
    exact UTC timestamp, so nothing has to be inferred from ordering.
    """
    url = (
        "https://api.met.no/weatherapi/locationforecast/2.0/complete"
        f"?lat={lat:.4f}&lon={lon:.4f}"
    )
    try:
        payload = json.loads(_get(url, "application/json"))
    except SourceError as e:
        return None, f"MET Norway unavailable ({e})"
    except json.JSONDecodeError:
        return None, "MET Norway returned malformed JSON"

    try:
        series = payload["properties"]["timeseries"]
        updated = payload["properties"]["meta"]["updated_at"]
    except KeyError:
        return None, "MET Norway response missing expected structure"

    steps = {}
    for entry in series:
        t = entry["time"]
        det = entry.get("data", {}).get("instant", {}).get("details", {})
        nxt = entry.get("data", {})
        precip = symbol = None
        for horizon in ("next_1_hours", "next_6_hours", "next_12_hours"):
            blk = nxt.get(horizon)
            if blk:
                precip = blk.get("details", {}).get("precipitation_amount")
                symbol = blk.get("summary", {}).get("symbol_code")
                break
        steps[t] = {
            "temp_c": det.get("air_temperature"),
            "wind_ms": det.get("wind_speed"),
            "gust_ms": det.get("wind_speed_of_gust"),
            "wind_dir": det.get("wind_from_direction"),
            "cloud_pct": det.get("cloud_area_fraction"),
            "rh_pct": det.get("relative_humidity"),
            "precip_mm": precip,
            "symbol": symbol,
        }
    if not steps:
        return None, "MET Norway returned an empty timeseries"
    return {"updated": updated, "steps": steps}, None


# ───────────────────────────────────────────────────────── rule changes ──

def fetch_rule_feed():
    """
    WDFW emergency-rule RSS. Used only for change detection: the harvest table
    is human-verified config, and this tells you when to go re-verify it.
    Returns [(iso_date, title)].
    """
    url = "https://wdfw.wa.gov/fishing/regulations/emergency-rules/rss"
    try:
        raw = _get(url, "application/rss+xml").decode("utf-8", "replace")
    except SourceError as e:
        return None, f"WDFW rule feed unavailable ({e})"

    items = []
    for chunk in re.findall(r"<item>(.*?)</item>", raw, re.S)[:40]:
        t = re.search(r"<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>", chunk, re.S)
        d = re.search(r"<pubDate>(.*?)</pubDate>", chunk, re.S)
        if t:
            items.append(((d.group(1).strip() if d else ""), t.group(1).strip()))
    if not items:
        return None, "WDFW rule feed had no items"
    return items, None


RELEVANT = re.compile(
    r"\b(marine area 8|area 8-1|area 8-2|possession|port susan|port gardner|"
    r"everett|snohomish|puget sound|crab|shrimp|shellfish|halibut)\b", re.I)


def relevant_rules(items, since_titles):
    """New feed items that mention this water. since_titles = previously seen."""
    fresh = [(d, t) for d, t in items if t not in since_titles]
    return [(d, t) for d, t in fresh if RELEVANT.search(t)]
