"""
Render the page as static HTML.

The published version builds its tiles in JavaScript at load time. This one
emits finished markup with the tide charts already drawn as inline SVG, so the
page needs no script at all — faster, works with JS off, and indexable if the
multi-area idea ever happens.
"""

from __future__ import annotations

import html
import math
import os
from datetime import date, datetime, timedelta

import scoring as S

HERE = os.path.dirname(os.path.abspath(__file__))
THEME = open(os.path.join(HERE, "theme.html")).read()


def esc(s):
    return html.escape(str(s), quote=False) if s is not None else ""


# ───────────────────────────────────────────────────────────── tide svg ──

def _mins(hm):
    h, m = hm.split(":")
    return int(h) * 60 + int(m)


def _height_at(turn_list, minute):
    """Cosine interpolation between turning points, as the JS version did."""
    a = b = None
    for t in turn_list:
        if t[0] <= minute:
            a = t
        if t[0] >= minute and b is None:
            b = t
    if a is None:
        return b[1] if b else 0.0
    if b is None or b[0] == a[0]:
        return a[1]
    p = (minute - a[0]) / (b[0] - a[0])
    return (a[1] + b[1]) / 2 - ((b[1] - a[1]) / 2) * math.cos(math.pi * p)


def tide_svg(prev_turns, turns, next_turns, sunrise, sunset):
    """One day's tide curve, with neighbouring days as anchors so the ends aren't flat."""
    W, H = 300, 88
    PADL, PADR, PADT, PADB = 22, 6, 9, 14
    LO, HI = 0, 12

    flat = ([(_mins(t["hm"]) - 1440, t["v"]) for t in prev_turns]
            + [(_mins(t["hm"]), t["v"]) for t in turns]
            + [(_mins(t["hm"]) + 1440, t["v"]) for t in next_turns])
    flat.sort()
    if not flat:
        return '<svg viewBox="0 0 300 88" role="img" aria-label="no tide data"></svg>'

    def x(m):
        return PADL + (m / 1440) * (W - PADL - PADR)

    def y(v):
        return H - PADB - ((v - LO) / (HI - LO)) * (H - PADT - PADB)

    pts = [(x(m), y(_height_at(flat, m))) for m in range(0, 1441, 20)]
    line = "M" + " L".join(f"{px:.1f} {py:.1f}" for px, py in pts)
    area = f"{line} L{x(1440):.1f} {H - PADB} L{x(0):.1f} {H - PADB} Z"

    band = ""
    if sunrise != "--:--" and sunset != "--:--":
        sx, ex = x(_mins(sunrise)), x(_mins(sunset))
        band = (f'<rect x="{sx:.1f}" y="{PADT}" width="{ex - sx:.1f}" '
                f'height="{H - PADT - PADB}" fill="var(--day-band)"/>')

    grid = ""
    for v in (0, 4, 8, 12):
        gy = y(v)
        grid += (f'<line x1="{PADL}" y1="{gy:.1f}" x2="{W - PADR}" y2="{gy:.1f}" '
                 f'stroke="var(--rule)" stroke-width=".6"/>'
                 f'<text x="{PADL - 4}" y="{gy + 3:.1f}" text-anchor="end" '
                 f'font-family="IBM Plex Mono,monospace" font-size="7.5" '
                 f'fill="var(--ink-faint)">{v}</text>')

    marks = "".join(
        f'<circle cx="{x(_mins(t["hm"])):.1f}" cy="{y(t["v"]):.1f}" r="2.6" '
        f'fill="var(--surface)" stroke="var(--tide-line)" stroke-width="1.5"/>'
        for t in turns)

    return (f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Tide curve">'
            f'{band}{grid}'
            f'<path d="{area}" fill="var(--tide-fill)" opacity=".75"/>'
            f'<path d="{line}" fill="none" stroke="var(--tide-line)" '
            f'stroke-width="1.8" stroke-linejoin="round"/>{marks}</svg>')


# ──────────────────────────────────────────────────────────── day cards ──

def day_card(day, prev_turns, next_turns, open_on):
    cls = "bc is-" + day["rating"] + (" is-best" if day.get("best") else "")

    if day["tilt"]:
        left = (
            '<div class="hgrid tilt">'
            '<div class="hcell"><div class="hlab">Temperature</div>'
            '<div class="htemp sm">No forecast</div><div class="hsky">Beyond model range</div></div>'
            '<div class="hcell"><div class="hlab">Precipitation</div>'
            '<div class="htemp sm">No forecast</div><div class="hsky">Beyond model range</div></div>'
            '<div class="hcell empty"><div class="hlab">Wind &amp; sea</div>'
            '<div class="htemp sm">No forecast</div><div class="hsky">Beyond model range</div></div>'
            '</div>'
            '<div class="nowind">No wind or sea-state guidance exists at this range &mdash; '
            'nothing here is a forecast you can plan a departure on. The tide, sun and moon '
            'beside it are exact.</div>')
        head_right = '<span class="tagline">' + esc(day["tag"]) + "</span>"
    else:
        cells = ""
        for c in day["cols"]:
            if c["f"] is None:
                cells += (f'<div class="hcell empty"><div class="hlab">{c["label"]}</div>'
                          f'<div class="htemp sm">&mdash;</div>'
                          f'<div class="hsky">{c["sky"]}</div></div>')
            else:
                arrow = S.ARROW.get(c["dir"], "&middot;")
                gust = ""
                if c.get("gust") is not None and c["kt"] is not None \
                        and c["gust"] - c["kt"] >= 2:
                    gust = f' <span class="gst">g{c["gust"]:.0f}</span>'
                cells += (f'<div class="hcell"><div class="hlab">{c["label"]}</div>'
                          f'<div class="htemp">{c["f"]}&deg;</div>'
                          f'<div class="hwind"><span class="arr">{arrow}</span> '
                          f'{c["dir"] or ""} {c["kt"]:.1f} kt{gust}</div>'
                          f'<div class="hsky">{c["sky"]}</div></div>')
        pk = day["peak_kt"] or 0
        lim = float(day.get("wind_limit", 10))
        scale = float(day.get("wind_scale", 12))
        pct = min(100, pk / scale * 100)
        over = " over" if pk > lim else ""
        gpct = None
        if day.get("gust_kt") is not None:
            gpct = min(100, day["gust_kt"] / scale * 100)
        gmark = (f'<span class="gmark" style="left:{gpct:.1f}%"></span>' if gpct else "")
        gtext = (f' &middot; gusts {day["gust_kt"]:.0f} kt'
                 if day.get("gust_kt") is not None else "")
        ncols = max(1, len(day["cols"]))
        left = (f'<div class="hgrid" style="grid-template-columns:repeat({ncols},1fr)">{cells}</div>'
                f'<div class="wbar-wrap">'
                f'<div class="wbar-top"><span>Peak wind vs. your limit</span>'
                f'<em>{pk:.1f} kt at {day["peak_at"]}{gtext} &middot; limit {lim:g} kt</em></div>'
                f'<div class="wbar"><span class="fill{over}" style="width:{pct:.1f}%"></span>'
                f'{gmark}'
                f'<span class="lim" style="left:{lim / scale * 100:.1f}%"></span></div>'
                f'<div class="wbar-scale"><span>0</span><span>{scale / 3:.0f}</span>'
                f'<span>{scale * 2 / 3:.0f}</span>'
                f'<span>{scale:.0f} kt</span></div></div>')
        gh = (f' <span class="gsth">g{day["gust_kt"]:.0f}</span>'
              if day.get("gust_kt") is not None else "")
        head_right = (f'<span class="bc-peak">peak <b>{pk:.1f} kt</b>{gh} '
                      f'{day["peak_dir"]} &middot; {day["sea"]}</span>')

    turns_html = "".join(
        f'<div class="tt"><div class="tt-k">{"High" if t["k"] == "H" else "Low"}</div>'
        f'<div class="tt-t">{t["hm"]}</div>'
        f'<div class="tt-v">{t["v"]:.1f} ft</div></div>'
        for t in day["turns"])

    sun_parts = day["sun"].split(" &ndash; ")
    svg = tide_svg(prev_turns, day["turns"], next_turns,
                   sun_parts[0], sun_parts[1] if len(sun_parts) > 1 else "--:--")

    rain_meta = (f'<div>Rain &nbsp;<span>{day["rain_in"]:.2f} in</span></div>'
                 if not day["tilt"] else
                 '<div>Precip tilt &nbsp;<span>No forecast</span></div>')

    # Why this day landed where it did, and which way the sea has room to build.
    WHY = {
        "seas": "Seas over limit",
        "seas and wind": "Wind and seas over limit",
        "wind": "Wind over limit",
        "rain": "Too wet",
        "gusts": "Gusts over limit",
        "gusty": "Gusty",
        "showers": "Showers",
        "near limit": "Close to wind limit",
    }
    why = WHY.get(day.get("reason"))
    why_meta = (f'<div>Limiter &nbsp;<span>{why}</span></div>' if why and not day["tilt"]
                else ('<div>Limiter &nbsp;<span>Nothing &mdash; clean</span></div>'
                      if not day["tilt"] else ""))
    fetch_meta = (f'<div>Fetch &nbsp;<span>{day["fetch"]}</span></div>'
                  if day.get("fetch") and not day["tilt"] else "")
    open_html = (f'<div class="open-on">Open &nbsp;<span>{open_on}</span></div>'
                 if open_on else "")

    return f"""
    <article class="{cls}" id="d{day['key'].replace('-', '')}">
      <div class="bc-head">
        <span class="bc-dow">{day['dow']}</span>
        <span class="bc-date">{day['date_label']}{' &middot; today' if day['today'] else ''}</span>
        <span class="chip {day['rating']}">{day['label']}</span>
        <span class="spacer"></span>
        {head_right}
      </div>
      <p class="bc-sum">{day['sum']}</p>
      <div class="bc-body">
        <div>{left}</div>
        <div class="tp">
          <div class="tp-top"><h4>Tide &middot; Everett</h4><span>range {day['range']}</span></div>
          {svg}
          <div class="tp-axis"><span>00</span><span>06</span><span>12</span><span>18</span><span>24</span></div>
          <div class="tp-turns">{turns_html}</div>
        </div>
      </div>
      <div class="bc-meta">
        <div>Sun &nbsp;<span>{day['sun']}</span></div>
        <div>Daylight &nbsp;<span>{day['daylight']}</span></div>
        <div>Moon &nbsp;<span>{day['moon']}</span></div>
        {rain_meta}
        {why_meta}
        {fetch_meta}
        {open_html}
      </div>
      {f'<p class="bc-win"><b>Best window</b>{day["win"]}</p>' if day.get("win") else ''}
      <p class="bc-note">{day['note']}</p>
    </article>"""


# ───────────────────────────────────────────────────────────── harvest ──

def harvest_section(harvest, checked, rule_alert):
    pills = ""
    for p in harvest["pills"]:
        note = p["note"]
        if p.get("to"):
            try:
                n = (datetime.strptime(p["to"], "%Y-%m-%d").date() - date.today()).days
                if n >= 0:
                    note += f"<br>closes in {n} day{'' if n == 1 else 's'}"
            except ValueError:
                pass
        pills += (f'<div class="hpill {p["state"]}"><b>{p["name"]}</b>'
                  f'<u>{p["head"]}</u><i>{note}</i></div>')

    rows = ""
    for r in harvest["table"]:
        rows += (f'<tr><td>{r["fishery"]}</td>'
                 f'<td class="st"><span class="st-tag {r["state"]}">{r["status"]}</span></td>'
                 f'<td class="mono">{r["season"]}</td>'
                 f'<td class="mono">{r["limit"]}</td>'
                 f'<td>{r["notes"]}</td></tr>')

    alert = ""
    if rule_alert:
        items = "".join(f"<li>{esc(t)}</li>" for _, t in rule_alert[:6])
        alert = (f'<p class="rnote"><b>New rule activity since this table was verified</b> '
                 f'&mdash; the WDFW feed has items that mention this water. The table below '
                 f'has <i>not</i> been updated for them; check before you go.<ul>{items}</ul></p>')

    return f"""
  <section class="sec" id="harvest">
    <div class="sec-head">
      <h3>What's open &middot; Marine Area 8-2</h3>
      <span class="src">Verified {checked} &middot; feed checked today</span>
    </div>
    <div class="sec-conf"><i style="width:100%"></i></div>
    <div class="harvest">
      <div class="hpills">{pills}</div>
      {alert}
     <details class="hdet" id="hdet" open>
      <summary class="hsum"><span class="lbl">Season detail, rules and deadlines</span>
        <span class="chev" aria-hidden="true"></span></summary>
      <div class="htable-wrap">
        <table class="ht">
          <colgroup><col style="width:18%"><col style="width:10%"><col style="width:20%">
            <col style="width:15%"><col style="width:37%"></colgroup>
          <thead><tr><th>Fishery</th><th>Status</th><th>Season</th>
            <th>Daily limit</th><th>Rules worth knowing</th></tr></thead>
          <tbody>{rows}</tbody>
        </table>
      </div>
      <div class="hfoot">
        {''.join(f'<p>{p}</p>' for p in harvest.get('footer', []))}
        <p><span class="caution">This is a convenience summary, not the regulations.</span>
        Seasons move on short notice, and this table is verified by hand rather than scraped.
        Confirm on WDFW's <a href="https://wdfw.wa.gov/fishing/regulations/emergency-rules"
        target="_blank" rel="noopener">emergency rules page</a> or the Fish Washington app
        before you leave the dock, and check shellfish on the
        <a href="https://doh.wa.gov/shellfishsafety" target="_blank" rel="noopener">DOH
        Shellfish Safety Map</a> or the biotoxin hotline at <b>1-800-562-5632</b>.</p>
      </div>
     </details>
    </div>
  </section>"""


# ──────────────────────────────────────────────────────────────── page ──

def glance(days):
    out = ""
    for d in days:
        cls = d["rating"] + (" now" if d["today"] else "")
        kt = "&mdash;" if d["tilt"] else f"{round(d['peak_kt'] or 0)}kt"
        out += (f'<a class="gd {cls}" href="#d{d["key"].replace("-", "")}">'
                f'<b>{d["dow"]}</b><i>{d["date"]:%-d}</i><u>{kt}</u></a>')
    return out


def render(cfg, days, verdict, harvest, checked, rule_alert, sources_line, notes):
    tiers = {1: "", 2: "", 3: ""}
    for n, d in enumerate(days):
        prev_t = days[n - 1]["turns"] if n > 0 else []
        next_t = days[n + 1]["turns"] if n + 1 < len(days) else []
        tiers[d["tier"]] += day_card(d, prev_t, next_t, harvest.get("open_on", ""))

    heads = {
        1: ("Days 1&ndash;5 &middot; Marine forecast", cfg["tier1_src"], 92),
        2: ("Days 6&ndash;10 &middot; Model guidance", cfg["tier2_src"], 55),
        3: ("Days 11&ndash;14 &middot; Climate outlook", cfg["tier3_src"], 20),
    }
    sections = ""
    for t in (1, 2, 3):
        title, src, conf = heads[t]
        sections += f"""
  <section class="sec">
    <div class="sec-head"><h3>{title}</h3><span class="src">{src}</span></div>
    <div class="sec-conf"><i style="width:{conf}%"></i></div>
    <div class="stack">{tiers[t]}</div>
  </section>"""

    notes_html = "".join(f"<li>{n}</li>" for n in notes)

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="{esc(cfg['description'])}">
<meta name="color-scheme" content="light dark">
<title>{esc(cfg['title'])}</title>
{THEME}
</head>
<body>
<div class="wrap">
  <header class="mast">
    <div class="mast-id">
      <p class="eyebrow">{cfg['eyebrow']}</p>
      <h1>{esc(cfg['title'])}</h1>
      <p class="mast-sub">{cfg['subtitle']}</p>
    </div>
    <div class="stamp">
      <b>Generated</b>{cfg['generated']}
      <b>Tides</b>NOAA {cfg['station']} Everett
      <b>Datum</b>MLLW, feet
    </div>
  </header>

  <section class="verdict">
    <h2>{verdict['headline']}</h2>
    {''.join(f'<p>{p}</p>' for p in verdict['paragraphs'])}
    <div class="thresh">
      <div>Your go/no-go &nbsp;<span>wind &le; {cfg['wind_limit_kt']} kt &middot;
        seas &le; {cfg['seas_limit_ft']} ft</span></div>
      <div>Scored for &nbsp;<span>general cruising comfort</span></div>
    </div>
    <div class="glance">{glance(days)}</div>
    <div class="glance-key">
      <span><em style="background:var(--go)"></em>Go &mdash; inside your limits</span>
      <span><em style="background:var(--warn)"></em>Marginal</span>
      <span><em style="background:var(--bad)"></em>Stay in</span>
      <span><em style="background:var(--rule-strong)"></em>Tilt only, no forecast</span>
      <span><em style="background:transparent;box-shadow:inset 0 0 0 2px var(--ink)"></em>Today</span>
    </div>
  </section>

{harvest_section(harvest, checked, rule_alert)}
{sections}

  <section class="notes">
    <h3>Reading this page</h3>
    <ul>{notes_html}</ul>
    <div class="srcs">{sources_line}</div>
  </section>
</div>
</body>
</html>
"""
