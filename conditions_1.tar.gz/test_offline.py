"""
Offline end-to-end test.

This session has no egress, so the live HTTP can't be exercised here. Everything
downstream of the fetch can: parsers run against real captured payloads, and the
build/score/render path runs against a realistic synthetic series.
"""
import json
import math
import sys
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

sys.path.insert(0, "/home/claude/gen")
import astro, build, render, scoring as S, sources

TZ = ZoneInfo("America/Los_Angeles")
UTC = ZoneInfo("UTC")
FAILS = []


def check(name, cond, detail=""):
    print(f"  {'PASS' if cond else 'FAIL'}  {name}{'  ' + detail if detail else ''}")
    if not cond:
        FAILS.append(name)


# ── 1. real NOAA payload through the real parser ────────────────────────
print("\n1. NOAA tide parser, against a captured response")
noaa = {"predictions": [
    {"t": "2026-09-13 00:52", "v": "1.127", "type": "L"},
    {"t": "2026-09-13 07:11", "v": "10.238", "type": "H"},
    {"t": "2026-09-13 12:58", "v": "3.065", "type": "L"},
    {"t": "2026-09-13 18:58", "v": "10.854", "type": "H"},
]}
sources._get = lambda url, accept="*/*": json.dumps(noaa).encode()
tides, err = sources.fetch_tides("9447659", date(2026, 9, 13), date(2026, 9, 13))
check("parses without error", err is None, str(err or ""))
check("returns 4 turns", tides and len(tides) == 4)
check("rounds feet", tides and tides[1][2] == 10.24, str(tides[1] if tides else ""))
check("keeps H/L", tides and [t[3] for t in tides] == ["L", "H", "L", "H"])

# ── 2. real PZZ135 text through the real parser ─────────────────────────
print("\n2. NWS zone parser, against a captured product")
pzz = """PZZ135-102145-
Puget Sound and Hood Canal-
235 AM PDT Sun Sep 13 2026

.TODAY...S wind 5 to 10 kt rising to 10 to 15 kt late. Waves around 2 ft.
.TONIGHT...S wind 15 to 20 kt easing to 10 to 15 kt after midnight. Waves 1 to 3 ft.
.MON...S wind 5 to 10 kt. Waves 1 ft or less.
.MON NIGHT...NW wind 5 to 10 kt. Waves 1 ft or less.
.TUE...N wind 5 to 10 kt. Waves 1 ft or less.
$$
"""
sources._get = lambda url, accept="*/*": pzz.encode()
zone, err = sources.fetch_zone("pzz135")
check("parses without error", err is None, str(err or ""))
check("finds issuance", zone and zone["issued"] == "235 AM PDT Sun Sep 13 2026",
      repr(zone["issued"]) if zone else "")
check("finds 5 periods", zone and len(zone["periods"]) == 5,
      str(len(zone["periods"])) if zone else "")
check("wind from 'rising to 15 kt' = 15", sources.zone_wind_kt(zone["periods"][0][1]) == 15,
      str(sources.zone_wind_kt(zone["periods"][0][1])))
check("waves from '1 to 3 ft' = 3", sources.zone_wave_ft(zone["periods"][1][1]) == 3,
      str(sources.zone_wave_ft(zone["periods"][1][1])))

print("\n3. zone period -> real dates, mapped from the product's own issuance")
issued = build.parse_zone_issued("235 AM PDT Sun Sep 13 2026", date(2026, 1, 1))
check("issuance date parsed", issued == date(2026, 9, 13), str(issued))
zmap = build.map_zone_periods(zone, issued)
check("TODAY -> Sep 13", date(2026, 9, 13) in zmap)
check("MON -> Sep 14", date(2026, 9, 14) in zmap and "day" in zmap[date(2026, 9, 14)])
check("TUE -> Sep 15", date(2026, 9, 15) in zmap)
check("MON NIGHT lands on Mon", zmap.get(date(2026, 9, 14), {}).get("night") is not None)

# ── 4. astronomy against known values ───────────────────────────────────
print("\n4. sun and moon")
rise, sset, dl = astro.sun_times(date(2026, 9, 13), 47.99, -122.22, "America/Los_Angeles")
check("Everett sunrise ~06:44", rise.startswith("06:4"), rise)
check("Everett sunset ~19:2x", sset.startswith("19:2"), sset)
check("daylight ~12h4x", dl.startswith("12h 4"), dl)
r2, s2, _ = astro.sun_times(date(2026, 12, 21), 47.99, -122.22, "America/Los_Angeles")
check("solstice is much shorter", r2 > "07:5" and s2 < "16:3", f"{r2}-{s2}")
check("new moon near Sep 11", "New moon" in astro.moon(date(2026, 9, 11)),
      astro.moon(date(2026, 9, 11)))
check("waxing by Sep 19", "gibbous" in astro.moon(date(2026, 9, 21)).lower()
      or "quarter" in astro.moon(date(2026, 9, 19)).lower(),
      astro.moon(date(2026, 9, 19)) + " / " + astro.moon(date(2026, 9, 21)))

# ── 5. scoring rules ────────────────────────────────────────────────────
print("\n5. scoring")
check("6 kt -> light chop 1 ft", S.sea_state(6)[1] == 0.5, str(S.sea_state(6)))
check("10 kt -> 1-2 ft", S.sea_state(10)[1] == 2.0, str(S.sea_state(10)))
check("legal wind + illegal seas = stay in",
      S.rate_day(10, 2.0, 0.0, 10, 10, 1)[1] == "Stay in")
check("that day's limiter is seas", S.limiting_factor(10, 2.0, 0.0, 10, 1) == "seas")
check("calm dry clear = Excellent",
      S.rate_day(4, 0.5, 0.0, 10, 10, 1)[1] == "Excellent", str(S.rate_day(4, 0.5, 0.0, 10, 10, 1)))
check("calm dry grey = Good",
      S.rate_day(4, 0.5, 0.0, 90, 10, 1)[1] == "Good")
check("heavy rain = Stay in", S.rate_day(3, 0.5, 0.40, 90, 10, 1)[1] == "Stay in")
check("light rain = Marginal", S.rate_day(3, 0.5, 0.08, 90, 10, 1)[1] == "Marginal")
check("no forecast = tilt", S.rate_day(None, None, 0, None, 10, 1, has_forecast=False)[0] == "soft")
check("gust over limit caps a clean day at Marginal",
      S.rate_day(6, 0.5, 0.0, 10, 10, 1, gust_kt=13)[1] == "Marginal",
      str(S.rate_day(6, 0.5, 0.0, 10, 10, 1, gust_kt=13)))
check("gusts alone never make a day 'Stay in'",
      S.rate_day(6, 0.5, 0.0, 10, 10, 1, gust_kt=30)[0] == "warn")
check("ragged but legal gusts block Excellent",
      S.rate_day(4, 0.5, 0.0, 10, 10, 1, gust_kt=9.5)[1] == "Good",
      str(S.rate_day(4, 0.5, 0.0, 10, 10, 1, gust_kt=9.5)))
check("calm with tight gusts is still Excellent",
      S.rate_day(4, 0.5, 0.0, 10, 10, 1, gust_kt=6)[1] == "Excellent")
check("no gust data = old behaviour",
      S.rate_day(4, 0.5, 0.0, 10, 10, 1) == S.rate_day(4, 0.5, 0.0, 10, 10, 1, gust_kt=None))
check("limiter names gusts", S.limiting_factor(6, 0.5, 0.0, 10, 1, gust_kt=13) == "gusts")
check("limiter names gustiness", S.limiting_factor(4, 0.5, 0.0, 10, 1, gust_kt=9.5) == "gusty")
check("seas still outrank gusts as the limiter",
      S.limiting_factor(10, 2.0, 0.0, 10, 1, gust_kt=13) == "seas")
check("a day near the wind limit has a named limiter",
      S.limiting_factor(9, 1.0, 0.0, 10, 1) == "near limit")
check("a genuinely clean day has no limiter",
      S.limiting_factor(4, 0.5, 0.0, 10, 1) is None)
check("every Marginal day can name its limiter",
      all(S.limiting_factor(w, s, r, 10, 1, gust_kt=g) is not None
          for w, s, r, g in [(9, 1.0, 0.0, None), (3, 0.5, 0.08, None),
                             (6, 0.5, 0.0, 13), (4, 0.5, 0.0, 9.5)]
          if S.rate_day(w, s, r, 50, 10, 1, gust_kt=g)[0] == "warn"))

check("southerly has the longest fetch", S.fetch_for("S")[1] == 1.3)
check("easterly is sheltered", S.fetch_for("E")[1] < 1.0)
check("unknown direction is neutral", S.fetch_for(None) == (None, 1.0))
check("fetch is config-overridable",
      S.fetch_for("S", {"S": ["test bay", 2.0]}) == ("test bay", 2.0))
check("same wind, more fetch -> bigger sea",
      S.sea_state(8, 1.3)[1] > S.sea_state(8, 0.8)[1],
      f"{S.sea_state(8, 1.3)} vs {S.sea_state(8, 0.8)}")
check("fetch weight 1.0 leaves the old bands alone",
      S.sea_state(10, 1.0) == S.sea_state(10))
check("a sheltered 10 kt easterly stays inside a 1 ft limit",
      S.sea_state(10, 0.8)[1] <= 1.0, str(S.sea_state(10, 0.8)))

check("compass 295 -> WNW", S.compass(295) == "WNW", S.compass(295))
check("compass 305 -> NW  (boundary 303.75)", S.compass(305) == "NW", S.compass(305))
check("compass 359 -> N", S.compass(359) == "N", S.compass(359))
check("m/s -> kt", S.kt(5) == 9.7, str(S.kt(5)))

# ── 6. full pipeline on a synthetic but realistic series ────────────────
print("\n6. end-to-end build + render")
today = datetime.now(TZ).date()

tide_rows = []
for i in range(-1, 16):
    d = today + timedelta(days=i)
    for hh, v, k in (("00:52", 1.1, "L"), ("07:11", 10.2, "H"),
                     ("12:58", 3.1, "L"), ("18:58", 10.9, "H")):
        tide_rows.append((f"{d:%Y-%m-%d}", hh, v, k))

steps = {}
start = datetime.now(UTC).replace(minute=0, second=0, microsecond=0)
for h in range(0, 60):                      # hourly for 2.5 days
    t = start + timedelta(hours=h)
    steps[t.strftime("%Y-%m-%dT%H:%M:%SZ")] = {
        "temp_c": 13 + 5 * math.sin(h / 24 * 2 * math.pi),
        "wind_ms": 2.0 + 1.5 * math.sin(h / 12),
        "wind_dir": (h * 17) % 360, "cloud_pct": 40 + 40 * math.sin(h / 9),
        "rh_pct": 80, "precip_mm": 0.3 if h < 6 else 0.0,
        "symbol": "rain" if h < 6 else "fair_day",
        "gust_ms": (2.0 + 1.5 * math.sin(h / 12)) * 1.4,
    }
t = start + timedelta(hours=60)
while t < start + timedelta(days=15):       # 6-hourly after
    steps[t.strftime("%Y-%m-%dT%H:%M:%SZ")] = {
        "temp_c": 15.0, "wind_ms": 1.6, "wind_dir": 300, "cloud_pct": 10,
        "rh_pct": 70, "precip_mm": 0.0, "symbol": "clearsky_day", "gust_ms": None,
    }
    t += timedelta(hours=6)

model = {"updated": "2026-09-13T11:14:00Z", "steps": steps}
cfg = json.load(open("/home/claude/gen/config.json"))
days, zi = build.build_days(cfg, tide_rows, model, zone, today)

check("14 days built", len(days) == 14, str(len(days)))
check("tier split 5/5/4",
      [sum(1 for d in days if d["tier"] == t) for t in (1, 2, 3)] == [5, 5, 4])
check("day 0 is today", days[0]["today"] is True)
check("weekdays match dates",
      all(d["dow"] == f"{d['date']:%a}" for d in days))
check("every day has tide turns", all(d["turns"] for d in days))
check("every day has a rating", all(d["rating"] in ("go", "warn", "bad", "soft") for d in days))
check("a best day was chosen", any(d.get("best") for d in days))
check("ratings vary across the run", len({d["rating"] for d in days}) >= 2,
      str(sorted({d["rating"] for d in days})))
check("tier-3 days are tilt-only",
      all(d["tilt"] for d in days if d["tier"] == 3) or
      not any(d["tilt"] for d in days))

harvest = json.load(open("/home/claude/gen/harvest.json"))
verdict = {"headline": "test", "paragraphs": ["a", "b"]}
cfg2 = dict(cfg, generated="test", tier1_src="a", tier2_src="b", tier3_src="c")
page = render.render(cfg2, days, verdict, harvest, "13 Sep 2026", [], "srcs", ["note"])

check("page is substantial", len(page) > 40000, f"{len(page)} bytes")
check("marker present", cfg["marker"] in page)
check("14 day cards rendered", page.count('class="bc ') == 14, str(page.count('class="bc ')))
check("14 glance chips", page.count('class="gd ') == 14, str(page.count('class="gd ')))
check("tide SVGs drawn", page.count("<svg") == 14, str(page.count("<svg")))
check("no leftover template braces", "{" not in page.split("<style>")[0])
check("no JS needed", "<script" not in page)
check("harvest pills rendered", page.count('class="hpill ') == 6, str(page.count('class="hpill ')))

# ── 7. the new detail actually reaches the page ─────────────────────────
print("\n7. gusts, limiter and fetch on the page")
check("gust figures rendered in the columns", 'class="gst"' in page)
check("every day states its limiter", page.count("Limiter &nbsp;") == 14,
      str(page.count("Limiter &nbsp;")))
check("gust never printed below the wind it belongs to",
      all(d["gust_kt"] >= d["peak_kt"] for d in days
          if d.get("gust_kt") is not None and d["peak_kt"]))
check("zone override suppresses the model's stale gust",
      all(d.get("gust_kt") is None for d in days
          if not d["tilt"] and d["peak_kt"] and d["peak_kt"] >= 15),
      "zone calls 15-20 kt; model gusts top out near 10")

# …and with no zone product at all, the model's gusts must survive.
nz_days, _ = build.build_days(cfg, tide_rows, model, None, today)
nz_gusts = [d for d in nz_days if d.get("gust_kt") is not None]
check("model gusts survive when nothing overrides them",
      len(nz_gusts) >= 2, f"{len(nz_gusts)} days")
check("those gusts sit at or above their sustained wind",
      all(d["gust_kt"] >= d["peak_kt"] for d in nz_gusts if d["peak_kt"]))
check("missing gusts degrade quietly, not loudly",
      all(d.get("gust_kt") is None or d["gust_kt"] > 0 for d in days)
      and "None" not in page and "nan" not in page.lower())
check("no day is downgraded without naming why",
      all(d.get("reason") for d in days
          if d["rating"] in ("warn", "bad") and not d["tilt"]),
      "offenders: " + str([d["key"] for d in days
                           if d["rating"] in ("warn", "bad")
                           and not d["tilt"] and not d.get("reason")]))
check("no clean day invents a limiter",
      all(not d.get("reason") for d in days
          if d["rating"] == "go" and d["label"] == "Excellent"))
check("fetch label attached", any(d.get("fetch") for d in days if not d["tilt"]))
check("thresholds travel with each day",
      all(d.get("wind_limit") == cfg["wind_limit_kt"] for d in days))

print("\n8. the wind bar follows config, not a hardcoded 10")
cfg12 = dict(cfg, wind_limit_kt=14, seas_limit_ft=2)
d12, _ = build.build_days(cfg12, tide_rows, model, zone, today)
p12 = render.render(dict(cfg12, generated="t", tier1_src="a", tier2_src="b", tier3_src="c"),
                    d12, verdict, harvest, "13 Sep 2026", [], "srcs", ["note"])
check("bar label reads the configured limit", "limit 14 kt" in p12)
check("old hardcoded limit is gone", "limit 10 kt" not in p12)
check("scale end follows the limit", ">17 kt<" in p12 or ">16 kt<" in p12,
      "scale labels: " + ",".join(sorted(set(
          x for x in p12.split('class="wbar-scale"')[1][:200].split("<span>")
          if "kt" in x))[:3]))
check("a higher limit lets more days through",
      sum(1 for d in d12 if d["rating"] == "go") >=
      sum(1 for d in days if d["rating"] == "go"),
      f'{sum(1 for d in d12 if d["rating"] == "go")} vs '
      f'{sum(1 for d in days if d["rating"] == "go")}')

open("/tmp/rendered.html", "w").write(page)
print(f"\n  wrote /tmp/rendered.html ({len(page)} bytes)")

print("\n" + ("ALL CHECKS PASSED" if not FAILS else f"{len(FAILS)} FAILED: {FAILS}"))
sys.exit(1 if FAILS else 0)
