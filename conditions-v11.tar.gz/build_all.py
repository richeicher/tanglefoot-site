#!/usr/bin/env python3
"""
Build every area, then the landing page that indexes them.

    build_all.py                 build and publish everything
    build_all.py --dry-run       build everything, install nothing
    build_all.py --check         test every area's sources, write nothing

One area failing does not stop the others, and it does not remove it from the
index — the landing page shows it as unavailable instead. A missing row reads
as "that area does not exist", which is a worse lie than "the data is down".

The index is assembled from the summaries the builds themselves return, so it
cannot drift from the pages it links to: same run, same numbers.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from datetime import datetime
from zoneinfo import ZoneInfo

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import generate
import render

AREAS_DIR = os.path.join(HERE, "areas")
SITE_FILE = os.path.join(HERE, "site.json")


def log(msg):
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}", flush=True)


def area_configs(d):
    if not os.path.isdir(d):
        return []
    return sorted(os.path.join(d, f) for f in os.listdir(d) if f.endswith(".json"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--areas", default=AREAS_DIR)
    args = ap.parse_args()

    v = generate.version_line()
    if v:
        log(f"conditions {v}")

    cfgs = area_configs(args.areas)
    if not cfgs:
        log(f"no area configs in {args.areas} — run newarea.py --all first")
        return 1
    log(f"{len(cfgs)} area(s): " + ", ".join(os.path.basename(c) for c in cfgs))

    summaries, failures = [], 0
    for path in cfgs:
        name = os.path.basename(path)
        log(f"── {name} " + "─" * max(0, 46 - len(name)))
        try:
            code, summary = generate.run_one(path, check=args.check,
                                             dry_run=args.dry_run)
        except Exception as e:                      # one bad config can't stop the rest
            log(f"  !! {name} raised {type(e).__name__}: {e}")
            summaries.append({"area": name, "ok": False,
                              "error": f"{type(e).__name__}: {e}", "order": 99})
            failures += 1
            continue
        if code != 0:
            failures += 1
        summaries.append(summary)

    if args.check:
        log(f"check complete — {failures} area(s) with problems")
        return 1 if failures else 0

    # ── landing page ────────────────────────────────────────────────────
    site = {}
    if os.path.exists(SITE_FILE):
        with open(SITE_FILE) as fh:
            site = json.load(fh)
    site.setdefault("title", "Boating Conditions for Overthinkers")
    site.setdefault("eyebrow", "Puget Sound &middot; Salish Sea")
    site.setdefault("subtitle", "14-day outlooks by marine area")
    site.setdefault("description",
                    "14-day boating conditions by Washington marine area - tides, "
                    "currents, wind against suggested limits, and what's open.")
    site.setdefault("output", "/var/www/tanglefoot/conditions/index.html")

    tz = ZoneInfo(site.get("timezone", "America/Los_Angeles"))
    generated = f"{datetime.now(tz):%a %-d %b %Y, %H:%M %Z}"
    page = render.landing_page(site, summaries, generated)

    if len(page) < 1500 or "</html>" not in page:
        log(f"REFUSED: landing page is {len(page)} bytes / malformed")
        return 1
    live = [s for s in summaries if s.get("ok")]
    if not live:
        log("REFUSED: no area built successfully, not publishing an empty index")
        return 1

    if args.dry_run:
        fd, tmp = tempfile.mkstemp(prefix="conditions-index-", suffix=".html")
        with os.fdopen(fd, "w") as fh:
            fh.write(page)
        os.chmod(tmp, 0o644)
        log(f"dry run — index written to {tmp}")
    else:
        out = site["output"]
        d = os.path.dirname(out)
        os.makedirs(d, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
        with os.fdopen(fd, "w") as fh:
            fh.write(page)
        os.chmod(tmp, 0o644)
        os.replace(tmp, out)
        log(f"index: {len(page)} bytes to {out} "
            f"({len(live)}/{len(summaries)} areas live)")

    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
