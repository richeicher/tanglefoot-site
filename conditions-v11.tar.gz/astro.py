"""Sun and moon, computed locally. No network, no dependencies."""

from __future__ import annotations

import math
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo


def _solar_minutes(d: date, lat: float, lon: float, event: str):
    """
    NOAA solar calculator. Returns minutes past UTC midnight for sunrise or
    sunset, or None above the arctic/antarctic circles where the sun does not
    cross the horizon that day.
    """
    jd = d.toordinal() + 1721424.5
    jc = (jd - 2451545.0) / 36525.0

    gml = (280.46646 + jc * (36000.76983 + jc * 0.0003032)) % 360
    gma = 357.52911 + jc * (35999.05029 - 0.0001537 * jc)
    ecc = 0.016708634 - jc * (0.000042037 + 0.0000001267 * jc)
    seq = (math.sin(math.radians(gma)) * (1.914602 - jc * (0.004817 + 0.000014 * jc))
           + math.sin(math.radians(2 * gma)) * (0.019993 - 0.000101 * jc)
           + math.sin(math.radians(3 * gma)) * 0.000289)
    stl = gml + seq
    sal = stl - 0.00569 - 0.00478 * math.sin(math.radians(125.04 - 1934.136 * jc))
    oe = 23 + (26 + (21.448 - jc * (46.815 + jc * (0.00059 - jc * 0.001813))) / 60) / 60
    oec = oe + 0.00256 * math.cos(math.radians(125.04 - 1934.136 * jc))
    decl = math.degrees(math.asin(math.sin(math.radians(oec)) * math.sin(math.radians(sal))))

    y = math.tan(math.radians(oec / 2)) ** 2
    eqt = 4 * math.degrees(
        y * math.sin(2 * math.radians(gml))
        - 2 * ecc * math.sin(math.radians(gma))
        + 4 * ecc * y * math.sin(math.radians(gma)) * math.cos(2 * math.radians(gml))
        - 0.5 * y * y * math.sin(4 * math.radians(gml))
        - 1.25 * ecc * ecc * math.sin(2 * math.radians(gma))
    )

    cos_ha = (math.cos(math.radians(90.833))
              / (math.cos(math.radians(lat)) * math.cos(math.radians(decl)))
              - math.tan(math.radians(lat)) * math.tan(math.radians(decl)))
    if not -1 <= cos_ha <= 1:
        return None
    ha = math.degrees(math.acos(cos_ha))
    noon = 720 - 4 * lon - eqt
    return noon - 4 * ha if event == "rise" else noon + 4 * ha


def sun_times(d: date, lat: float, lon: float, tz: str):
    """('HH:MM', 'HH:MM', 'Xh Ym') local sunrise, sunset, daylight length."""
    zone = ZoneInfo(tz)
    out = []
    for event in ("rise", "set"):
        m = _solar_minutes(d, lat, lon, event)
        if m is None:
            return ("--:--", "--:--", "--")
        utc = datetime(d.year, d.month, d.day, tzinfo=ZoneInfo("UTC")) + timedelta(minutes=m)
        out.append(utc.astimezone(zone))
    rise, sset = out
    mins = int(round((sset - rise).total_seconds() / 60))
    return (rise.strftime("%H:%M"), sset.strftime("%H:%M"),
            f"{mins // 60}h {mins % 60:02d}m")


_SYNODIC = 29.530588853
_REF = datetime(2000, 1, 6, 18, 14)  # a known new moon, UTC


def moon(d: date):
    """('Waxing crescent, 32%',) style description: phase name + illumination."""
    days = (datetime(d.year, d.month, d.day, 12) - _REF).total_seconds() / 86400.0
    phase = (days % _SYNODIC) / _SYNODIC                  # 0 = new, .5 = full
    illum = (1 - math.cos(2 * math.pi * phase)) / 2       # 0..1

    if phase < 0.02 or phase > 0.98:
        name = "New moon"
    elif phase < 0.23:
        name = "Waxing crescent"
    elif phase < 0.27:
        name = "First quarter"
    elif phase < 0.48:
        name = "Waxing gibbous"
    elif phase < 0.52:
        name = "Full moon"
    elif phase < 0.73:
        name = "Waning gibbous"
    elif phase < 0.77:
        name = "Last quarter"
    else:
        name = "Waning crescent"
    return f"{name}, {round(illum * 100)}%"
