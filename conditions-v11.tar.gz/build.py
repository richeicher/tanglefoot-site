"""Assemble the fortnight: fold sources into the day structures the page renders."""

from __future__ import annotations

import math
import re
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

import astro
import scoring as S

UTC = ZoneInfo("UTC")

# The four columns. Local hours, chosen because the model's 6-hourly steps land
# exactly here in PDT, so no interpolation is ever needed at range.
COLUMNS = [(5, "5 AM"), (11, "11 AM"), (17, "5 PM"), (23, "11 PM")]


def _iso(dt: datetime) -> str:
    return dt.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _step_at(steps, local_dt):
    """Model step for a local time, tolerating an hour either side."""
    for delta in (0, -1, 1):
        key = _iso(local_dt + timedelta(hours=delta))
        if key in steps:
            return steps[key]
    return None


def _day_steps(steps, d: date, tz):
    """Every model step falling inside this local calendar day."""
    start = datetime(d.year, d.month, d.day, 0, 0, tzinfo=tz)
    end = start + timedelta(days=1)
    out = []
    for k, v in steps.items():
        try:
            t = datetime.strptime(k, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
        except ValueError:
            continue
        if start <= t < end:
            out.append((t.astimezone(tz), v))
    return sorted(out)


# ───────────────────────────────────────────────────── zone period mapping ──

_DOW = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]


def map_zone_periods(zone, issued_date: date):
    """
    Map the product's period names onto real dates, counting from the product's
    own issuance date rather than today — the file is often a few hours or a
    day old, and mapping from today silently shifts everything.
    """
    if not zone:
        return {}
    out, cursor = {}, issued_date
    for name, text in zone["periods"]:
        n = name.upper().strip()
        night = n.endswith("NIGHT")
        base = n.replace(" NIGHT", "").strip()
        if base in ("TODAY", "THIS AFTERNOON"):
            day = issued_date
        elif base in ("TONIGHT",):
            day = issued_date
        elif base in _DOW:
            day = cursor
            while _DOW[day.weekday()] != base:
                day += timedelta(days=1)
                if (day - issued_date).days > 9:
                    break
            cursor = day
        else:
            continue
        out.setdefault(day, {})["night" if night else "day"] = text
    return out


def parse_zone_issued(issued: str, fallback: date) -> date:
    """'235 AM PDT Sun Sep 13 2026' -> date(2026, 9, 13)."""
    if not issued:
        return fallback
    m = re.search(r"(\w{3})\s+(\w{3})\s+(\d{1,2})\s+(\d{4})", issued)
    if not m:
        return fallback
    try:
        return datetime.strptime(f"{m.group(2)} {m.group(3)} {m.group(4)}",
                                 "%b %d %Y").date()
    except ValueError:
        return fallback


# ───────────────────────────────────────────────────────────────── tides ──

def tide_index(tides):
    """Group NOAA turns by date string, and keep a flat ordered list."""
    by_day = {}
    for d, hm, v, k in tides:
        by_day.setdefault(d, []).append({"hm": hm, "v": v, "k": k})
    for v in by_day.values():
        v.sort(key=lambda t: t["hm"])
    return by_day


def tide_range(turns):
    if not turns:
        return None
    vs = [t["v"] for t in turns]
    return round(max(vs) - min(vs), 1)


# ──────────────────────────────────────────────────────────────── prose ──

def _trend(vals):
    vals = [v for v in vals if v is not None]
    if len(vals) < 2:
        return "steady"
    if vals[-1] > vals[0] + 1:
        return "building"
    if vals[-1] < vals[0] - 1:
        return "easing"
    return "steady"


def day_summary(cols, rain_in, peak_kt, peak_label, cloud_first, cloud_last,
                high_f, limit_reason, gust_kt=None, peak_dir=None,
                fetch_label=None):
    """One or two plain sentences describing the shape of the day."""
    bits = []

    if rain_in >= 0.25:
        bits.append(f"Wet — {rain_in:.2f} in through the day")
    elif rain_in >= 0.05:
        bits.append(f"Showery, {rain_in:.2f} in")
    elif rain_in > 0:
        bits.append("A trace of rain, not enough to matter")
    else:
        bits.append("Dry")

    if cloud_first is not None and cloud_last is not None:
        if cloud_first > 70 and cloud_last < 30:
            bits.append("grey to start and clearing out by evening")
        elif cloud_first < 30 and cloud_last > 70:
            bits.append("clear early, clouding over later")
        elif cloud_first > 70 and cloud_last > 70:
            bits.append("overcast all day")
        elif cloud_first < 25 and cloud_last < 25:
            bits.append("clear throughout")

    winds = [c["kt"] for c in cols if c["kt"] is not None]
    if winds:
        t = _trend(winds)
        where = f" {peak_dir}" if peak_dir else ""
        if t == "building":
            bits.append(f"wind building to {peak_kt:.1f} kt{where} by {peak_label}")
        elif t == "easing":
            bits.append(f"wind easing off through the day, peaking {peak_kt:.1f} kt{where}")
        else:
            bits.append(f"wind steady, peaking {peak_kt:.1f} kt{where}")
        if S.is_gusty(peak_kt, gust_kt):
            bits.append(f"gusting {gust_kt:.0f}")

    if high_f:
        bits.append(f"{high_f}&deg;F at the warmest")

    text = bits[0] + ", " + ", ".join(bits[1:]) + "." if len(bits) > 1 else bits[0] + "."
    text = text[0].upper() + text[1:]

    # Why this day is rated the way it is, in words, on the day itself.
    if limit_reason == "seas":
        text += " Wind stays legal but the water does not &mdash; seas are what rule this one out"
        text += f", with the fetch running {fetch_label}." if fetch_label else "."
    elif limit_reason == "seas and wind":
        text += " Both the wind and the sea are over the suggested limits."
    elif limit_reason == "wind":
        text += " Over the suggested wind limit."
    elif limit_reason == "rain":
        text += " Too wet to be worth it."
    elif limit_reason == "gusts":
        text += (f" Sustained wind is inside the suggested limit; the gusts to {gust_kt:.0f} kt "
                 f"are not. Legal, but you will be working for it.")
    elif limit_reason == "gusty":
        text += " Inside the limits, but ragged &mdash; the puffs run well above the average."
    elif limit_reason == "showers":
        text += " Showers are the only thing against it."
    elif limit_reason == "near limit":
        text += " Inside the limits, but not by much &mdash; watch it before you commit."
    return text


def best_window(hourly, wind_limit, sunrise, sunset, seas_limit=None,
                fetch_table=None):
    """
    Longest run of daylight hours that are dry, inside the wind limit, and —
    when a seas limit is given — inside that too. Testing wind alone was wrong:
    it could offer a window during the exact hours the chop was over the line.

    hourly = [(local_dt, step)] for the day.
    """
    if not hourly:
        return None
    sr = int(sunrise.split(":")[0]) if sunrise != "--:--" else 6
    ss = int(sunset.split(":")[0]) if sunset != "--:--" else 20

    ok, best, cur = [], None, None
    for t, v in hourly:
        if not (sr <= t.hour <= ss):
            continue
        w = S.kt(v.get("wind_ms"))
        p = v.get("precip_mm") or 0
        good = (w is not None and w <= wind_limit and p < 0.1)
        if good and seas_limit is not None:
            _, fw = S.fetch_for(S.compass(v.get("wind_dir")), fetch_table)
            _, ft = S.sea_state(w, fw)
            good = ft is None or ft <= seas_limit
        if good:
            cur = [t, t] if cur is None else [cur[0], t]
        else:
            if cur and (best is None or (cur[1] - cur[0]) > (best[1] - best[0])):
                best = cur
            cur = None
    if cur and (best is None or (cur[1] - cur[0]) > (best[1] - best[0])):
        best = cur
    if not best:
        return None
    a, b = best
    if a == b:
        return None
    span = (b - a).total_seconds() / 3600
    if span >= (ss - sr) * 0.8:
        return "ANY"          # usable essentially all day; the caller words it
    return f"{a:%-I %p} to {b:%-I %p}"


def current_at(events, when):
    """
    Speed in knots at a moment, cosine-interpolated between the surrounding
    slack/max events — the same shape the tide curve uses, because a tidal
    current is the same harmonic seen as flow instead of height.

    events = [(datetime, knots, kind)] sorted. Returns None outside their span.
    """
    if not events or len(events) < 2:
        return None
    if when < events[0][0] or when > events[-1][0]:
        return None
    for i in range(len(events) - 1):
        t0, v0, _ = events[i]
        t1, v1, _ = events[i + 1]
        if t0 <= when <= t1:
            span = (t1 - t0).total_seconds()
            if span <= 0:
                return v0
            f = (when - t0).total_seconds() / span
            return v0 + (v1 - v0) * (1 - math.cos(math.pi * f)) / 2
    return None


def current_note(day_events, meta):
    """One line naming the day's strongest set and when the water is still."""
    if not day_events:
        return None
    slacks = [e for e in day_events if e[2] == "slack"]
    runs = [e for e in day_events if e[2] in ("flood", "ebb")]
    parts = []
    if runs:
        big = max(runs, key=lambda e: abs(e[1]))
        set_dir = ""
        if meta:
            d = meta.get("flood_dir") if big[2] == "flood" else meta.get("ebb_dir")
            if d not in (None, ""):
                try:
                    set_dir = f" setting {float(d):.0f}&deg;"
                except (TypeError, ValueError):
                    set_dir = ""
        parts.append(f"Strongest {big[2]} {abs(big[1]):.2f} kt at "
                     f"{big[0]:%-I:%M %p}{set_dir}.")
    if slacks:
        parts.append("Slack " + ", ".join(f"{s[0]:%-I:%M %p}" for s in slacks[:4]) + ".")
    return " ".join(parts) if parts else None


def tide_note(turns, rng):
    if not turns:
        return ""
    highs = [t for t in turns if t["k"] == "H"]
    lows = [t for t in turns if t["k"] == "L"]
    parts = [f"Range {rng} ft."] if rng else []
    if highs:
        big = max(highs, key=lambda t: t["v"])
        parts.append(f"High {big['v']:.1f} ft at {big['hm']}.")
    if lows:
        small = min(lows, key=lambda t: t["v"])
        parts.append(f"Low {small['v']:.1f} ft at {small['hm']}.")
    if rng is not None and rng < 8.2:
        parts.append("Neap tides — little water moving.")
    elif rng is not None and rng > 10.5:
        parts.append("Big range — expect real current in the channel.")
    return " ".join(parts)


# ──────────────────────────────────────────────────────────────── build ──

def group_currents(currents, tz):
    """
    {date: [(local_datetime, knots, kind)]} plus a flat sorted list spanning the
    whole run, so a column time near midnight can interpolate across the day
    boundary instead of falling off the end of its own day.
    """
    if not currents:
        return {}, [], None
    by_day, flat = {}, []
    for d_str, hm, kts, kind in currents.get("events", []):
        try:
            y, m, dd = (int(x) for x in d_str.split("-"))
            hh, mm = (int(x) for x in hm.split(":"))
        except (ValueError, AttributeError):
            continue
        t = datetime(y, m, dd, hh, mm, tzinfo=tz)
        by_day.setdefault(t.date(), []).append((t, kts, kind))
        flat.append((t, kts, kind))
    for v in by_day.values():
        v.sort(key=lambda e: e[0])
    flat.sort(key=lambda e: e[0])
    return by_day, flat, currents.get("meta")


def build_days(cfg, tides, model, zone, today: date, currents=None):
    tz = ZoneInfo(cfg["timezone"])
    by_day = tide_index(tides) if tides else {}
    steps = model["steps"] if model else {}

    issued = parse_zone_issued(zone.get("issued") if zone else None, today)
    zmap = map_zone_periods(zone, issued)

    cur_by_day, cur_flat, cur_meta = group_currents(currents, tz)

    days = []
    for i in range(14):
        d = today + timedelta(days=i)
        key = f"{d:%m-%d}"
        turns = by_day.get(f"{d:%Y-%m-%d}", [])
        rise, sset, daylight = astro.sun_times(d, cfg["lat"], cfg["lon"], cfg["timezone"])

        hourly = _day_steps(steps, d, tz)
        has_model = bool(hourly)

        def _col(label, st, when=None):
            cur = current_at(cur_flat, when) if (cur_flat and when) else None
            return {
                "label": label,
                "f": S.f(st.get("temp_c")) if st else None,
                "kt": S.kt(st.get("wind_ms")) if st else None,
                "gust": S.kt(st.get("gust_ms")) if st else None,
                "dir": S.compass(st.get("wind_dir")) if st else None,
                "sky": S.sky_phrase(st.get("symbol"), st.get("cloud_pct")) if st else "No guidance",
                "sym": st.get("symbol") if st else None,
                "cur": None if cur is None else round(cur, 2),
            }

        cols = []
        if i == 0 and hourly:
            # Today's early columns are already in the past. Lead with a "now"
            # column from the earliest step the run actually has, then keep only
            # the standard hours still ahead of us.
            now_local = datetime.now(tz)
            first_t, first_v = hourly[0]
            stamp = f"{first_t:%-I %p}".replace("AM", "AM").replace("PM", "PM")
            cols.append(_col(f"{stamp} &middot; now", first_v, first_t))
            for hour, label in COLUMNS:
                local = datetime(d.year, d.month, d.day, hour, tzinfo=tz)
                if local <= first_t + timedelta(minutes=30):
                    continue
                st = _step_at(steps, local)
                if st:
                    cols.append(_col(label, st, local))
            cols = cols[:4]
        else:
            for hour, label in COLUMNS:
                local = datetime(d.year, d.month, d.day, hour, tzinfo=tz)
                cols.append(_col(label, _step_at(steps, local), local))

        temps = [S.f(v.get("temp_c")) for _, v in hourly if v.get("temp_c") is not None]
        winds = [(t, S.kt(v.get("wind_ms"))) for t, v in hourly if v.get("wind_ms") is not None]
        clouds = [v.get("cloud_pct") for _, v in hourly if v.get("cloud_pct") is not None]
        rain_mm = sum(v.get("precip_mm") or 0 for _, v in hourly)

        gusts = [S.kt(v.get("gust_ms")) for _, v in hourly
                 if v.get("gust_ms") is not None]
        peak_gust = max(gusts) if gusts else None

        peak_kt = max((w for _, w in winds), default=None)
        peak_t = max(winds, key=lambda x: x[1])[0] if winds else None
        peak_label = f"{peak_t:%-I %p}".lower().replace("am", "AM").replace("pm", "PM") if peak_t else "&mdash;"
        peak_dir = None
        if peak_t:
            for t, v in hourly:
                if t == peak_t:
                    peak_dir = S.compass(v.get("wind_dir"))
        rain_in = S.inches(rain_mm)
        cloud_avg = sum(clouds) / len(clouds) if clouds else None

        # The zone forecast overrides the model where they disagree: it is the
        # authoritative marine product at short range.
        zone_txt = zmap.get(d, {})
        zone_kt = zone_wave = None
        split = None
        if zone_txt.get("day"):
            from sources import zone_wind_kt, zone_wave_ft
            zone_kt = zone_wind_kt(zone_txt["day"])
            zone_wave = zone_wave_ft(zone_txt["day"])
            if zone_kt and peak_kt and abs(zone_kt - peak_kt) >= 4:
                split = (f"<span class='flag'>Sources split</span> &mdash; the zone forecast "
                         f"has wind to {zone_kt} kt, the model {peak_kt:.1f} kt. "
                         f"Taking the zone forecast; it is the authoritative product at this range.")

        eff_kt = max([x for x in (peak_kt, zone_kt) if x is not None], default=None)

        # Gusts come from the model. When the zone forecast overrides the model's
        # wind, the model's gust belongs to a wind we are no longer reporting —
        # and printing "peak 15 kt g9" would be a visible contradiction. We have
        # no gust figure consistent with the wind we're showing, so show none.
        if peak_gust is not None and eff_kt is not None and peak_gust < eff_kt:
            peak_gust = None

        # Sea state is wind-driven, but how much sea a given wind builds depends
        # on how far it has run. Weight the wind by the fetch of its own sector
        # before banding it.
        fetch_label, fetch_w = S.fetch_for(peak_dir, cfg.get("fetch"))
        sea_label, sea_ft = S.sea_state(eff_kt, fetch_w)
        if zone_wave:
            sea_ft = max(sea_ft or 0, zone_wave)
            if zone_wave >= 2:
                sea_label = f"{zone_wave} ft (zone forecast)"

        tier = 1 if i < 5 else (2 if i < 10 else 3)
        rating, label = S.rate_day(eff_kt, sea_ft, rain_in, cloud_avg,
                                   cfg["wind_limit_kt"], cfg["seas_limit_ft"],
                                   has_forecast=has_model, gust_kt=peak_gust)
        reason = S.limiting_factor(eff_kt, sea_ft, rain_in,
                                   cfg["wind_limit_kt"], cfg["seas_limit_ft"],
                                   gust_kt=peak_gust)

        rng = tide_range(turns)
        note = tide_note(turns, rng)
        if split:
            note = split + " " + note

        day = {
            "i": i, "date": d, "key": key, "tier": tier,
            "dow": f"{d:%a}", "date_label": f"{d:%b %-d}",
            "today": i == 0,
            "rating": rating, "label": label,
            "tilt": not has_model,
            "cols": cols,
            "peak_kt": eff_kt, "peak_at": peak_label, "peak_dir": peak_dir or "&mdash;",
            "gust_kt": peak_gust,
            "gusty": S.is_gusty(eff_kt, peak_gust),
            "sea": sea_label, "seas_ft": sea_ft,
            "fetch": fetch_label, "fetch_w": fetch_w,
            "reason": reason,
            # Wind through the day for the trace: minutes past local midnight.
            # Kept at the model's own resolution — no interpolation, so a
            # 6-hourly day is visibly four points and not a smooth invention.
            "wind_series": [(t.hour * 60 + t.minute, w) for t, w in winds],
            "zone_kt": zone_kt,
            "currents": cur_by_day.get(d, []),
            "cur_note": current_note(cur_by_day.get(d, []), cur_meta),
            "cur_max": (max((abs(e[1]) for e in cur_by_day.get(d, [])), default=None)),
            # Thresholds travel with the day so the renderer never hardcodes them.
            "wind_limit": cfg["wind_limit_kt"],
            "seas_limit": cfg["seas_limit_ft"],
            "wind_scale": max(12.0, float(cfg["wind_limit_kt"]) * 1.2),
            "station_name": cfg.get("station_name", ""),
            "rain_in": rain_in,
            "high_f": max(temps) if temps else None,
            "cloud_avg": cloud_avg,
            "sun": f"{rise} &ndash; {sset}", "daylight": daylight,
            "moon": astro.moon(d),
            "range": f"{rng} ft" if rng else "&mdash;",
            "turns": turns,
            "note": note,
            "zone_text": zone_txt.get("day"),
            "tag": "NWS + model" if zone_txt.get("day") else ("Model only" if has_model else "CPC tilt"),
        }
        day["sum"] = day_summary(cols, rain_in, eff_kt or 0, peak_label,
                                 clouds[0] if clouds else None,
                                 clouds[-1] if clouds else None,
                                 day["high_f"], reason,
                                 gust_kt=peak_gust, peak_dir=peak_dir,
                                 fetch_label=fetch_label) if has_model else \
            "Past the model's reach. Only the seasonal tilt from here — the tide below is still exact."
        w = best_window(hourly, cfg["wind_limit_kt"], rise, sset,
                        seas_limit=cfg["seas_limit_ft"],
                        fetch_table=cfg.get("fetch")) if has_model else None
        if w == "ANY":
            day["win"] = "Any time &mdash; inside the limits right through the daylight hours."
        elif w:
            day["win"] = f"About {w}."
        else:
            day["win"] = None
        day["score"] = S.score_for_ranking(day)
        days.append(day)

    best = max((d for d in days if not d["tilt"]), key=lambda x: x["score"], default=None)
    if best and best["rating"] == "go":
        best["best"] = True
        best["label"] = "Best day"
    return days, issued
