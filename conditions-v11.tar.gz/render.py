"""
Render the page as static HTML.

The published version builds its tiles in JavaScript at load time. This one
emits finished markup with the tide charts already drawn as inline SVG, so the
page needs no script at all — faster, works with JS off, and indexable if the
multi-area idea ever happens.
"""

from __future__ import annotations

import html
import math
import os
from datetime import date, datetime, timedelta

import scoring as S

HERE = os.path.dirname(os.path.abspath(__file__))
THEME = open(os.path.join(HERE, "theme.html")).read()


def esc(s):
    return html.escape(str(s), quote=False) if s is not None else ""


# ───────────────────────────────────────────────────────────── tide svg ──

def _mins(hm):
    h, m = hm.split(":")
    return int(h) * 60 + int(m)


def _height_at(turn_list, minute):
    """Cosine interpolation between turning points, as the JS version did."""
    a = b = None
    for t in turn_list:
        if t[0] <= minute:
            a = t
        if t[0] >= minute and b is None:
            b = t
    if a is None:
        return b[1] if b else 0.0
    if b is None or b[0] == a[0]:
        return a[1]
    p = (minute - a[0]) / (b[0] - a[0])
    return (a[1] + b[1]) / 2 - ((b[1] - a[1]) / 2) * math.cos(math.pi * p)


def tide_svg(prev_turns, turns, next_turns, sunrise, sunset):
    """One day's tide curve, with neighbouring days as anchors so the ends aren't flat."""
    W, H = 300, 88
    PADL, PADR, PADT, PADB = 22, 6, 9, 14
    LO, HI = 0, 12

    flat = ([(_mins(t["hm"]) - 1440, t["v"]) for t in prev_turns]
            + [(_mins(t["hm"]), t["v"]) for t in turns]
            + [(_mins(t["hm"]) + 1440, t["v"]) for t in next_turns])
    flat.sort()
    if not flat:
        return '<svg viewBox="0 0 300 88" role="img" aria-label="no tide data"></svg>'

    def x(m):
        return PADL + (m / 1440) * (W - PADL - PADR)

    def y(v):
        return H - PADB - ((v - LO) / (HI - LO)) * (H - PADT - PADB)

    pts = [(x(m), y(_height_at(flat, m))) for m in range(0, 1441, 20)]
    line = "M" + " L".join(f"{px:.1f} {py:.1f}" for px, py in pts)
    area = f"{line} L{x(1440):.1f} {H - PADB} L{x(0):.1f} {H - PADB} Z"

    band = ""
    if sunrise != "--:--" and sunset != "--:--":
        sx, ex = x(_mins(sunrise)), x(_mins(sunset))
        band = (f'<rect x="{sx:.1f}" y="{PADT}" width="{ex - sx:.1f}" '
                f'height="{H - PADT - PADB}" fill="var(--day-band)"/>')

    grid = ""
    for v in (0, 4, 8, 12):
        gy = y(v)
        grid += (f'<line x1="{PADL}" y1="{gy:.1f}" x2="{W - PADR}" y2="{gy:.1f}" '
                 f'stroke="var(--rule)" stroke-width=".6"/>'
                 f'<text x="{PADL - 4}" y="{gy + 3:.1f}" text-anchor="end" '
                 f'font-family="IBM Plex Mono,monospace" font-size="7.5" '
                 f'fill="var(--ink-faint)">{v}</text>')

    marks = "".join(
        f'<circle cx="{x(_mins(t["hm"])):.1f}" cy="{y(t["v"]):.1f}" r="2.6" '
        f'fill="var(--surface)" stroke="var(--tide-line)" stroke-width="1.5"/>'
        for t in turns)

    return (f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Tide curve">'
            f'{band}{grid}'
            f'<path d="{area}" fill="var(--tide-fill)" opacity=".75"/>'
            f'<path d="{line}" fill="none" stroke="var(--tide-line)" '
            f'stroke-width="1.8" stroke-linejoin="round"/>{marks}</svg>')


def _share_tags(cfg):
    """
    Open Graph and Twitter tags. Without these a link pasted into Facebook shows
    as a bare URL with no title or description, which reads as spam and gets
    scrolled past. The share title carries the area, so nobody in a
    Puget-Sound-wide group mistakes one area's page for their own water.
    """
    url = cfg.get("canonical", "")
    area = cfg.get("area", "")
    t = f"{cfg['title']}{' &middot; ' + area if area else ''}"
    tags = [
        f'<meta property="og:title" content="{esc(t)}">',
        f'<meta property="og:description" content="{esc(cfg["description"])}">',
        '<meta property="og:type" content="website">',
        '<meta name="twitter:card" content="summary">',
        f'<meta name="twitter:title" content="{esc(t)}">',
        f'<meta name="twitter:description" content="{esc(cfg["description"])}">',
    ]
    if url:
        tags.append(f'<meta property="og:url" content="{esc(url)}">')
        tags.append(f'<link rel="canonical" href="{esc(url)}">')
    return "\n".join(tags)


# ───────────────────────────────────────────────────────────── wind svg ──

def wind_svg(series, limit, scale, sunrise, sunset, zone_kt=None):
    """
    Wind through the day against the limit line.

    `series` is [(minutes_past_midnight, kt)] from the model. Past day three the
    model is 6-hourly, so this is drawn as points joined by straight lines and
    the markers are left visible — a smooth curve there would imply resolution
    the data does not have.

    The zone forecast, when it disagrees, is drawn as its own dashed line rather
    than blended in. The two are different products and the reader should be
    able to see them disagree.
    """
    # The viewBox is wide on purpose. This panel spans the full card, and a
    # 300-unit box inside a 600px element letterboxes: the browser fits by
    # height and paints the chart centred at 300px, leaving the axis below it
    # spanning a width the chart doesn't occupy.
    W, H = 600, 74
    PADL, PADR, PADT, PADB = 30, 10, 8, 13
    if not series:
        return ""

    def x(m):
        return PADL + (max(0, min(1440, m)) / 1440) * (W - PADL - PADR)

    def y(v):
        v = max(0.0, min(scale, v))
        return H - PADB - (v / scale) * (H - PADT - PADB)

    band = ""
    if sunrise != "--:--" and sunset != "--:--":
        sx, ex = x(_mins(sunrise)), x(_mins(sunset))
        band = (f'<rect x="{sx:.1f}" y="{PADT}" width="{ex - sx:.1f}" '
                f'height="{H - PADT - PADB}" fill="var(--day-band)"/>')

    grid = ""
    for v in (0, scale / 2, scale):
        gy = y(v)
        grid += (f'<line x1="{PADL}" y1="{gy:.1f}" x2="{W - PADR}" y2="{gy:.1f}" '
                 f'stroke="var(--rule)" stroke-width=".6"/>'
                 f'<text x="{PADL - 4}" y="{gy + 3:.1f}" text-anchor="end" '
                 f'font-family="IBM Plex Mono,monospace" font-size="9" '
                 f'fill="var(--ink-faint)">{v:g}</text>')

    ly = y(limit)
    limit_line = (f'<line x1="{PADL}" y1="{ly:.1f}" x2="{W - PADR}" y2="{ly:.1f}" '
                  f'stroke="var(--bad)" stroke-width="1.1" stroke-dasharray="4 3"/>'
                  f'<text x="{W - PADR}" y="{ly - 3:.1f}" text-anchor="end" '
                  f'font-family="IBM Plex Mono,monospace" font-size="9" '
                  f'fill="var(--bad)">suggested limit {limit:g}</text>')

    pts = [(x(m), y(v)) for m, v in series]
    line = "M" + " L".join(f"{px:.1f} {py:.1f}" for px, py in pts)
    area = (f"{line} L{pts[-1][0]:.1f} {H - PADB} L{pts[0][0]:.1f} {H - PADB} Z"
            if len(pts) > 1 else "")
    fill = (f'<path d="{area}" fill="var(--tide-fill)" opacity=".5"/>' if area else "")

    marks = "".join(
        f'<circle cx="{px:.1f}" cy="{py:.1f}" r="2" fill="var(--surface)" '
        f'stroke="var(--tide-line)" stroke-width="1.2"/>' for px, py in pts)

    zone = ""
    if zone_kt is not None:
        zy = y(float(zone_kt))
        zone = (f'<line x1="{PADL}" y1="{zy:.1f}" x2="{W - PADR}" y2="{zy:.1f}" '
                f'stroke="var(--accent)" stroke-width="1" stroke-dasharray="2 3" '
                f'opacity=".85"/>'
                f'<text x="{PADL + 2}" y="{zy - 3:.1f}" '
                f'font-family="IBM Plex Mono,monospace" font-size="9" '
                f'fill="var(--accent)">NWS {float(zone_kt):g}</text>')

    return (f'<svg viewBox="0 0 {W} {H}" role="img" '
            f'aria-label="Wind through the day against the suggested {limit:g} knot limit">'
            f'{band}{grid}{fill}'
            f'<path d="{line}" fill="none" stroke="var(--tide-line)" '
            f'stroke-width="1.6" stroke-linejoin="round"/>'
            f'{marks}{limit_line}{zone}</svg>')


# ─────────────────────────────────────────────────────────────── icons ──
#
# Inline SVG, currentColor, 16px. No external requests — the page is
# self-contained and must stay that way.

_ICON = {
    "sun": '<circle cx="8" cy="8" r="3.4"/><g stroke-linecap="round">'
           '<path d="M8 .8v2M8 13.2v2M.8 8h2M13.2 8h2'
           'M2.9 2.9l1.4 1.4M11.7 11.7l1.4 1.4M13.1 2.9l-1.4 1.4M4.3 11.7l-1.4 1.4"/></g>',
    "moon": '<path d="M13 9.8A5.6 5.6 0 0 1 6.2 3a5.8 5.8 0 1 0 6.8 6.8z"/>',
    "partsun": '<circle cx="5.6" cy="5.6" r="2.5"/><g stroke-linecap="round">'
               '<path d="M5.6 .9v1.6M.9 5.6h1.6M2.3 2.3l1.1 1.1M8.9 2.3L7.8 3.4"/></g>'
               '<path d="M5.4 13.6a2.6 2.6 0 0 1 .3-5.2 3.5 3.5 0 0 1 6.6 1 2.1 2.1 0 0 1-.4 4.2z"/>',
    "cloud": '<path d="M4.6 13.2a3 3 0 0 1 .4-6 4 4 0 0 1 7.6 1.2 2.4 2.4 0 0 1-.5 4.8z"/>',
    "rain": '<path d="M4.6 10.4a3 3 0 0 1 .4-6 4 4 0 0 1 7.6 1.2 2.4 2.4 0 0 1-.5 4.8z"/>'
            '<g stroke-linecap="round"><path d="M5.4 12.2l-.9 2.4M8.2 12.2l-.9 2.4'
            'M11 12.2l-.9 2.4"/></g>',
    "showers": '<path d="M4.6 10.4a3 3 0 0 1 .4-6 4 4 0 0 1 7.6 1.2 2.4 2.4 0 0 1-.5 4.8z"/>'
               '<g stroke-linecap="round"><path d="M6.2 12.4l-.7 1.8M9.8 12.4l-.7 1.8"/></g>',
    "heavyrain": '<path d="M4.6 9.6a3 3 0 0 1 .4-6 4 4 0 0 1 7.6 1.2 2.4 2.4 0 0 1-.5 4.8z"/>'
                 '<g stroke-linecap="round"><path d="M4.4 11.2l-1 3.4M7.2 11.2l-1 3.4'
                 'M10 11.2l-1 3.4M12.8 11.2l-1 3.4"/></g>',
    "snow": '<path d="M4.6 10a3 3 0 0 1 .4-6 4 4 0 0 1 7.6 1.2 2.4 2.4 0 0 1-.5 4.8z"/>'
            '<g stroke-linecap="round"><path d="M5.6 12.4v2M4.7 12.9l1.8 1M6.5 12.9l-1.8 1'
            'M10.4 12.4v2M9.5 12.9l1.8 1M11.3 12.9l-1.8 1"/></g>',
    "sleet": '<path d="M4.6 10a3 3 0 0 1 .4-6 4 4 0 0 1 7.6 1.2 2.4 2.4 0 0 1-.5 4.8z"/>'
             '<g stroke-linecap="round"><path d="M5.6 12.2l-.8 2.2M10 12.2v2'
             'M9.2 12.7l1.6.9M10.8 12.7l-1.6.9"/></g>',
    "fog": '<g stroke-linecap="round"><path d="M2 5.5h12M3.5 8.5h9M2 11.5h12"/></g>',
}

# symbol_code stem -> icon. The model's own symbol is preferred over the phrase
# because it already knows about day and night.
_SYM = {
    "clearsky": "sun", "fair": "partsun", "partlycloudy": "partsun",
    "cloudy": "cloud", "fog": "fog",
    "lightrain": "showers", "rain": "rain", "heavyrain": "heavyrain",
    "lightrainshowers": "showers", "rainshowers": "rain",
    "heavyrainshowers": "heavyrain",
    "lightsleet": "sleet", "sleet": "sleet", "heavysleet": "sleet",
    "lightsleetshowers": "sleet", "sleetshowers": "sleet",
    "lightsnow": "snow", "snow": "snow", "heavysnow": "snow",
    "lightsnowshowers": "snow", "snowshowers": "snow",
}

_PHRASE = {
    "Clear": "sun", "Mostly clear": "partsun", "Partly cloudy": "partsun",
    "Overcast": "cloud", "Fog": "fog", "Light rain": "showers", "Rain": "rain",
    "Heavy rain": "heavyrain", "Light showers": "showers", "Showers": "rain",
    "Heavy showers": "heavyrain", "Sleet": "sleet", "Snow": "snow",
    "Light snow": "snow", "Snow showers": "snow",
}


def icon(symbol, phrase):
    """16px inline SVG for a sky condition, or nothing if we can't name it."""
    key = None
    if symbol:
        stem = symbol.split("_")[0]
        key = _SYM.get(stem)
        # a clear or fair night is a moon, not a sun
        if key in ("sun", "partsun") and symbol.endswith("_night"):
            key = "moon"
    if not key:
        key = _PHRASE.get(phrase)
    if not key or key not in _ICON:
        return ""
    return (f'<svg class="ico ico-{key}" viewBox="0 0 16 16" width="16" height="16" '
            f'aria-hidden="true" fill="none" stroke="currentColor" '
            f'stroke-width="1.3">{_ICON[key]}</svg>')


# ──────────────────────────────────────────────────────────── day cards ──

def _wind_trace(day, lim, scale):
    """The wind-through-the-day panel, or nothing when there is too little to plot."""
    series = day.get("wind_series") or []
    if len(series) < 2:
        return ""
    sun = day["sun"].split(" &ndash; ")
    svg = wind_svg(series, lim, scale, sun[0],
                   sun[1] if len(sun) > 1 else "--:--", day.get("zone_kt"))
    if not svg:
        return ""
    n = len(series)
    res = "hourly" if n >= 12 else f"{n} points, 6-hourly"
    return (f'<div class="wtrace">'
            f'<div class="wtrace-top"><span>Wind through the day</span>'
            f'<em>model, {res}</em></div>{svg}'
            f'<div class="wtrace-axis"><span>00</span><span>06</span><span>12</span>'
            f'<span>18</span><span>24</span></div></div>')


def day_card(day, prev_turns, next_turns, open_on):
    cls = "bc is-" + day["rating"] + (" is-best" if day.get("best") else "")

    if day["tilt"]:
        left = (
            '<div class="hgrid tilt">'
            '<div class="hcell"><div class="hlab">Temperature</div>'
            '<div class="htemp sm">No forecast</div><div class="hsky">Beyond model range</div></div>'
            '<div class="hcell"><div class="hlab">Precipitation</div>'
            '<div class="htemp sm">No forecast</div><div class="hsky">Beyond model range</div></div>'
            '<div class="hcell empty"><div class="hlab">Wind &amp; sea</div>'
            '<div class="htemp sm">No forecast</div><div class="hsky">Beyond model range</div></div>'
            '</div>'
            '<div class="nowind">No wind or sea-state guidance exists at this range &mdash; '
            'nothing here is a forecast you can plan a departure on. The tide, sun and moon '
            'beside it are exact.</div>')
        head_right = '<span class="tagline">' + esc(day["tag"]) + "</span>"
    else:
        cells = ""
        for c in day["cols"]:
            if c["f"] is None:
                cells += (f'<div class="hcell empty"><div class="hlab">{c["label"]}</div>'
                          f'<div class="htemp sm">&mdash;</div>'
                          f'<div class="hsky">{c["sky"]}</div></div>')
            else:
                arrow = S.ARROW.get(c["dir"], "&middot;")
                gust = ""
                if c.get("gust") is not None and c["kt"] is not None \
                        and c["gust"] - c["kt"] >= 2:
                    gust = f' <span class="gst">g{c["gust"]:.0f}</span>'
                cur = ""
                if c.get("cur") is not None:
                    v = c["cur"]
                    if abs(v) < 0.05:
                        cur = '<div class="hcur">slack</div>'
                    else:
                        cur = (f'<div class="hcur">{"flood" if v > 0 else "ebb"} '
                               f'{abs(v):.1f} kt</div>')
                ic = icon(c.get("sym"), c.get("sky"))
                cells += (f'<div class="hcell"><div class="hlab">{c["label"]}</div>'
                          f'<div class="htemp">{ic}<span>{c["f"]}&deg;</span></div>'
                          f'<div class="hwind"><span class="arr">{arrow}</span> '
                          f'{c["dir"] or ""} {c["kt"]:.1f} kt{gust}</div>'
                          f'<div class="hsky">{c["sky"]}</div>{cur}</div>')
        pk = day["peak_kt"] or 0
        lim = float(day.get("wind_limit", 10))
        scale = float(day.get("wind_scale", 12))
        pct = min(100, pk / scale * 100)
        over = " over" if pk > lim else ""
        gpct = None
        if day.get("gust_kt") is not None:
            gpct = min(100, day["gust_kt"] / scale * 100)
        gmark = (f'<span class="gmark" style="left:{gpct:.1f}%"></span>' if gpct else "")
        gtext = (f' &middot; gusts {day["gust_kt"]:.0f} kt'
                 if day.get("gust_kt") is not None else "")
        ncols = max(1, len(day["cols"]))
        left = (f'<div class="hgrid" style="grid-template-columns:repeat({ncols},1fr)">{cells}</div>'
                f'<div class="wbar-wrap">'
                f'<div class="wbar-top"><span>Peak wind vs. suggested limit</span>'
                f'<em>{pk:.1f} kt at {day["peak_at"]}{gtext} &middot; suggested limit {lim:g} kt</em></div>'
                f'<div class="wbar"><span class="fill{over}" style="width:{pct:.1f}%"></span>'
                f'{gmark}'
                f'<span class="lim" style="left:{lim / scale * 100:.1f}%"></span></div>'
                f'<div class="wbar-scale"><span>0</span><span>{scale / 3:.0f}</span>'
                f'<span>{scale * 2 / 3:.0f}</span>'
                f'<span>{scale:.0f} kt</span></div>'
                + _wind_trace(day, lim, scale)
                + f'</div>')
        gh = (f' <span class="gsth">g{day["gust_kt"]:.0f}</span>'
              if day.get("gust_kt") is not None else "")
        head_right = (f'<span class="bc-peak">peak <b>{pk:.1f} kt</b>{gh} '
                      f'{day["peak_dir"]} &middot; {day["sea"]}</span>')

    turns_html = "".join(
        f'<div class="tt"><div class="tt-k">{"High" if t["k"] == "H" else "Low"}</div>'
        f'<div class="tt-t">{t["hm"]}</div>'
        f'<div class="tt-v">{t["v"]:.1f} ft</div></div>'
        for t in day["turns"])

    cur_html = ""
    if day.get("currents"):
        chips = "".join(
            f'<div class="ct ct-{kind}"><div class="ct-k">'
            f'{"Slack" if kind == "slack" else kind.title()}</div>'
            f'<div class="ct-t">{t:%H:%M}</div>'
            f'<div class="ct-v">{"&mdash;" if kind == "slack" else f"{abs(v):.2f}"}</div></div>'
            for t, v, kind in day["currents"])
        cur_html = (f'<div class="cp-top"><h4>Current</h4>'
                    f'<span>max {day["cur_max"]:.2f} kt</span></div>'
                    f'<div class="cp-turns">{chips}</div>') if day.get("cur_max") else ""

    sun_parts = day["sun"].split(" &ndash; ")
    svg = tide_svg(prev_turns, day["turns"], next_turns,
                   sun_parts[0], sun_parts[1] if len(sun_parts) > 1 else "--:--")

    rain_meta = (f'<div>Rain &nbsp;<span>{day["rain_in"]:.2f} in</span></div>'
                 if not day["tilt"] else
                 '<div>Precip tilt &nbsp;<span>No forecast</span></div>')

    # Why this day landed where it did, and which way the sea has room to build.
    WHY = {
        "seas": "Seas over limit",
        "seas and wind": "Wind and seas over limit",
        "wind": "Wind over limit",
        "rain": "Too wet",
        "gusts": "Gusts over limit",
        "gusty": "Gusty",
        "showers": "Showers",
        "near limit": "Close to wind limit",
    }
    why = WHY.get(day.get("reason"))
    why_meta = (f'<div>Limiter &nbsp;<span>{why}</span></div>' if why and not day["tilt"]
                else ('<div>Limiter &nbsp;<span>Nothing &mdash; clean</span></div>'
                      if not day["tilt"] else ""))
    fetch_meta = (f'<div>Fetch &nbsp;<span>{day["fetch"]}</span></div>'
                  if day.get("fetch") and not day["tilt"] else "")
    open_html = (f'<div class="open-on">Open &nbsp;<span>{open_on}</span></div>'
                 if open_on else "")

    return f"""
    <article class="{cls}" id="d{day['key'].replace('-', '')}">
      <div class="bc-head">
        <span class="bc-dow">{day['dow']}</span>
        <span class="bc-date">{day['date_label']}{' &middot; today' if day['today'] else ''}</span>
        <span class="chip {day['rating']}">{day['label']}</span>
        <span class="spacer"></span>
        {head_right}
      </div>
      <p class="bc-sum">{day['sum']}</p>
      <div class="bc-body">
        <div>{left}</div>
        <div class="tp">
          <div class="tp-top"><h4>Tide &middot; {day.get("station_name") or "local"}</h4><span>range {day['range']}</span></div>
          {svg}
          <div class="tp-axis"><span>00</span><span>06</span><span>12</span><span>18</span><span>24</span></div>
          <div class="tp-turns">{turns_html}</div>
          {cur_html}
        </div>
      </div>
      <div class="bc-meta">
        <div>Sun &nbsp;<span>{day['sun']}</span></div>
        <div>Daylight &nbsp;<span>{day['daylight']}</span></div>
        <div>Moon &nbsp;<span>{day['moon']}</span></div>
        {rain_meta}
        {why_meta}
        {fetch_meta}
        {open_html}
      </div>
      {f'<p class="bc-win"><b>Best window</b>{day["win"]}</p>' if day.get("win") else ''}
      <p class="bc-note">{day['note']}</p>
    </article>"""


# ───────────────────────────────────────────────────────────── harvest ──

def _days_since(checked):
    """Days since the seasons table was hand-verified, or None if unparseable."""
    if not checked:
        return None
    for fmt in ("%d %b %Y", "%Y-%m-%d", "%b %d %Y"):
        try:
            return (date.today() - datetime.strptime(checked, fmt).date()).days
        except ValueError:
            continue
    return None


def harvest_section(harvest, checked, rule_alert, area="this area"):
    pills = ""
    for p in harvest["pills"]:
        note = p["note"]
        if p.get("to"):
            try:
                n = (datetime.strptime(p["to"], "%Y-%m-%d").date() - date.today()).days
                if n >= 0:
                    note += f"<br>closes in {n} day{'' if n == 1 else 's'}"
            except ValueError:
                pass
        pills += (f'<div class="hpill {p["state"]}"><b>{p["name"]}</b>'
                  f'<u>{p["head"]}</u><i>{note}</i></div>')

    rows = ""
    for r in harvest["table"]:
        rows += (f'<tr><td>{r["fishery"]}</td>'
                 f'<td class="st"><span class="st-tag {r["state"]}">{r["status"]}</span></td>'
                 f'<td class="mono">{r["season"]}</td>'
                 f'<td class="mono">{r["limit"]}</td>'
                 f'<td>{r["notes"]}</td></tr>')

    alert = ""
    if rule_alert:
        items = "".join(f"<li>{esc(t)}</li>" for _, t in rule_alert[:6])
        alert = (f'<p class="rnote"><b>New rule activity since this table was verified</b> '
                 f'&mdash; the WDFW feed has items that mention this water. The table below '
                 f'has <i>not</i> been updated for them; check before you go.<ul>{items}</ul></p>')

    # Regulations are the one thing on this page that can cost a reader a
    # citation. The verify line is always present, and it escalates on its own
    # once the hand-verified table starts going stale, so an unattended page
    # tells the truth about its own age instead of asserting last month's rules.
    # No seasons data at all -> no section. An empty "What's open" heading with
    # nothing under it reads as "nothing is open", which is a different claim.
    if not harvest.get("pills") and not harvest.get("table"):
        return ""

    age = _days_since(checked)
    if age is None:
        stale_cls, stale_msg = " warn", (
            "<b>Seasons not dated.</b> Confirm every rule with WDFW before you fish: "
            "<a href=\"https://wdfw.wa.gov/fishing/regulations/rules-concise\">"
            "wdfw.wa.gov fishing rules</a>.")
    elif age >= 10:
        stale_cls, stale_msg = " stale", (
            f"<b>These seasons were last checked by hand {age} days ago and may be out "
            f"of date.</b> WDFW changes rules mid-season by emergency order. "
            f"<a href=\"https://wdfw.wa.gov/fishing/regulations/rules-concise\">"
            f"Check the current rules</a> before you fish &mdash; do not rely on this table.")
    else:
        stale_cls, stale_msg = "", (
            "Checked by hand, not scraped. Rules change mid-season by emergency order "
            "&mdash; always confirm with "
            "<a href=\"https://wdfw.wa.gov/fishing/regulations/rules-concise\">WDFW</a> "
            "before you fish.")

    return f"""
  <section class="sec" id="harvest">
    <div class="sec-head">
      <h3>What's open &middot; {area}</h3>
      <span class="src">Verified {checked} &middot; feed checked today</span>
    </div>
    <div class="sec-conf"><i style="width:100%"></i></div>
    <div class="harvest">
      <div class="hpills">{pills}</div>
      <p class="hverify{stale_cls}">{stale_msg}</p>
      {alert}
     <details class="hdet" id="hdet" open>
      <summary class="hsum"><span class="lbl">Season detail, rules and deadlines</span>
        <span class="chev" aria-hidden="true"></span></summary>
      <div class="htable-wrap">
        <table class="ht">
          <colgroup><col style="width:18%"><col style="width:10%"><col style="width:20%">
            <col style="width:15%"><col style="width:37%"></colgroup>
          <thead><tr><th>Fishery</th><th>Status</th><th>Season</th>
            <th>Daily limit</th><th>Rules worth knowing</th></tr></thead>
          <tbody>{rows}</tbody>
        </table>
      </div>
      <div class="hfoot">
        {''.join(f'<p>{p}</p>' for p in harvest.get('footer', []))}
        <p><span class="caution">This is a convenience summary, not the regulations.</span>
        Seasons move on short notice, and this table is verified by hand rather than scraped.
        Confirm on WDFW's <a href="https://wdfw.wa.gov/fishing/regulations/emergency-rules"
        target="_blank" rel="noopener">emergency rules page</a> or the Fish Washington app
        before you leave the dock, and check shellfish on the
        <a href="https://doh.wa.gov/shellfishsafety" target="_blank" rel="noopener">DOH
        Shellfish Safety Map</a> or the biotoxin hotline at <b>1-800-562-5632</b>.</p>
      </div>
     </details>
    </div>
  </section>"""


# ──────────────────────────────────────────────────────────────── page ──

def glance(days):
    out = ""
    for d in days:
        cls = d["rating"] + (" now" if d["today"] else "")
        kt = "&mdash;" if d["tilt"] else f"{round(d['peak_kt'] or 0)}kt"
        out += (f'<a class="gd {cls}" href="#d{d["key"].replace("-", "")}">'
                f'<b>{d["dow"]}</b><i>{d["date"]:%-d}</i><u>{kt}</u></a>')
    return out


def render(cfg, days, verdict, harvest, checked, rule_alert, sources_line, notes):
    tiers = {1: "", 2: "", 3: ""}
    for n, d in enumerate(days):
        prev_t = days[n - 1]["turns"] if n > 0 else []
        next_t = days[n + 1]["turns"] if n + 1 < len(days) else []
        tiers[d["tier"]] += day_card(d, prev_t, next_t, harvest.get("open_on", ""))

    heads = {
        1: ("Days 1&ndash;5 &middot; Marine forecast", cfg["tier1_src"], 92),
        2: ("Days 6&ndash;10 &middot; Model guidance", cfg["tier2_src"], 55),
        3: ("Days 11&ndash;14 &middot; Climate outlook", cfg["tier3_src"], 20),
    }
    sections = ""
    for t in (1, 2, 3):
        title, src, conf = heads[t]
        sections += f"""
  <section class="sec">
    <div class="sec-head"><h3>{title}</h3><span class="src">{src}</span></div>
    <div class="sec-conf"><i style="width:{conf}%"></i></div>
    <div class="stack">{tiers[t]}</div>
  </section>"""

    notes_html = "".join(f"<li>{n}</li>" for n in notes)

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="{esc(cfg['description'])}">
<meta name="color-scheme" content="light dark">
<title>{esc(cfg['title'])}</title>
{_share_tags(cfg)}
{THEME}
</head>
<body>
<div class="wrap">
  <header class="mast">
    <div class="mast-id">
      <p class="eyebrow">{cfg['eyebrow']}</p>
      <h1>{esc(cfg['title'])}</h1>
      <p class="mast-sub">{cfg['subtitle']}</p>
    </div>
    <div class="stamp">
      <b>Generated</b>{cfg['generated']}
      <b>Tides</b>NOAA {cfg['station']} {cfg.get('station_name','')}
      <b>Datum</b>MLLW, feet
    </div>
  </header>

  <section class="verdict">
    <h2>{verdict['headline']}</h2>
    {''.join(f'<p>{p}</p>' for p in verdict['paragraphs'])}
    <div class="thresh">
      <div>Suggested limits &nbsp;<span>wind &le; {cfg['wind_limit_kt']} kt &middot;
        seas &le; {cfg['seas_limit_ft']} ft</span></div>
      <div>Scored for &nbsp;<span>general cruising comfort</span></div>
    </div>
    <div class="glance">{glance(days)}</div>
    <div class="glance-key">
      <span><em style="background:var(--go)"></em>Go &mdash; inside the limits</span>
      <span><em style="background:var(--warn)"></em>Marginal</span>
      <span><em style="background:var(--bad)"></em>Stay in</span>
      <span><em style="background:var(--rule-strong)"></em>Tilt only, no forecast</span>
      <span><em style="background:transparent;box-shadow:inset 0 0 0 2px var(--ink)"></em>Today</span>
    </div>
  </section>

{harvest_section(harvest, checked, rule_alert, cfg.get('area', 'this area')) if harvest else ''}
{sections}

  <section class="notes">
    <h3>Reading this page</h3>
    <ul>{notes_html}</ul>
    <div class="srcs">{sources_line}</div>
  </section>
</div>
</body>
</html>
"""


# ───────────────────────────────────────────────────────────── landing ──

def landing_page(site, areas, generated):
    """
    The index over every area. Built from the same run that built the pages, so
    it can never claim something the page it links to contradicts.

    An area that failed to build is shown as unavailable rather than omitted —
    a missing row looks like the area does not exist, which is a worse lie than
    saying the data is down.
    """
    CHIP = {"go": ("go", "Good today"), "warn": ("warn", "Marginal today"),
            "bad": ("bad", "Stay in today"), "soft": ("soft", "No forecast")}
    cards = ""
    for a in sorted(areas, key=lambda x: (x.get("order", 99), x.get("area", ""))):
        href = a.get("href") or "#"
        if not a.get("ok"):
            cards += (f'<a class="ac is-down" href="{esc(href)}">'
                      f'<div class="ac-top"><span class="ac-area">{a.get("area","")}</span>'
                      f'<span class="chip soft">Unavailable</span></div>'
                      f'<p class="ac-head">This area could not be built on the last run.</p>'
                      f'<p class="ac-meta">{esc(a.get("error","") or "source unavailable")}</p>'
                      f'</a>')
            continue
        cls, lbl = CHIP.get(a.get("today_rating", "soft"), CHIP["soft"])
        peak = (f'{a["today_peak"]:.1f} kt' if a.get("today_peak") is not None
                else "&mdash;")
        nxt = (f'Next good day {a["next_good"]}' if a.get("next_good")
               else "No clear day in the run")
        cards += (f'<a class="ac is-{cls}" href="{esc(href)}">'
                  f'<div class="ac-top"><span class="ac-area">{a.get("area","")}</span>'
                  f'<span class="chip {cls}">{lbl}</span></div>'
                  f'<p class="ac-head">{a.get("headline","")}</p>'
                  f'<p class="ac-blurb">{a.get("blurb","")}</p>'
                  f'<div class="ac-meta"><span>Today {peak}</span>'
                  f'<span>{a.get("go_days", 0)} good days in 14</span>'
                  f'<span>{nxt}</span></div></a>')

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="{esc(site['description'])}">
<meta name="color-scheme" content="light dark">
<title>{esc(site['title'])}</title>
<meta property="og:title" content="{esc(site['title'])}">
<meta property="og:description" content="{esc(site['description'])}">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary">
{f'<link rel="canonical" href="{esc(site["canonical"])}">' if site.get("canonical") else ''}
{THEME}
</head>
<body>
<div class="wrap">
  <header class="mast">
    <div class="mast-id">
      <p class="eyebrow">{site.get('eyebrow','')}</p>
      <h1>{esc(site['title'])}</h1>
      <p class="mast-sub">{site.get('subtitle','')}</p>
    </div>
    <div class="stamp"><b>Updated</b>{generated}</div>
  </header>
  <div class="areas">{cards}</div>
  <p class="ac-foot">{site.get('footer','')}</p>
</div>
</body>
</html>"""
