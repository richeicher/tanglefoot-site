"""
Offline end-to-end test.

This session has no egress, so the live HTTP can't be exercised here. Everything
downstream of the fetch can: parsers run against real captured payloads, and the
build/score/render path runs against a realistic synthetic series.
"""
import json
import math
import sys
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

import os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import astro, build, render, scoring as S, sources

TZ = ZoneInfo("America/Los_Angeles")
UTC = ZoneInfo("UTC")
FAILS = []


def check(name, cond, detail=""):
    print(f"  {'PASS' if cond else 'FAIL'}  {name}{'  ' + detail if detail else ''}")
    if not cond:
        FAILS.append(name)


# ── 1. real NOAA payload through the real parser ────────────────────────
print("\n1. NOAA tide parser, against a captured response")
noaa = {"predictions": [
    {"t": "2026-09-13 00:52", "v": "1.127", "type": "L"},
    {"t": "2026-09-13 07:11", "v": "10.238", "type": "H"},
    {"t": "2026-09-13 12:58", "v": "3.065", "type": "L"},
    {"t": "2026-09-13 18:58", "v": "10.854", "type": "H"},
]}
sources._get = lambda url, accept="*/*": json.dumps(noaa).encode()
tides, err = sources.fetch_tides("9447659", date(2026, 9, 13), date(2026, 9, 13))
check("parses without error", err is None, str(err or ""))
check("returns 4 turns", tides and len(tides) == 4)
check("rounds feet", tides and tides[1][2] == 10.24, str(tides[1] if tides else ""))
check("keeps H/L", tides and [t[3] for t in tides] == ["L", "H", "L", "H"])

# ── 2. real PZZ135 text through the real parser ─────────────────────────
print("\n2. NWS zone parser, against a captured product")
pzz = """PZZ135-102145-
Puget Sound and Hood Canal-
235 AM PDT Sun Sep 13 2026

.TODAY...S wind 5 to 10 kt rising to 10 to 15 kt late. Waves around 2 ft.
.TONIGHT...S wind 15 to 20 kt easing to 10 to 15 kt after midnight. Waves 1 to 3 ft.
.MON...S wind 5 to 10 kt. Waves 1 ft or less.
.MON NIGHT...NW wind 5 to 10 kt. Waves 1 ft or less.
.TUE...N wind 5 to 10 kt. Waves 1 ft or less.
$$
"""
sources._get = lambda url, accept="*/*": pzz.encode()
zone, err = sources.fetch_zone("pzz135")
check("parses without error", err is None, str(err or ""))
check("finds issuance", zone and zone["issued"] == "235 AM PDT Sun Sep 13 2026",
      repr(zone["issued"]) if zone else "")
check("finds 5 periods", zone and len(zone["periods"]) == 5,
      str(len(zone["periods"])) if zone else "")
check("wind from 'rising to 15 kt' = 15", sources.zone_wind_kt(zone["periods"][0][1]) == 15,
      str(sources.zone_wind_kt(zone["periods"][0][1])))
check("waves from '1 to 3 ft' = 3", sources.zone_wave_ft(zone["periods"][1][1]) == 3,
      str(sources.zone_wave_ft(zone["periods"][1][1])))

print("\n3. zone period -> real dates, mapped from the product's own issuance")
issued = build.parse_zone_issued("235 AM PDT Sun Sep 13 2026", date(2026, 1, 1))
check("issuance date parsed", issued == date(2026, 9, 13), str(issued))
zmap = build.map_zone_periods(zone, issued)
check("TODAY -> Sep 13", date(2026, 9, 13) in zmap)
check("MON -> Sep 14", date(2026, 9, 14) in zmap and "day" in zmap[date(2026, 9, 14)])
check("TUE -> Sep 15", date(2026, 9, 15) in zmap)
check("MON NIGHT lands on Mon", zmap.get(date(2026, 9, 14), {}).get("night") is not None)

# ── 3b. currents: the good shape, and the shapes that bit us ────────────
print("\n3b. current predictions")
good = {"current_predictions": {"meanFloodDir": "20", "meanEbbDir": "200", "cp": [
    {"Time": "2026-09-13 01:27", "Type": "slack", "Velocity_Major": "0"},
    {"Time": "2026-09-13 04:14", "Type": "flood", "Velocity_Major": "0.51"},
    {"Time": "2026-09-13 07:19", "Type": "slack", "Velocity_Major": "0"},
    {"Time": "2026-09-13 10:25", "Type": "ebb", "Velocity_Major": "-0.32"},
]}}
sources._get = lambda url, accept="*/*": json.dumps(good).encode()
cur, err = sources.fetch_currents("PUG1605", 40, date(2026, 9, 13), date(2026, 9, 14))
check("parses the documented shape", err is None, str(err or ""))
check("keeps 4 events", cur and len(cur["events"]) == 4)
check("ebb keeps its negative sign", cur and cur["events"][3][2] == -0.32)
check("slack is forced to zero", cur and cur["events"][0][2] == 0.0)
check("mean set directions kept", cur and cur["meta"]["ebb_dir"] == "200")

# PUG1613 answered with strings where dicts were documented — the crash that
# took the last probe down. It must degrade, not raise.
for name, bad in [
    ("cp is a list of strings", {"current_predictions": {"cp": ["no data", "x"]}}),
    ("cp is a bare string", {"current_predictions": {"cp": "no predictions"}}),
    ("block is a string", {"current_predictions": "unavailable"}),
    ("error envelope", {"error": {"message": "No data was found"}}),
    ("empty object", {}),
]:
    sources._get = lambda url, accept="*/*", b=bad: json.dumps(b).encode()
    try:
        c2, e2 = sources.fetch_currents("PUG1613", 29, date(2026, 9, 13), date(2026, 9, 14))
        check(f"degrades on {name}", c2 is None and bool(e2), str(e2)[:54])
    except Exception as ex:
        check(f"degrades on {name}", False, f"RAISED {type(ex).__name__}: {ex}")

sources._get = lambda url, accept="*/*": json.dumps(good).encode()
cur, _ = sources.fetch_currents("PUG1605", 40, date(2026, 9, 13), date(2026, 9, 14))
cby, cflat, cmeta = build.group_currents(cur, TZ)
check("grouped onto the right day", date(2026, 9, 13) in cby)
check("events sorted", [e[0] for e in cflat] == sorted(e[0] for e in cflat))
mid = datetime(2026, 9, 13, 5, 46, tzinfo=TZ)          # between flood max and slack
v = build.current_at(cflat, mid)
check("interpolates between events", v is not None and 0.0 < v < 0.51, str(v))
check("returns None outside the span",
      build.current_at(cflat, datetime(2026, 9, 20, 12, 0, tzinfo=TZ)) is None)
check("no currents configured is not an error",
      sources.fetch_currents(None, None, date(2026, 9, 13), date(2026, 9, 14)) == (None, None))
check("missing currents group to nothing", build.group_currents(None, TZ) == ({}, [], None))

# ── 3c. rule-feed alerting: it must be able to go quiet ─────────────────
print("\n3c. WDFW rule alerting")
_feed = [
    ("Thu, 03 Sep 2026 00:00:00 -0700", "Marine Area 9 (Admiralty Inlet), Marine Area 12 (Hood Canal) shellfish beaches update"),
    ("Tue, 25 Aug 2026 00:00:00 -0700", "Marine Area 4 (Neah Bay) salmon possession rules update"),
    ("Thu, 13 Aug 2026 00:00:00 -0700", "Puget Sound recreational crabbing update, Marine Area 7 North opens Aug. 15"),
    ("Wed, 05 Aug 2026 00:00:00 -0700", "Summer halibut fishery 2026"),
    ("Fri, 11 Sep 2026 00:00:00 -0700", "Skagit and Cascade River fishing updates"),
]
_chk = sources.parse_checked("13 Sep 2026")
check("checked date parses", _chk == date(2026, 9, 13), str(_chk))
check("rfc822 pubDate parses",
      sources._rfc822("Thu, 03 Sep 2026 00:00:00 -0700") == date(2026, 9, 3))
check("unparseable pubDate is not fatal", sources._rfc822("garbage") is None)
check("items older than the last check go quiet",
      sources.relevant_rules(_feed, set(), _chk) == [],
      str(len(sources.relevant_rules(_feed, set(), _chk))))
check("without a date, matching items still flag (3: shellfish, crab, halibut)",
      len(sources.relevant_rules(_feed, set(), None)) == 3,
      str(len(sources.relevant_rules(_feed, set(), None))))
_new = _feed + [("Wed, 24 Sep 2026 00:00:00 -0700",
                 "Puget Sound recreational crabbing, Marine Areas 8-1 and 8-2 winter season")]
check("a genuinely new item still fires",
      len(sources.relevant_rules(_new, set(), _chk)) == 1)
check("'possession limit' no longer matches Possession Sound",
      not sources.RELEVANT.search("Marine Area 4 (Neah Bay) salmon possession rules update"))
check("Possession Sound itself still matches",
      bool(sources.RELEVANT.search("Possession Sound crab closure")))
check("area 8 still matches", bool(sources.RELEVANT.search("Marine Area 8-2 update")))
check("an unrelated river item never matches",
      not sources.RELEVANT.search("Yakima River fall salmon fishery to open"))
check("a missing checked date does not crash",
      isinstance(sources.relevant_rules(_feed, set(), sources.parse_checked(None)), list))


# ── 4. astronomy against known values ───────────────────────────────────
print("\n4. sun and moon")
rise, sset, dl = astro.sun_times(date(2026, 9, 13), 47.99, -122.22, "America/Los_Angeles")
check("Everett sunrise ~06:44", rise.startswith("06:4"), rise)
check("Everett sunset ~19:2x", sset.startswith("19:2"), sset)
check("daylight ~12h4x", dl.startswith("12h 4"), dl)
r2, s2, _ = astro.sun_times(date(2026, 12, 21), 47.99, -122.22, "America/Los_Angeles")
check("solstice is much shorter", r2 > "07:5" and s2 < "16:3", f"{r2}-{s2}")
check("new moon near Sep 11", "New moon" in astro.moon(date(2026, 9, 11)),
      astro.moon(date(2026, 9, 11)))
check("waxing by Sep 19", "gibbous" in astro.moon(date(2026, 9, 21)).lower()
      or "quarter" in astro.moon(date(2026, 9, 19)).lower(),
      astro.moon(date(2026, 9, 19)) + " / " + astro.moon(date(2026, 9, 21)))

# ── 5. scoring rules ────────────────────────────────────────────────────
print("\n5. scoring")
check("6 kt -> light chop 1 ft", S.sea_state(6)[1] == 0.5, str(S.sea_state(6)))
check("10 kt -> 1-2 ft", S.sea_state(10)[1] == 2.0, str(S.sea_state(10)))
check("legal wind + illegal seas = stay in",
      S.rate_day(10, 2.0, 0.0, 10, 10, 1)[1] == "Stay in")
check("that day's limiter is seas", S.limiting_factor(10, 2.0, 0.0, 10, 1) == "seas")
check("calm dry clear = Excellent",
      S.rate_day(4, 0.5, 0.0, 10, 10, 1)[1] == "Excellent", str(S.rate_day(4, 0.5, 0.0, 10, 10, 1)))
check("calm dry grey = Good",
      S.rate_day(4, 0.5, 0.0, 90, 10, 1)[1] == "Good")
check("heavy rain = Stay in", S.rate_day(3, 0.5, 0.40, 90, 10, 1)[1] == "Stay in")
check("light rain = Marginal", S.rate_day(3, 0.5, 0.08, 90, 10, 1)[1] == "Marginal")
check("no forecast = tilt", S.rate_day(None, None, 0, None, 10, 1, has_forecast=False)[0] == "soft")
check("gust over limit caps a clean day at Marginal",
      S.rate_day(6, 0.5, 0.0, 10, 10, 1, gust_kt=13)[1] == "Marginal",
      str(S.rate_day(6, 0.5, 0.0, 10, 10, 1, gust_kt=13)))
check("gusts alone never make a day 'Stay in'",
      S.rate_day(6, 0.5, 0.0, 10, 10, 1, gust_kt=30)[0] == "warn")
check("ragged but legal gusts block Excellent",
      S.rate_day(4, 0.5, 0.0, 10, 10, 1, gust_kt=9.5)[1] == "Good",
      str(S.rate_day(4, 0.5, 0.0, 10, 10, 1, gust_kt=9.5)))
check("calm with tight gusts is still Excellent",
      S.rate_day(4, 0.5, 0.0, 10, 10, 1, gust_kt=6)[1] == "Excellent")
check("no gust data = old behaviour",
      S.rate_day(4, 0.5, 0.0, 10, 10, 1) == S.rate_day(4, 0.5, 0.0, 10, 10, 1, gust_kt=None))
check("limiter names gusts", S.limiting_factor(6, 0.5, 0.0, 10, 1, gust_kt=13) == "gusts")
check("limiter names gustiness", S.limiting_factor(4, 0.5, 0.0, 10, 1, gust_kt=9.5) == "gusty")
check("seas still outrank gusts as the limiter",
      S.limiting_factor(10, 2.0, 0.0, 10, 1, gust_kt=13) == "seas")
check("a day near the wind limit has a named limiter",
      S.limiting_factor(9, 1.0, 0.0, 10, 1) == "near limit")
check("a genuinely clean day has no limiter",
      S.limiting_factor(4, 0.5, 0.0, 10, 1) is None)
check("every Marginal day can name its limiter",
      all(S.limiting_factor(w, s, r, 10, 1, gust_kt=g) is not None
          for w, s, r, g in [(9, 1.0, 0.0, None), (3, 0.5, 0.08, None),
                             (6, 0.5, 0.0, 13), (4, 0.5, 0.0, 9.5)]
          if S.rate_day(w, s, r, 50, 10, 1, gust_kt=g)[0] == "warn"))

_ft = json.load(open(os.path.join(HERE, "areas", "8-2.json")))["fetch"]
check("southerly has the longest fetch", S.fetch_for("S", _ft)[1] == 1.3)
check("easterly is sheltered", S.fetch_for("E", _ft)[1] < 1.0)
check("no table means no inherited coastline", S.fetch_for("S") == (None, 1.0))
check("unknown direction is neutral", S.fetch_for(None) == (None, 1.0))
check("fetch is config-overridable",
      S.fetch_for("S", {"S": ["test bay", 2.0]}) == ("test bay", 2.0))
check("same wind, more fetch -> bigger sea",
      S.sea_state(8, 1.3)[1] > S.sea_state(8, 0.8)[1],
      f"{S.sea_state(8, 1.3)} vs {S.sea_state(8, 0.8)}")
check("fetch weight 1.0 leaves the old bands alone",
      S.sea_state(10, 1.0) == S.sea_state(10))
check("a sheltered 10 kt easterly stays inside a 1 ft limit",
      S.sea_state(10, 0.8)[1] <= 1.0, str(S.sea_state(10, 0.8)))

check("compass 295 -> WNW", S.compass(295) == "WNW", S.compass(295))
check("compass 305 -> NW  (boundary 303.75)", S.compass(305) == "NW", S.compass(305))
check("compass 359 -> N", S.compass(359) == "N", S.compass(359))
check("m/s -> kt", S.kt(5) == 9.7, str(S.kt(5)))

# ── 6. full pipeline on a synthetic but realistic series ────────────────
print("\n6. end-to-end build + render")
today = datetime.now(TZ).date()

tide_rows = []
for i in range(-1, 16):
    d = today + timedelta(days=i)
    for hh, v, k in (("00:52", 1.1, "L"), ("07:11", 10.2, "H"),
                     ("12:58", 3.1, "L"), ("18:58", 10.9, "H")):
        tide_rows.append((f"{d:%Y-%m-%d}", hh, v, k))

steps = {}
start = datetime.now(UTC).replace(minute=0, second=0, microsecond=0)
for h in range(0, 60):                      # hourly for 2.5 days
    t = start + timedelta(hours=h)
    steps[t.strftime("%Y-%m-%dT%H:%M:%SZ")] = {
        "temp_c": 13 + 5 * math.sin(h / 24 * 2 * math.pi),
        "wind_ms": 2.0 + 1.5 * math.sin(h / 12),
        "wind_dir": (h * 17) % 360, "cloud_pct": 40 + 40 * math.sin(h / 9),
        "rh_pct": 80, "precip_mm": 0.3 if h < 6 else 0.0,
        "symbol": "rain" if h < 6 else "fair_day",
        "gust_ms": (2.0 + 1.5 * math.sin(h / 12)) * 1.4,
    }
t = start + timedelta(hours=60)
while t < start + timedelta(days=15):       # 6-hourly after
    steps[t.strftime("%Y-%m-%dT%H:%M:%SZ")] = {
        "temp_c": 15.0, "wind_ms": 1.6, "wind_dir": 300, "cloud_pct": 10,
        "rh_pct": 70, "precip_mm": 0.0, "symbol": "clearsky_day", "gust_ms": None,
    }
    t += timedelta(hours=6)

model = {"updated": "2026-09-13T11:14:00Z", "steps": steps}
cfg = json.load(open(os.path.join(HERE, "config.json")))
cur_rows = {"events": [], "meta": {"flood_dir": "20", "ebb_dir": "200"}}
for i in range(-1, 16):
    _d = today + timedelta(days=i)
    for hm, v, k in (("01:27", 0.0, "slack"), ("04:14", 0.51, "flood"),
                     ("07:19", 0.0, "slack"), ("10:25", -0.32, "ebb"),
                     ("12:53", 0.0, "slack"), ("16:04", 0.58, "flood"),
                     ("19:30", 0.0, "slack"), ("22:40", -0.41, "ebb")):
        cur_rows["events"].append((f"{_d:%Y-%m-%d}", hm, v, k))

days, zi = build.build_days(cfg, tide_rows, model, zone, today, currents=cur_rows)

check("14 days built", len(days) == 14, str(len(days)))
check("tier split 5/5/4",
      [sum(1 for d in days if d["tier"] == t) for t in (1, 2, 3)] == [5, 5, 4])
check("day 0 is today", days[0]["today"] is True)
check("weekdays match dates",
      all(d["dow"] == f"{d['date']:%a}" for d in days))
check("every day has tide turns", all(d["turns"] for d in days))
check("every day has a rating", all(d["rating"] in ("go", "warn", "bad", "soft") for d in days))
check("a best day was chosen", any(d.get("best") for d in days))
check("ratings vary across the run", len({d["rating"] for d in days}) >= 2,
      str(sorted({d["rating"] for d in days})))
check("tier-3 days are tilt-only",
      all(d["tilt"] for d in days if d["tier"] == 3) or
      not any(d["tilt"] for d in days))

harvest = json.load(open(os.path.join(HERE, "harvest.json")))
verdict = {"headline": "test", "paragraphs": ["a", "b"]}
cfg2 = dict(cfg, generated="test", tier1_src="a", tier2_src="b", tier3_src="c")
page = render.render(cfg2, days, verdict, harvest, "13 Sep 2026", [], "srcs", ["note"])

check("page is substantial", len(page) > 40000, f"{len(page)} bytes")
check("title appears on the page", cfg["title"] in page)
check("marker defaults to the title when unset",
      (cfg.get("marker") or cfg["title"]) == cfg["title"])
check("renaming the page cannot break publishing",
      render.render(dict(cfg2, title="Totally Different Name"), days, verdict,
                    harvest, "13 Sep 2026", [], "s", ["n"]).count(
                        "Totally Different Name") >= 1)
check("14 day cards rendered", page.count('class="bc ') == 14, str(page.count('class="bc ')))
check("14 glance chips", page.count('class="gd ') == 14, str(page.count('class="gd ')))
check("tide SVGs drawn", page.count('aria-label="Tide curve"') == 14,
      str(page.count('aria-label="Tide curve"')))
check("no leftover template braces", "{" not in page.split("<style>")[0])
check("no JS needed", "<script" not in page)
check("harvest pills rendered", page.count('class="hpill ') == 6, str(page.count('class="hpill ')))

# ── 7. the new detail actually reaches the page ─────────────────────────
print("\n7. gusts, limiter and fetch on the page")
check("gust figures rendered in the columns", 'class="gst"' in page)
check("every day states its limiter", page.count("Limiter &nbsp;") == 14,
      str(page.count("Limiter &nbsp;")))
check("gust never printed below the wind it belongs to",
      all(d["gust_kt"] >= d["peak_kt"] for d in days
          if d.get("gust_kt") is not None and d["peak_kt"]))
check("zone override suppresses the model's stale gust",
      all(d.get("gust_kt") is None for d in days
          if not d["tilt"] and d["peak_kt"] and d["peak_kt"] >= 15),
      "zone calls 15-20 kt; model gusts top out near 10")

# …and with no zone product at all, the model's gusts must survive.
nz_days, _ = build.build_days(cfg, tide_rows, model, None, today)
nz_gusts = [d for d in nz_days if d.get("gust_kt") is not None]
check("model gusts survive when nothing overrides them",
      len(nz_gusts) >= 2, f"{len(nz_gusts)} days")
check("those gusts sit at or above their sustained wind",
      all(d["gust_kt"] >= d["peak_kt"] for d in nz_gusts if d["peak_kt"]))
check("missing gusts degrade quietly, not loudly",
      all(d.get("gust_kt") is None or d["gust_kt"] > 0 for d in days)
      and "None" not in page and "nan" not in page.lower())
check("no day is downgraded without naming why",
      all(d.get("reason") for d in days
          if d["rating"] in ("warn", "bad") and not d["tilt"]),
      "offenders: " + str([d["key"] for d in days
                           if d["rating"] in ("warn", "bad")
                           and not d["tilt"] and not d.get("reason")]))
check("no clean day invents a limiter",
      all(not d.get("reason") for d in days
          if d["rating"] == "go" and d["label"] == "Excellent"))
check("fetch label attached", any(d.get("fetch") for d in days if not d["tilt"]))

print("\n7a. wind trace and sky icons")
n_trace = page.count('class="wtrace"')
check("wind traces drawn for forecast days", n_trace >= 8, str(n_trace))
check("one trace per forecast day, never for a tilt day",
      n_trace == len([d for d in days
                      if len(d.get("wind_series") or []) >= 2]), str(n_trace))
check("trace svgs match trace panels",
      page.count('aria-label="Wind through the day') == n_trace)
check("limit line labelled on the trace",
      page.count(">suggested limit 10<") >= n_trace,
      str(page.count(">suggested limit 10<")))
check("the page never calls the limits the reader's own",
      not any(s in page for s in ["your limit", "your limits", "Your go/no-go",
                                  "your 10-knot", "your 1-foot"]),
      next((s for s in ["your limit", "your limits", "Your go/no-go"]
            if s in page), ""))
check("limits are framed as suggested", "suggested limit" in page
      and "Suggested limits" in page)
import generate as G
_notes = G.make_notes(cfg, "235 AM PDT Sun Sep 13 2026", "2026-09-13T11:14Z",
                      [], "13 Sep 2026", None)
_nj = " ".join(_notes)
check("notes say where the numbers come from",
      "not a standard" in _nj and "never as permission" in _nj)
check("notes quote the configured limits, not hardcoded ones",
      f"{cfg['wind_limit_kt']} knots" in _nj and f"{cfg['seas_limit_ft']}-foot" in _nj,
      _nj[:80])
_n12 = " ".join(G.make_notes(dict(cfg, wind_limit_kt=14, seas_limit_ft=2),
                             None, None, [], "13 Sep 2026", None))
check("changing the limit changes the notes",
      "14 knots" in _n12 and "10 knots" not in _n12)
check("notes carry no second-person limit language",
      not any(s in _nj for s in ["your limit", "your 10-kt", "your 1-foot"]))
check("trace states its own resolution",
      "model, hourly" in page or "6-hourly" in page)
check("zone line drawn only where the zone spoke",
      page.count(">NWS ") == len([d for d in days
                                  if d.get("zone_kt") is not None
                                  and len(d.get("wind_series") or []) >= 2]),
      str(page.count(">NWS ")))
tilt_days, _ = build.build_days(cfg, tide_rows, None, zone, today)
tilt_page = render.render(cfg2, tilt_days, verdict, harvest, "13 Sep 2026", [], "s", ["n"])
check("all-tilt run really is all tilt", all(d["tilt"] for d in tilt_days))
check("no wind trace on a day with no model", 'class="wtrace"' not in tilt_page)
check("no sky icons on a day with no model", 'class="ico ' not in tilt_page)
check("tilt page still renders 14 cards", tilt_page.count('class="bc ') == 14)

check("sky icons rendered", page.count('class="ico ') > 20,
      str(page.count('class="ico ')))
check("icons are inline, no external requests",
      "<img" not in page and "http://" not in page.split("</style>")[-1])
check("icons carry a condition class", 'class="ico ico-' in page)
check("clear night is a moon, not a sun",
      render.icon("clearsky_night", "Clear") != render.icon("clearsky_day", "Clear"))
check("unknown symbol falls back to the phrase",
      render.icon("no_such_symbol", "Overcast") != "")
check("unknown everything renders nothing", render.icon(None, "Gibberish") == "")
check("every model symbol used by the scorer has an icon",
      all(render.icon(s + "_day", None) != "" for s in
          ["clearsky", "fair", "partlycloudy", "cloudy", "lightrain", "rain",
           "heavyrain", "rainshowers", "fog", "snow", "sleet"]))

print("\n7c. ready for a public audience")
check("share card tags present",
      all(s in page for s in ['property="og:title"', 'property="og:description"',
                              'name="twitter:card"']))
check("share title carries the area", f'content="{cfg["title"]} &middot; {cfg["area"]}"' in page
      or cfg["area"] in page.split("</head>")[0], cfg["area"])
check("canonical url emitted", 'rel="canonical"' in page and cfg["canonical"] in page)
check("area label is not hardcoded",
      "Marine Area 8-2" in page and render.harvest_section(
          harvest, "13 Sep 2026", [], "Marine Area 9").count("Marine Area 9") >= 1)
check("verify-with-WDFW line always present",
      "wdfw.wa.gov/fishing/regulations" in page)

# the staleness ladder
_fresh = render.harvest_section(harvest, f"{date.today():%d %b %Y}", [], "MA 8-2")
_old = render.harvest_section(harvest,
       f"{date.today() - timedelta(days=40):%d %b %Y}", [], "MA 8-2")
_none = render.harvest_section(harvest, None, [], "MA 8-2")
check("fresh table reads as routine", 'class="hverify"' in _fresh)
check("stale table escalates", 'class="hverify stale"' in _old and "40 days ago" in _old)
check("undated table escalates", 'class="hverify warn"' in _none)
check("stale wording tells them not to rely on it", "do not rely on this table" in _old)
check("every state links to WDFW",
      all("wdfw.wa.gov" in x for x in (_fresh, _old, _none)))

print("\n7b. currents on the page")
check("every day carries its current events",
      all(len(d["currents"]) == 8 for d in days),
      str(sorted({len(d["currents"]) for d in days})))
check("current panels rendered", page.count('class="cp-turns"') == 14,
      str(page.count('class="cp-turns"')))
check("slack/flood/ebb chips rendered", page.count('class="ct ct-') == 14 * 8,
      str(page.count('class="ct ct-')))
check("column current values rendered", page.count('class="hcur"') > 0,
      str(page.count('class="hcur"')))
check("day max current computed", all(abs(d["cur_max"] - 0.58) < 1e-9 for d in days),
      str({d["cur_max"] for d in days}))
check("current note names the strongest set",
      all("Strongest flood 0.58 kt" in (d["cur_note"] or "") for d in days),
      str(days[0]["cur_note"]))
check("note carries the mean set direction",
      "200&deg;" in (days[0]["cur_note"] or "") or "20&deg;" in (days[0]["cur_note"] or ""),
      str(days[0]["cur_note"]))
check("ebb never shown as a negative number to the reader",
      "-0." not in page.split('class="cp-turns"')[1].split("</div></div>")[0])

# the page must survive currents being absent entirely
nc_days, _ = build.build_days(cfg, tide_rows, model, zone, today, currents=None)
nc_page = render.render(cfg2, nc_days, verdict, harvest, "13 Sep 2026", [], "srcs", ["note"])
check("page builds with no currents at all", len(nc_page) > 40000)
check("no empty current panel when there is no data",
      'class="cp-turns"' not in nc_page)
check("14 day cards either way", nc_page.count('class="bc ') == 14)
check("thresholds travel with each day",
      all(d.get("wind_limit") == cfg["wind_limit_kt"] for d in days))

print("\n8. the wind bar follows config, not a hardcoded 10")
cfg12 = dict(cfg, wind_limit_kt=14, seas_limit_ft=2)
d12, _ = build.build_days(cfg12, tide_rows, model, zone, today)
p12 = render.render(dict(cfg12, generated="t", tier1_src="a", tier2_src="b", tier3_src="c"),
                    d12, verdict, harvest, "13 Sep 2026", [], "srcs", ["note"])
check("bar label reads the configured limit", "limit 14 kt" in p12)
check("old hardcoded limit is gone", "limit 10 kt" not in p12)
check("scale end follows the limit", ">17 kt<" in p12 or ">16 kt<" in p12,
      "scale labels: " + ",".join(sorted(set(
          x for x in p12.split('class="wbar-scale"')[1][:200].split("<span>")
          if "kt" in x))[:3]))
check("a higher limit lets more days through",
      sum(1 for d in d12 if d["rating"] == "go") >=
      sum(1 for d in days if d["rating"] == "go"),
      f'{sum(1 for d in d12 if d["rating"] == "go")} vs '
      f'{sum(1 for d in days if d["rating"] == "go")}')

# A fixed path in /tmp is a trap: Ubuntu's fs.protected_regular stops even root
# from writing a sticky-dir file owned by another user, so a run as `ubuntu`
# would poison every later run as root. Unique file, owned by whoever ran it.
import tempfile
_fd, _out = tempfile.mkstemp(prefix="conditions-render-", suffix=".html")
with os.fdopen(_fd, "w") as _fh:
    _fh.write(page)
print(f"\n  wrote {_out} ({len(page)} bytes)")

# ── 10. multi-area: the runner and the landing page ─────────────────────
print("\n10. multi-area")
import generate as _G

_summaries = [
    {"area": "Marine Area 8-2", "href": "/conditions/8-2/", "order": 1, "ok": True,
     "blurb": "Home water.", "headline": "5 straight days inside the suggested limits",
     "today_rating": "go", "today_label": "Good", "today_peak": 6.2,
     "next_good": "Sat 19 Sep", "go_days": 7, "degraded": []},
    {"area": "Marine Area 9", "href": "/conditions/9/", "order": 2, "ok": True,
     "blurb": "The gate.", "headline": "A mixed fortnight", "today_rating": "bad",
     "today_label": "Stay in", "today_peak": 18.0, "next_good": None,
     "go_days": 0, "degraded": []},
    {"area": "Marine Area 7", "href": "/conditions/7/", "order": 4, "ok": False,
     "error": "NWS zone forecast unavailable (HTTP 503)", "degraded": []},
]
_site = {"title": "Boating Conditions for Overthinkers", "eyebrow": "Puget Sound",
         "subtitle": "by marine area", "description": "d",
         "canonical": "https://tanglefoot.dev/conditions/", "footer": "f"}
_idx = render.landing_page(_site, _summaries, "Sun 13 Sep 2026, 23:46 PDT")

check("index renders a card per area", _idx.count('class="ac ') == 3,
      str(_idx.count('class="ac ')))
check("a failed area is shown, not hidden", "Marine Area 7" in _idx
      and "is-down" in _idx)
check("the failure reason is stated", "HTTP 503" in _idx)
check("ordering respects the order key",
      _idx.index("Marine Area 8-2") < _idx.index("Marine Area 9") < _idx.index("Marine Area 7"))
check("today's rating colours the card", "ac is-go" in _idx and "ac is-bad" in _idx)
check("links point at the area pages",
      'href="/conditions/8-2/"' in _idx and 'href="/conditions/9/"' in _idx)
check("index carries share tags", 'property="og:title"' in _idx)
check("index needs no JavaScript", "<script" not in _idx)
check("theme has exactly one closing style tag",
      render.THEME.count("</style>") == 1, str(render.THEME.count("</style>")))
check("no CSS leaks outside the style element",
      not render.THEME.split("</style>")[-1].strip(),
      repr(render.THEME.split("</style>")[-1][:60]))
check("landing CSS is inside the style element",
      render.THEME.index(".ac-foot") < render.THEME.index("</style>"))
for _p, _nm in ((_idx, "index"), (page, "day page")):
    _after = _p.split("</style>")[-1]
    check(f"{_nm}: no raw CSS rendered as text",
          "{" not in _after.split("<body")[0] if "<body" in _after else True)
    check(f"{_nm}: exactly one style block", _p.count("<style>") == 1,
          str(_p.count("<style>")))

check("no leftover template braces", "{" not in _idx.split("<style>")[0])
check("'no clear day' stated rather than blank", "No clear day in the run" in _idx)

# the area configs that ship with the tarball must be valid and self-consistent
_adir = os.path.join(HERE, "areas")
_files = sorted(f for f in os.listdir(_adir)) if os.path.isdir(_adir) else []
check("at least one area config ships", len(_files) >= 1, str(_files))
for _f in _files:
    _c = json.load(open(os.path.join(_adir, _f)))
    _slug = _f[:-5]
    check(f"{_f}: output path matches its slug",
          f"/conditions/{_slug}/" in _c.get("output", ""), _c.get("output", ""))
    check(f"{_f}: href matches its slug", _c.get("href") == f"/conditions/{_slug}/",
          str(_c.get("href")))
    check(f"{_f}: names its own area", bool(_c.get("area")))
    check(f"{_f}: has a title", bool(_c.get("title")))

check("fetch never falls back to another area's coastline",
      S.fetch_for("S", None) == (None, 1.0) and S.fetch_for("S", {}) == (None, 1.0))
check("an area with no fetch table says nothing about fetch",
      S.fetch_for("S", {})[0] is None)
check("8-2 still has its own fetch table",
      S.fetch_for("S", json.load(open(os.path.join(_adir, "8-2.json")))["fetch"])[1] == 1.3)


# An area with no seasons table must build. This is the case that crashed all
# six areas: the "empty harvest" default I invented did not match the shape the
# renderer reads, and nothing tested it because the suite always had a real one.
_empty = dict(_G.EMPTY_HARVEST)
check("EMPTY_HARVEST has every key the renderer reads",
      all(k in _empty for k in ("pills", "table", "checked", "footer")),
      str(sorted(_empty)))
_nohv = render.render(dict(cfg2, area="Marine Area 9"), days, verdict,
                      _empty, None, [], "srcs", ["note"])
check("a page builds with no seasons data", len(_nohv) > 40000, f"{len(_nohv)} bytes")
check("no empty 'What's open' section is rendered", "What's open" not in _nohv)
check("14 day cards without a harvest table", _nohv.count('class="bc ') == 14)
check("harvest_section returns nothing when there is nothing",
      render.harvest_section(_empty, None, [], "MA 9") == "")
check("a real harvest table still renders", "What's open" in page)
_pt = render.render(dict(cfg2, station_name="Port Townsend", subtitle="Admiralty Inlet"),
                    [dict(d, station_name="Port Townsend") for d in days],
                    verdict, _empty, None, [], "s", ["n"])
check("tide panel names the configured station",
      _pt.count("Tide &middot; Port Townsend") == 14,
      str(_pt.count("Tide &middot; Port Townsend")))
check("no other area's station leaks in", "Everett" not in _pt)
check("8-2 still says Everett", page.count("Tide &middot; Everett") == 14,
      str(page.count("Tide &middot; Everett")))
check("run_one returns (code, summary)",
      len(_G.run_one.__code__.co_varnames) > 0 and callable(_G.run_one))

print("\n10b. zone must never be silently borrowed")
import newarea as _NA
_src = open(os.path.join(HERE, "newarea.py")).read()
check("no hardcoded zone fallback in newarea",
      'or "pzz135"' not in _src and "or 'pzz135'" not in _src)
check("newarea refuses to write an area with no zone",
      "REFUSING to write this area" in _src)
_gsrc = open(os.path.join(HERE, "generate.py")).read()
check("a missing zone degrades rather than crashing",
      "no NWS zone configured for this area" in _gsrc)
check("every shipped area names its zone",
      all(json.load(open(os.path.join(_adir, f))).get("zone")
          for f in os.listdir(_adir) if f.endswith(".json")))
check("shipped areas carry the zone's plain-English name",
      all(json.load(open(os.path.join(_adir, f))).get("zone_name")
          for f in os.listdir(_adir) if f.endswith(".json")))

# ── 9. portability: nothing may be pinned to the machine it was written on ──
print("\n9. portability")
_offenders = []
for _f in sorted(os.listdir(HERE)):
    if not _f.endswith((".py", ".json", ".html")):
        continue
    _txt = open(os.path.join(HERE, _f), encoding="utf-8", errors="replace").read()
    # Assembled at runtime so this file does not trip its own check.
    for _bad in ("/home/" + "claude", "/Users" + "/", "C:" + "\\"):
        if _bad in _txt:
            _offenders.append(f"{_f}: {_bad}")
check("no author-machine paths baked into any file", not _offenders,
      "; ".join(_offenders))

# A fixed path under /tmp is unwritable by a second user once a first one has
# created it (fs.protected_regular), which is how a root-run update broke on a
# file an earlier non-root run had left behind.
_tmp_lit = []
for _f in sorted(os.listdir(HERE)):
    if not _f.endswith(".py"):
        continue
    for _i, _line in enumerate(open(os.path.join(HERE, _f), encoding="utf-8"), 1):
        if _line.lstrip().startswith("#"):
            continue
        # needles assembled at runtime so this line does not match itself
        if ('"' + "/tm" + "p/") in _line or ("'" + "/tm" + "p/") in _line:
            _tmp_lit.append(f"{_f}:{_i}")
check("no fixed /tmp paths in any source file", not _tmp_lit, "; ".join(_tmp_lit))
check("runs from any working directory", HERE == os.path.dirname(
    os.path.abspath(__file__)))

print("\n" + ("ALL CHECKS PASSED" if not FAILS else f"{len(FAILS)} FAILED: {FAILS}"))
sys.exit(1 if FAILS else 0)
