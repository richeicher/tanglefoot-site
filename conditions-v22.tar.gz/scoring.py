"""
Turning numbers into a verdict.

All of the judgement the page makes lives here, in one place, so the rules can
be read and argued with rather than being scattered through the renderer.
"""

from __future__ import annotations

MS_TO_KT = 1.94384
MM_TO_IN = 1 / 25.4

COMPASS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
           "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]

# Arrows point the way the wind is blowing, not where it comes from.
ARROW = {"N": "↓", "NNE": "↓", "NE": "↙", "ENE": "↙", "E": "←", "ESE": "←",
         "SE": "↖", "SSE": "↑", "S": "↑", "SSW": "↑", "SW": "↗", "WSW": "→",
         "W": "→", "WNW": "→", "NW": "↘", "NNW": "↓"}


def compass(deg):
    if deg is None:
        return None
    return COMPASS[int((float(deg) % 360) / 22.5 + 0.5) % 16]


def kt(ms):
    return None if ms is None else round(float(ms) * MS_TO_KT, 1)


def f(c):
    return None if c is None else round(float(c) * 9 / 5 + 32)


def inches(mm):
    return 0.0 if mm is None else round(float(mm) * MM_TO_IN, 2)


def sea_state(peak_kt, fetch_weight=1.0):
    """
    Possession Sound has a short fetch, so sea state follows wind closely —
    but not equally from every direction. fetch_weight scales the wind before
    banding: a southerly with the length of the main basin behind it builds
    more sea than the same speed blowing off the Everett waterfront.

    Returns (label, upper-bound feet) — the bound is what gets compared against
    the seas threshold.
    """
    if peak_kt is None:
        return ("Unknown", None)
    peak_kt = peak_kt * (fetch_weight or 1.0)
    if peak_kt <= 3:
        return ("Glassy, under 6 in", 0.5)
    if peak_kt <= 6:
        return ("Ripples, under 6 in", 0.5)
    if peak_kt <= 9:
        return ("Light chop, ~1 ft", 1.0)
    if peak_kt <= 12:
        return ("Chop, 1&ndash;2 ft", 2.0)
    # Above 12 kt the old model stopped at a flat "2+ ft", which made anything
    # near an advisory unreachable on the seas axis. These continue the curve so
    # 18 kt and 28 kt are not the same number.
    if peak_kt <= 16:
        return ("Choppy, 2&ndash;3 ft", 3.0)
    if peak_kt <= 21:
        return ("Rough, 3&ndash;5 ft", 5.0)
    if peak_kt <= 27:
        return ("Very rough, 5&ndash;8 ft", 8.0)
    return ("Dangerous, 8+ ft", 12.0)


def sky_phrase(symbol, cloud_pct):
    """Short human phrase for a cell, preferring the model's own symbol."""
    if symbol:
        s = symbol.split("_")[0]
        table = {
            "clearsky": "Clear", "fair": "Mostly clear", "partlycloudy": "Partly cloudy",
            "cloudy": "Overcast", "lightrain": "Light rain", "rain": "Rain",
            "heavyrain": "Heavy rain", "lightrainshowers": "Light showers",
            "rainshowers": "Showers", "heavyrainshowers": "Heavy showers",
            "fog": "Fog", "lightsleet": "Sleet", "sleet": "Sleet", "snow": "Snow",
            "lightsnow": "Light snow", "heavysnow": "Heavy snow",
            "lightsnowshowers": "Snow showers", "snowshowers": "Snow showers",
        }
        if s in table:
            return table[s]
    if cloud_pct is None:
        return "&mdash;"
    if cloud_pct < 10:
        return "Clear"
    if cloud_pct < 40:
        return "Mostly clear"
    if cloud_pct < 75:
        return "Partly cloudy"
    return "Overcast"


GUST_SPREAD_KT = 5.0     # gust minus sustained, above which a day reads as gusty


def is_gusty(peak_kt, gust_kt):
    """A day is 'gusty' when the gusts run well above the sustained wind."""
    if peak_kt is None or gust_kt is None:
        return False
    return (gust_kt - peak_kt) >= GUST_SPREAD_KT


# Every rating rate_day can return, in order of severity. Anything that consumes
# a rating must handle all of them. This constant exists because it did not:
# v17 added the "rough" band and the landing page's label table was never
# updated, so its dict lookup fell through to a default and printed "No
# forecast" for a day that had a perfectly good forecast. A silent default turns
# an unhandled state into a confident claim about the weather.
RATINGS = ("go", "warn", "rough", "bad", "soft")


def rate_day(peak_kt, seas_ft, rain_in, cloud_avg, wind_limit, seas_limit,
             has_forecast=True, gust_kt=None, bands=None, hazard_rank=0):
    """
    Returns (rating, label) on a four-step scale.

        go    comfortable      within the green limits
        warn  workable         past comfortable, well short of hazardous
        rough capable          getting serious for a small boat
        bad   advisory         NWS has declared it, or the numbers are there

    `bands` carries the thresholds so they live in config, not here:
        {"green": [12, 2], "amber": [18, 4], "rough": [24, 6]}
    meaning green up to 12 kt and 2 ft, amber up to 18/4, rough up to 24/6,
    and red beyond that.

    `hazard_rank` is NWS's own headline: 1 = small craft advisory and up. When
    NWS has actually declared hazardous conditions, that wins over any number
    this code could pick, and the day is red regardless.
    """
    if not has_forecast:
        return ("soft", "Tilt only")

    if hazard_rank and hazard_rank >= 1:
        return ("bad", "Advisory")

    b = bands or {"green": [wind_limit, seas_limit], "amber": [18, 4], "rough": [24, 6]}
    gw, gs = b["green"]
    aw, as_ = b["amber"]
    rw, rs = b["rough"]

    w = peak_kt if peak_kt is not None else 0
    sfeet = seas_ft if seas_ft is not None else 0
    gust_over = gust_kt is not None and gust_kt > aw

    if rain_in >= 0.25 and w <= gw and sfeet <= gs:
        return ("warn", "Wet")                    # calm but not worth it

    if w > rw or sfeet > rs:
        return ("bad", "Advisory range")
    if w > aw or sfeet > as_ or gust_over:
        return ("rough", "Rough")
    if w > gw or sfeet > gs or rain_in >= 0.05:
        return ("warn", "Workable")

    dry_calm = rain_in < 0.02 and w <= gw * 0.7
    if dry_calm and not is_gusty(peak_kt, gust_kt) \
            and (cloud_avg is not None and cloud_avg < 45):
        return ("go", "Excellent")
    return ("go", "Good")


def limiting_factor(peak_kt, seas_ft, rain_in, wind_limit, seas_limit,
                    gust_kt=None, hazard_rank=0):
    """Which threshold actually decides the day. Used in the prose."""
    if hazard_rank and hazard_rank >= 1:
        return "advisory"
    if seas_ft is not None and seas_ft > seas_limit:
        if peak_kt is not None and peak_kt <= wind_limit:
            return "seas"          # the interesting case: legal wind, illegal water
        return "seas and wind"
    if peak_kt is not None and peak_kt > wind_limit:
        return "wind"
    if rain_in >= 0.25:
        return "rain"
    if gust_kt is not None and gust_kt > wind_limit:
        return "gusts"             # sustained is legal, the puffs are not
    if rain_in >= 0.05:
        return "showers"
    if is_gusty(peak_kt, gust_kt):
        return "gusty"
    # rate_day downgrades a day once wind reaches 80% of the limit, so the
    # limiter has to have a name for that case — otherwise a Marginal day
    # reports that nothing is against it.
    if peak_kt is not None and peak_kt > wind_limit * 0.8:
        return "near limit"
    return None


# ───────────────────────────────────────────────────────────────── fetch ──
#
# Which way the wind has room to build a sea. Sector -> (label, weight), where
# weight scales the wind-derived sea estimate: a 10 kt southerly with 20 miles
# of open water behind it is a different sea than 10 kt off a beach half a mile
# away. Overridden per-area from config.json; this is the fallback.

# There is deliberately NO default table. Fetch is local geography: Possession
# Sound's table is wrong for Admiralty Inlet and very wrong for the San Juans.
# An area that has not had its fetch described gets neutral weighting and says
# nothing about fetch, rather than inheriting another area's coastline.


def fetch_for(direction, table=None):
    """(label, weight) for a compass sector. No table, or unknown direction,
    is neutral: no label and no scaling."""
    if not table:
        return (None, 1.0)
    row = table.get(direction)
    if not row:
        return (None, 1.0)
    return (row[0], float(row[1]))


def score_for_ranking(day):
    """Higher is better. Used to pick the standout day of the run."""
    if day.get("tilt"):
        return -1e9
    s = 0.0
    s -= (day.get("rain_in") or 0) * 400          # dry dominates
    s -= (day.get("peak_kt") or 0) * 6            # then calm
    s -= (day.get("cloud_avg") or 0) * 0.35       # then clear
    s += (day.get("high_f") or 0) * 0.8           # then warm
    if day["rating"] == "bad":
        s -= 500
    if day["rating"] == "warn":
        s -= 200
    return s
